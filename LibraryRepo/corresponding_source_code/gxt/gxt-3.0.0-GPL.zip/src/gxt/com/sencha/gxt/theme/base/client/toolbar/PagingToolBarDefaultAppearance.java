/**
 * Sencha GXT 3.0.0 - Sencha for GWT
 * Copyright(c) 2007-2012, Sencha, Inc.
 * licensing@sencha.com
 *
 * http://www.sencha.com/products/gxt/license/
 */
package com.sencha.gxt.theme.base.client.toolbar;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.CssResource;
import com.google.gwt.resources.client.ImageResource;
import com.sencha.gxt.widget.core.client.toolbar.PagingToolBar.PagingToolBarAppearance;

public class PagingToolBarDefaultAppearance implements PagingToolBarAppearance {

  public interface PagingToolBarResources extends ClientBundle {
    @Source("page-first.gif")
    ImageResource first();
    
    @Source("page-prev.gif")
    ImageResource prev();
    
    @Source("page-next.gif")
    ImageResource next();
    
    @Source("page-last.gif")
    ImageResource last();
    
    ImageResource refresh();
    
    @Source("wait.gif")
    ImageResource loading();
  }

  public interface PagingToolBarStyle extends CssResource {

  }

  private final PagingToolBarResources resources;

  public PagingToolBarDefaultAppearance() {
    this(GWT.<PagingToolBarResources> create(PagingToolBarResources.class));
  }

  public PagingToolBarDefaultAppearance(PagingToolBarResources resources) {
    this.resources = resources;
  }

  @Override
  public ImageResource first() {
    return resources.first();
  }

  @Override
  public ImageResource last() {
    return resources.last();
  }

  @Override
  public ImageResource next() {
    return resources.next();
  }

  @Override
  public ImageResource prev() {
    return resources.prev();
  }

  @Override
  public ImageResource refresh() {
    return resources.refresh();
  }

  @Override
  public ImageResource loading() {
    return resources.loading();
  }

}
