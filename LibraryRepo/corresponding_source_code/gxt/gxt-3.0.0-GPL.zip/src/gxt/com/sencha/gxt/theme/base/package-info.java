/**
 * Sencha GXT 3.0.0 - Sencha for GWT
 * Copyright(c) 2007-2012, Sencha, Inc.
 * licensing@sencha.com
 *
 * http://www.sencha.com/products/gxt/license/
 */
/**
 * The default base theme for GXT. This theme applies enough CSS rules to give the components structure but does not
 * otherwise style components.
 */
package com.sencha.gxt.theme.base;