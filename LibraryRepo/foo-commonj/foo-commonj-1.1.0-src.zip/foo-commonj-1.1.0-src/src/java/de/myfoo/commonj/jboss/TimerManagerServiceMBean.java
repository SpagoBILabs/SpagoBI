package de.myfoo.commonj.jboss;


/**
 * JMX MBean interface of the JSR 236 <code>Timer</code> Service 
 * for JBoss.
 * 
 * @author Andreas Keldenich
 */
public interface TimerManagerServiceMBean extends FooServiceMBean {

}
