package de.myfoo.commonj.jboss;


/**
 * JMX MBean interface of the JSR 237 <code>WorkManager</code> Service 
 * for JBoss.
 * 
 * @author Andreas Keldenich
 */
public interface WorkManagerServiceMBean extends FooServiceMBean {

}
