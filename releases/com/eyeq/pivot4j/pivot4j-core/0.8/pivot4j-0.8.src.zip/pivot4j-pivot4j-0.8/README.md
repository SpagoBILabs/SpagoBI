About Pivot4J
=======

Pivot4J provides a common API for OLAP servers which can be used to build an analytical service frontend with pivot style GUI.

It aims to leverage mature but now discontinued JPivot project's codebase to make it a general purpose OLAP API library which 
is independent of any particular GUI implementation.

Project Page
=======

Please visit Pivot4J home page at http://mysticfall.github.com/pivot4j