About Pivot4J Analytics Project
=======

This project contains a sample application demonstrating basic API usage of Pivot4J library. 
It is built with PrimeFaces and can be deployed on Servlet 2.5 compatible containers.

Project Page
=======

For more information, please visit the Pivot4J homepage at http://mysticfall.github.com/pivot4j/example.html
