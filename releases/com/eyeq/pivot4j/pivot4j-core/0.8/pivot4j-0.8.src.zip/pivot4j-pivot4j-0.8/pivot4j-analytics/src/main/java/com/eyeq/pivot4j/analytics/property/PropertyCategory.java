package com.eyeq.pivot4j.analytics.property;

public enum PropertyCategory {

	Header, Cell
}
