package com.eyeq.pivot4j.analytics.graphene;

public interface PageFragment {
}
