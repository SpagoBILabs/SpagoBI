package com.eyeq.pivot4j.analytics.repository.test;

import com.eyeq.pivot4j.analytics.repository.ReportRepository;

public interface TestRepository extends ReportRepository {

	void initialize();
}
