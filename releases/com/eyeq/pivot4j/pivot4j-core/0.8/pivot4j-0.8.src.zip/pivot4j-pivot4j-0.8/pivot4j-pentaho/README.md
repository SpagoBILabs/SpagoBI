About Pivot4J Pentaho Project
=======

This project contains a plugin for the Pentaho BI platform which is based on the Pivot4J JSF application. 

Project Page
=======

For more information, please visit the Pivot4J homepage at http://mysticfall.github.com/pivot4j/pentaho.html
