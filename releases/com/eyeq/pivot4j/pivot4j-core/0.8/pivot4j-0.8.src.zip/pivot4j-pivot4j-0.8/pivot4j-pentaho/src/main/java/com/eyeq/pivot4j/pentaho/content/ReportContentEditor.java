package com.eyeq.pivot4j.pentaho.content;

public class ReportContentEditor extends ReportContentGenerator {

	private static final long serialVersionUID = 2954902953680461053L;

	/**
	 * @see com.eyeq.pivot4j.pentaho.content.ReportContentGenerator#isEditable()
	 */
	@Override
	public boolean isEditable() {
		return true;
	}
}
