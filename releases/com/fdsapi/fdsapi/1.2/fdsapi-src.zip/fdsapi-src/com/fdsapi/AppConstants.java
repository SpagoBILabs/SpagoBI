

package com.fdsapi;  // FormattedDataSet API


import java.util.*;
import com.jamonapi.*;
import com.jamonapi.utils.*;

/**

This class defines constants used in the FormattedDataSet codeline.

Currently it contains constants that define what the applications HTML tables and listboxes will look like.
The constants defined in this class can be accessed as follows:

String str=AppConstants.DATASOURCE;

Note that being as all values are static the AppConstants object does not to be created
with new to reference it.

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/AppConstants.htm">View Code</a>
@author Steve Souza
 

*/
//???? set methods should be synchronized.

public class AppConstants extends java.lang.Object
{
public static       String DATASOURCE="DataSource";
public static final int MONITOR_PRIORITY_LEVEL=11;
public static final String MONITOR_PREFIX="com.fdsapi.";

private static Map appConstants;

static {
    appConstants = AppMap.createInstance();
    // I don't believe these are needed any longer??
    appConstants.put(DATASOURCE, DATASOURCE);
    appConstants.put("formMethod", "post");
    appConstants.put("debug", "0");
    appConstants.put("dateFormat", "M/d/yy");
    appConstants.put( "errorIndicator", "** ");
    appConstants.put( "requiredField",  "This is a required field.<br>");
    appConstants.put( "invalidDate", " is an invalid date.<br>");
    appConstants.put( "conversion", " was not converted properly.<br>");
    appConstants.put( "fieldNoExists", " Field object must be defined.<br>");

}

public static void setAppConstants(Map newAppConstants) {
    appConstants = newAppConstants;
}

public static Map getAppConstants() {
    return appConstants;
}



public static String get(String key) {
    String value="The requested AppConstant was not found.  Please contact a developer.  key="+key;

    if (appConstants.containsKey(key))
        value = appConstants.get(key).toString();
    else
        Utils.log(value);

    return value;

}


public static Monitor start(String locator) {
    return MonitorFactory.getDebugFactory(MONITOR_PRIORITY_LEVEL).start(MONITOR_PREFIX+locator);
}  

// i.e. replaceString("Steve Smith", "Smith", "Souza")
// would return "Steve Souza".  Only replaces first occurence
public static String replaceString(String sourceStr, String replaceStr, String replaceWithStr) {
    final int NOMATCH=-1;
    int start=sourceStr.indexOf(replaceStr);  

    if (start==NOMATCH)
        return sourceStr;
    else {
            StringBuffer sourceBuffer = new StringBuffer(sourceStr);
            int end = start+replaceStr.length();
            sourceBuffer.replace(start, end, replaceWithStr);
            return sourceBuffer.toString();
    }

}



protected AppConstants() {
}
}

