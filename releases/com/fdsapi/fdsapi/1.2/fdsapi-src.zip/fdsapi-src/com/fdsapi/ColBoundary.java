package com.fdsapi;  // FormattedDataSet API

import java.util.*;
import com.jamonapi.utils.*;

/** Class used by the FormattedDataSet Template parser to build Template objects. 
 
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ColBoundary.htm">View Code</a>
 */


 public abstract class ColBoundary  {
     
/* The variable 'string' contains the non dynamic portion of template variable before dynamic part.  
   ColBoundary itself contains both dynamic and nondynamic portions.
   
   For example if dataSource==myDataSource##rowNum, then string would contain myDataSource,
   dynamicVariableType would contain rowNum.
   
   getVariableValue(...) returns the dynamic portion (i.e. in this case ##rowNum)
  
 */
     String string; 

 /** Note if there is no match and strictSyntax is false then when an entry is not
     in the miscData HashMap() then a noop occurs.
     For example if ##myVar is not in the Map at runtime then either nothing will be appended to the buffer or 
    a RuntimeException will be thrown depending on the value of strictSyntaxError.
  **/
     boolean strictSyntax=false;
     
     ColBoundary(String string, String dynamicVariableType)      {
         this.string = string;
     }
     
    
     void getVariableValue(StringBuffer stringBuffer, DataSetParm dataSetParm) {
        stringBuffer.append(string);
        getVariableValueThis(stringBuffer, dataSetParm);

     }
     
     void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
         
     }
     
     static int parseInt(String integerStr) {
         return Integer.parseInt(integerStr);
     }
     
     static int firstIntPosition(String str) {
         char[] arr=str.toCharArray();
         int startPosition=-1;
         // look at end of string for a number and count backwards until the start of the number is found
         for (int i=str.length()-1; i>=0; i--) {
             if (Character.isDigit(arr[i]))
                 startPosition=i;
             else 
                 break;
         }
         
         return startPosition;
   
     }
     
     // if a string is passed of the format header1, or myVariable23 then 
     // the int 1 and 23 will be returned respectively.
     static int extractInt(String str) {
         int startPosition=firstIntPosition(str);
         if (startPosition==-1)
             return -1;
         else
             return parseInt(str.substring(startPosition));
     }
     
     
     static ColBoundary createInstance(String string, String dynamicVariableType) {
         ColBoundary colBoundary=null;
         if (Null.isType(dynamicVariableType))  // no ## variable
            colBoundary=new Null(string, dynamicVariableType);
         else if (CellData.isType(dynamicVariableType)) //##1, ##2, ##99 etc.
            colBoundary=new CellData(string, dynamicVariableType);
         else if (CurrentCol.isType(dynamicVariableType))  // ##this
            colBoundary=new CurrentCol(string, dynamicVariableType);         
         else if (RowNum.isType(dynamicVariableType)) // ##rowNum
            colBoundary=new RowNum(string, dynamicVariableType);
         else if (ColNum.isType(dynamicVariableType)) /// ##colNum
            colBoundary=new ColNum(string, dynamicVariableType);
         else if (CurrentColHeader.isType(dynamicVariableType))  // ##headerThis
            colBoundary=new CurrentColHeader(string, dynamicVariableType);         
         else if (CellDataHeader.isType(dynamicVariableType)) //##header1, ##header2, ##header99 etc.
            colBoundary=new CellDataHeader(string, dynamicVariableType);
         else if (MiscDataArray.isType(dynamicVariableType)) // ##myMiscVariable
            colBoundary=new MiscDataArray(string, dynamicVariableType);
         else if (MiscDataCurrentCol.isType(dynamicVariableType)) // ##myMiscVariable
            colBoundary=new MiscDataCurrentCol(string, dynamicVariableType);
         else if (MiscData.isType(dynamicVariableType)) // ##myMiscVariable
            colBoundary=new MiscData(string, dynamicVariableType);
         else 
            throw new RuntimeExceptionBase("Error creating ColBoundary object of type (This code should never be reached): "+dynamicVariableType+" ("+string+")");
         
         log(colBoundary+": string="+string+", dynamicVariableType="+dynamicVariableType);
         return colBoundary;
       
     }
     
     private static boolean debug=false;
     static void setDebug(boolean debugFlag) {
         debug=debugFlag;
     }
     
     /* Log debug message */
     static private void log(String logStr) {
         if (debug)
           Utils.logDebug(logStr);
     }

     
     
     
     /**** start inner classes ****/
     // 1) ##1
     private static class CellData extends ColBoundary {
        int col;
         
        CellData(String string, String integerStr)  {
             super(string, integerStr);
             col=parseInt(integerStr);
         }
         

         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                stringBuffer.append(dataSetParm.getTabularData().getCellData(col));
             
         }

        static boolean isType(String dynamicVariableType) {
            return Character.isDigit(dynamicVariableType.charAt(0));
        }

         
     }
     
     
     // 2) no ## variable
     private static class Null extends ColBoundary {
        Null(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
         }

        static boolean isType(String dynamicVariableType) {
            return dynamicVariableType==null;
        }
         
     }
     
     
     // 3) ##this
     private static class CurrentCol extends ColBoundary {
        CurrentCol(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
         }
         
         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                stringBuffer.append(dataSetParm.getTabularData().getCellData());
             
         }

        static boolean isType(String dynamicVariableType) {
            return TemplateConstants.CURRENT_COL.equalsIgnoreCase(dynamicVariableType);
        }

     }
     
     // 4) ##rowNum
     private static class RowNum extends ColBoundary {
        RowNum(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
         }
         
         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                stringBuffer.append(dataSetParm.getTabularData().getRowIterator().getCurrentItemNumber());
             
         }

        static boolean isType(String dynamicVariableType) {
            return TemplateConstants.ROW_NUM.equalsIgnoreCase(dynamicVariableType);
        }

     }
     

     // 5) ##colNum
     private static class ColNum extends ColBoundary {
        ColNum(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
         }
         
         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                stringBuffer.append(dataSetParm.getTabularData().getColIterator().getCurrentItemNumber());
             
         }

        static boolean isType(String dynamicVariableType) {
            return TemplateConstants.COL_NUM.equalsIgnoreCase(dynamicVariableType);
        }

     }

     // 6) ##header1
     private static class CellDataHeader extends ColBoundary {
        int col;
        private static final String HEADER=TemplateConstants.HEADER.toLowerCase();
         
        CellDataHeader(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
             // Converts string like headerNum with just num
             // ex.  header5 returns 5
             //String integerStr=AppConstants.replaceString(dynamicVariableType.toLowerCase(), HEADER,"");
             col=extractInt(dynamicVariableType);
         }
         
        void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                stringBuffer.append(dataSetParm.getTabularData().getHeader().getCellData(col));
             
         }

        // Checking to see if passed variable starts with header and is followed by a number
        static boolean isType(String dynamicVariableType) {
            return  dynamicVariableType.toLowerCase().startsWith(HEADER) // i.e. a match has been found
                    &&             
                    Character.isDigit(dynamicVariableType.charAt(HEADER.length()));
        }

     }
  

     // 7) ##headerThis
     private static class CurrentColHeader extends ColBoundary {
        CurrentColHeader(String string, String dynamicVariableType)  {
             super(string, dynamicVariableType);
         }
         
         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                int currentCol=dataSetParm.getTabularData().getColIterator().getCurrentItemNumber();
                stringBuffer.append(dataSetParm.getTabularData().getHeader().getCellData(currentCol));
             
         }

        static boolean isType(String dynamicVariableType) {
            return TemplateConstants.CURRENT_COL_HEADER.equalsIgnoreCase(dynamicVariableType);
        }

     }
     

     // 8) ##myMiscDataVariable1 .. ##myMiscDataVariableN
     private static class MiscDataArray extends ColBoundary {
        private int col;
        private String miscVariableName;
         
        MiscDataArray(String string, String miscVariableName)  {
             super(string, miscVariableName);
             int intPos=firstIntPosition(miscVariableName);
             // if the value is myMiscDataVariable100 then return 99
             col=extractInt(miscVariableName)-1;
             //  in the example above return myMiscDataVariable
             this.miscVariableName=miscVariableName.substring(0, intPos);
         }

         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
             // Calls Map for anything after the ##variable .i.e. in this case variable
             // would be passed to the Map.  Look in the Map for a variable myMiscDataVariable.
             // It must be of type Object[].
             Object obj=dataSetParm.getMiscDataMap().get(miscVariableName);
             
             if (obj instanceof Object[]) {
                Object[] objArr=(Object[])obj;
                stringBuffer.append(objArr[col]);
             } else if (obj instanceof int[]) {
                int[] intArr=(int[])obj;
                stringBuffer.append(intArr[col]);
             } else if (strictSyntax)
                throw new RuntimeExceptionBase("Invalid object type in miscDataMap.  Valid values are Object[] and int[]: "+miscVariableName+col);
         }
         
         /** This method is the last to be called, and it means ## was followed by something that
          *  didn't match.  This will always return true
          */
         static boolean isType(String dynamicVariableType) {
            char lastChar=dynamicVariableType.charAt(dynamicVariableType.length()-1);
            return Character.isDigit(lastChar);
        }
         
     }

     // 9) ##myMiscDataVariableThis
     private static class MiscDataCurrentCol extends ColBoundary {
        private String miscVariableName;
         
        MiscDataCurrentCol(String string, String miscVariableName)  {
             super(string, miscVariableName);
             // myVarThis would return 9-4-1=4 (i.e. the 5th character because of 0 indexing)
             int endIndex=miscVariableName.length()-TemplateConstants.CURRENT_COL.length();
             this.miscVariableName=miscVariableName.substring(0, endIndex);
        }

         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                // The entry in the map must be a 1 dimensional array of objects.
             Object obj=dataSetParm.getMiscDataMap().get(miscVariableName);
             int index=dataSetParm.getTabularData().getColIterator().getCurrentItemNumber()-1;
             
             if (obj instanceof Object[]) {
                Object[] objArr=(Object[])obj;
                stringBuffer.append(objArr[index]);
             } else if (obj instanceof int[]) {
                int[] intArr=(int[])obj;
                stringBuffer.append(intArr[index]);
             } else if (strictSyntax)
                throw new RuntimeExceptionBase("Invalid object type in miscDataMap.  Valid values are Object[] and int[]: variableName="+miscVariableName+", index="+index+", Object type="+obj);
         }
         
         /** Checks that the end of the passed string ends in 'this'.
          *  i.e. ##myVariableThis would return true
          *       ##myVariable would return false
          */
         static boolean isType(String dynamicVariableType) {
            String var=dynamicVariableType.toLowerCase();
            String thisStr=TemplateConstants.CURRENT_COL.toLowerCase();
            return var.endsWith(thisStr);
        }
         
     }

     // 10) ##myMiscDataVariable
     private static class MiscData extends ColBoundary {
        private String miscVariableName;
         
        MiscData(String string, String miscVariableName)  {
             super(string, miscVariableName);
             this.miscVariableName=miscVariableName;
        }

         void getVariableValueThis(StringBuffer stringBuffer, DataSetParm dataSetParm) {
                // Calls Map for anything after the ##variable .i.e. in this case variable
                // would be passed to the Map.
             Object value=dataSetParm.getMiscDataMap().get(miscVariableName);
             if (value!=null)
                stringBuffer.append(value);
             else if (strictSyntax)
                throw new RuntimeExceptionBase("A value was not in miscDataMap: variableName="+miscVariableName);
                 
         }
         
         /** This method is the last to be called, and it means ## was followed by something that
          *  didn't match.  This will always return true
          */
         static boolean isType(String dynamicVariableType) {
            return true;
        }
         
     }

 }
