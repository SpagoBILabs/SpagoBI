/*
 * Converter.java
 *
 * Created on February 20, 2005, 3:57 PM
 */

package com.fdsapi;

/**
 *
 * This interface is implemented when you want to convert one Object to another.  Another way to
 * look at the use of this interface is that it is useful when you want to change the format or 
 * transform an input Object to an Output object.  For example you could 'convert' an Integer object 
 * such as 100000 to a comma delimeted String such as 100,000.  One of the main uses of this interface
 * is to format numbers and dates for display, but more generally the concept is that this interface 
 * allows you to convert from ANY object to ANY other Object.
 * 
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/Converter.htm">View Code</a>
 */
public interface Converter {
    /* Convert an input Object into another Object.  For example the ConverterNumToString converts a number
     * like 100000 to 100,000.  Although not strictly required there are advantages to simply checking the
     * passed in Object's data type and performing a noop if it is not of the right type (i.e. simply return the data
     * unchanged as opposed to throwing an exception).  */
    public Object convert(Object inputObj);

    /* Factory method that Converters must implement to return a usable instance.  Functionally it
     should operate as clone() would.  I didn't use Cloneable to do this as the Cloneable interface
     does not force developers to implement any method.  This explicit interface forces developers
     to provide this behaviour at compile time.
     */
    public Converter createInstance();
}
