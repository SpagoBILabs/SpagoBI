/*
 * ConverterBase.java
 *
 * Created on February 22, 2005, 1:36 PM
 */

package com.fdsapi;

/**
 * Base class for Converter objects used to convert an input Object to an output Object.  This class
 * implements the decorator design pattern that allows the chaining of Converters together.  Each one
 * checking the passed in data and taking action if appropriate.  The last decorator in the chain 
 * takes action first and passes the CHANGED output Object up the chain and further action may be
 * taken by other Converters at this point.  Keep in mind that the Object being passed up the change
 * for action may not be the same type as the input Object was.  For example a Date may go down the 
 * chain and a Date converted to a String may come up the chain.   The last Converter in the chain
 * is always the NullConverter which simply returns the input Object.
 *
 * 
 *  <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ConverterBase.htm">View Code</a>
 */
abstract public class ConverterBase implements Converter {
    private static final Converter NULL_CONVERTER=new NullConverter();
    // Unless specified by the child classes explicityly the last Converter in the chain is a 
    // NullConverter.
    private Converter nextConverter=NULL_CONVERTER;
    
    /** Creates a new instance of ConverterBase */
    public ConverterBase() {
    }
    
    /** Constructor that takes the next Converter in the decorator chain*/
    public ConverterBase(Converter nextConverter) {
        this.nextConverter=nextConverter;
    }
    
    
    /** This method calls the decorator chain of Converters.  In general the last Converter in the chain 
     * takes the first action, and the first converters in the chain act on this methods return value
     * and not the inputObj local variable.
     */
    protected Object decoratorConvert(Object inputObj) {
        return nextConverter.convert(inputObj);
    }
    /* Factory method that returns a useable instance of this class.  It is a factory method that works conceptually
     * like clone(). The child class does not override this method but instead overrides the createInstance method that
     * takes the nextConverter.  
     */
    public Converter createInstance() {
        return createInstance(nextConverter.createInstance());
    }
    
    /** This method returns the usable copy of this object.   Note it is passed the next Converter so it can recreate
     * the whole chain of converters in the copied/clone/returned instance.
     */
    abstract protected Converter createInstance(Converter nextConverter);
    
    
}
