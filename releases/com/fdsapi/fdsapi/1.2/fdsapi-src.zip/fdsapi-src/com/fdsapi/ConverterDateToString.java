/*
 * ConverterDateToString.java
 *
 * Created on February 22, 2005, 11:06 AM
 */


package com.fdsapi;

import java.util.*;
import java.text.*;
import com.fdsapi.*;

/** <p>This class takes a Date Object and formats it into a String with a DateFormat object.</p>
 *
 * <p>Note due to its use of the nonthread safe class NumberFormat this class is NOT thread safe.  It could
 * be wrapped in a ThreadSafe object if this is important.  However when used with the ArrayConverter a
 * new Converter will always be created at the appropriate time and so the developer need not worry about it.  
 * If a converter is used as say an instance variable in another class then you would need to ensure that
 * a createInstance() is first called in a multithreaded environment.</p>
 *
 *  <p>
 *  <b>Sample call:</b><br><br><blockquote><code><pre>
 *  Converter converter=new ConverterNumToString();// default DateFormat including short date and time
 *  converter=new ConverterNumToString(DateFormat.getInstance());// same as default
 *  converter=new ConverterNumToString(DateFormat.getDateInstance());
 *  converter=new ConverterNumToString(DateFormat.getDateTimeInstance());
 *  ...
 *  </pre></code></blockquote></p>
 *
 *  <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ConverterDateToString.htm">View Code</a>
 */
public class ConverterDateToString extends ConverterBase {

    // Java object that formats dates.
    private DateFormat dateFormat;
    
    /** Creates a new instance of ConverterNumToString */
    public ConverterDateToString() {
        setDateFormat(DateFormat.getInstance());
    }
    
    /** Constructor that takes the formatter that will be used to format the date */
    public ConverterDateToString(DateFormat dateFormat) {
        setDateFormat(dateFormat);
    }
    
    /** Constructor that takes the next converter in the decorator chain */
    public ConverterDateToString(Converter nextConverter) {
        super(nextConverter);
        setDateFormat(DateFormat.getInstance());
    }

    /** Constructor that takes the DateFormat object that will be used as well as the 
     * next Converter that will be called in the decorator chain. */
    public ConverterDateToString(DateFormat dateFormat, Converter nextConverter) {
        super(nextConverter);
        setDateFormat(dateFormat);
    }
    
    private void setDateFormat(DateFormat dateFormat) {
        this.dateFormat=dateFormat;
    }
        
    
    
    /* Converts an input Date object to a string based on the DateFormat class that backs the ConverterDateToString. This class/method is not
     * thread safe due to the fact that the backing DateFormat object is not thread safe.  createInstance() should always be called first or a new
     * object created in a multithreaded environment. This method should take a Date object.  If any other Object is input then it is simply
     * returned unchanged.
     */
    public Object convert(Object inputObj) {
       // Note this method essentially calls the decorator chains convert method first.
       inputObj=decoratorConvert(inputObj); 
       
       // Data input validation - if the passed object is null it is ok, but no logic needs to be performed. 
       if (inputObj==null)
         return null;
       else if (inputObj instanceof Date)
         return dateFormat.format(inputObj);
       else
         return inputObj;
    }
    
    
    /* Make a copy of whatever DateFormat is in this instance.  This method is used as
     * a factory.  The DateFormat class is not thread safe, so each converter must be sure
     * to return a new copy.
     */
    private DateFormat cloneDateFormat() {
        return (DateFormat) dateFormat.clone();
    }
    
    /** Creates a cloned/copy of this Object. This method is called by the parent class */
    protected Converter createInstance(Converter nextConverter) {
        return new ConverterDateToString(cloneDateFormat(), nextConverter);
    }
    
}
