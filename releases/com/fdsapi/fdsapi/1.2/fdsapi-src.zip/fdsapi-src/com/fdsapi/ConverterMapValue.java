/*
 * ConverterStringsFromMap.java
 *
 * Created on February 22, 2005, 11:00 PM
 */

package com.fdsapi;


import java.util.*;

/** <p>This class looks for the Object passed to the convert method in a HashMap and replaces this key with the 
 * associated value in the Map (if key then replace with value).  Note both key and value can be ANY Object type
 * or null.  </p>
 *
 *
 *  <p>
 *  <b>Sample call:</b><br><br><blockquote><code><pre>
 *  Map map=new HashMap();
 *  map.put(null,"&nbsp;");
 *  map.put("","&nbsp;");
 *  map.put(new Boolean(true),"yes");
 *  map.put(new Boolean(false),"no");
 *
 *  Converter converter=new ConverterMapValue(map);// default DateFormat including short date and time
 *  Object output=converter.convert(null);  // returns "&nbsp;" 
 *  ...
 *  </pre></code></blockquote></p>
 *
 *  <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ConverterMapValue.htm">View Code</a>
 */


public class ConverterMapValue extends ConverterBase {
    // map that contains the keys and values that should replace the keys.
    private Map map;
    /** Constructor that takes the map that the convert method uses to see what keys to replace with what value */
    
    public ConverterMapValue(Map map) {
        this.map=map;
        
    }
    
    /** Constructor that takes the map that the convert method uses to see what keys to replace with what
     ** values as well as the next Converter in the decorator chain.
     */
    public ConverterMapValue(Map map, Converter nextConverter) {
        super(nextConverter);
        this.map=map;
    }

    
    /* Converts an input Object that is the key in a Map to to an output Object that is the associated value
     * in the Map.  If the passed input Object is not in the Map then the input Object is simply returned.
     */    
    public Object convert(Object inputObj) {
        inputObj=decoratorConvert(inputObj);
        
        if (map.containsKey(inputObj))
          return map.get(inputObj);
        else
          return inputObj;
    }
    
    /** Method that works like clone in that it returns a usable copy of the this Object */
    protected Converter createInstance(Converter nextConverter) {
        return new ConverterMapValue(map, nextConverter);
    }
    
    
}
