/*
 * ConverterNumToString.java
 *
 * Created on February 20, 2005, 5:42 PM
 */

package com.fdsapi;

import java.text.*;
import java.math.*;
import com.fdsapi.*;

/** <p>This class takes any Object the inherits from the Number class (BigDecimal, BigInteger,
 * Byte, Double, Float, Integer, Long, and Short) and converts it to a formatted
 * string based on the NumberFormat that is passed to the constructor or if the no arg constructor
 * is used based on the default NumberFormatter returned by NumberFormat.getInstance().  The following
 * give examples on how to construct this object.  </p>
 *
 * <p>Note due to its use of the nonthread safe class NumberFormat this class is NOT thread safe.  It could
 * be wrapped in a ThreadSafe object if this is important.</p>
 *
 *  <p>
 *  <b>Sample call:</b><br><br><blockquote><code><pre>
 *  Converter converter=new ConverterNumToString();// default NumberFormat
 *  converter=new ConverterNumToString(NumberFormat.getInstance());// same as default
 *  converter=new ConverterNumToString(NumberFormat.getNumberInstance());// default NumberFormat
 *  converter=new ConverterNumToString(NumberFormat.getCurrencyInstance());
 *  converter=new ConverterNumToString(NumberFormat.getIntegerInstance());
 *  converter=new ConverterNumToString(NumberFormat.getPercentInstance());
 *  Object obj=converter.convert(new Long(10000));// obj will have the String 10,000
 * 
 *  </pre></code></blockquote></p>
 *
 *  <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ConverterNumToString.htm">View Code</a>
 *
 */
public class ConverterNumToString extends ConverterBase {

    // Java class that formats numbers.
    private NumberFormat numberFormat;
    
    /** Creates a new instance of ConverterNumToString */
    public ConverterNumToString() {
        setNumberFormat(NumberFormat.getInstance());
    }
    
    /** Constructor that takes the NumberFormat that will be used to format the Number object passed
     ** to the convert method.
     **/
    public ConverterNumToString(NumberFormat numberFormat) {
        setNumberFormat(numberFormat);
    }

    /** Constructor that takes the next Converter in the decorator chain */
    public ConverterNumToString(Converter nextConverter) {
        super(nextConverter);
        setNumberFormat(NumberFormat.getInstance());
    }

    /** Constructor that takes the formatter that will be used by convert to format the number as 
     * well as the next Converter in the decorator chain.
     */
    public ConverterNumToString(NumberFormat numberFormat, Converter nextConverter) {
        super(nextConverter);
        setNumberFormat(numberFormat);
    }
    
    private void setNumberFormat(NumberFormat numberFormat) {
        this.numberFormat=numberFormat;
    }
    
    /* Converts an input object that inherits from java.lang.Number to a formatted String.  For example
     * 10000 could be formatted as the String 10,000.  Note nulls or objects that are not inherited
     * from java.lang.Number will be returned unchanged.
     */
    public Object convert(Object inputObj) {
       // Note this method essentially calls the decorator chains convert method first.
       inputObj=decoratorConvert(inputObj); 
       // Data input validation - if the passed object is null it is ok, but no logic needs to be performed. 
       if (inputObj==null)
         return null;
       else if (!(inputObj instanceof Number)) 
         return inputObj;

       // The format method below takes either a double or a long as an arg.  Technically I would think 
       // a BigDecimal or BigInteger could overflow.  
       if (inputObj instanceof Float || inputObj instanceof Double || inputObj instanceof BigDecimal) {
          double value=((Number) inputObj).doubleValue();
          return numberFormat.format(value);        
       } else { // Integer, Long, Short, Byte, BigInteger
          long value=((Number) inputObj).longValue();
          return numberFormat.format(value);        
       }
    }
    
    
    /* Make a copy of whatever NumberFormat is in this instance.  This method is used as
     * a factory.  The NumberFormat class is not thread safe, so each converter must be sure
     * to return a new copy.
     */
    private NumberFormat cloneNumberFormat() {
        return (NumberFormat) numberFormat.clone();
    }

    /** Called by the parent class when a createInstance() is called to make a copy of this Object */
    protected Converter createInstance(Converter nextConverter) {
        return new ConverterNumToString(cloneNumberFormat(), nextConverter);
    }
    
}
