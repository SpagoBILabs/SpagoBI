package com.fdsapi;  // FormattedDataSet API


/**

This class is used to represent an x, y coordinate system by the FormattedDataSet API at runtime 
to find which DataSet's are registered at a particular coordinate.  For example x can correspond to a row 
and y a column.  This object is used to look up other objects in the HashMap.  

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/Coordinate.htm">View Code</a>
*/

public class Coordinate extends java.lang.Object
{
/**
The x coordinate in an x, y coordinate system. 
*/
public int x;

/**
The y coordinate in an x, y coordinate system. 
*/
public int y;

public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;
}


/**
This method is called automatically by a HashMap when this class is used as a HashMap key.  A Coordinate is
considered equal if its x and y variables have the same value.
*/

public boolean equals(Object compareKey) {

  return (compareKey instanceof Coordinate && 
          x==((Coordinate) compareKey).x && 
        y==((Coordinate) compareKey).y);

}


/**
This function implements the flyweight pattern.  This patterns is used to reduce the number of Coordinate 
objects that need to be created.  Instead of calling new Coordinate(), setValue() can be called instead.  
The flyweight pattern is documented in the "Design Patterns" book by Gamma, Helm, Johnson and 
Vlissides and published by Addison Wesley.  
*/

public Coordinate setValues(int x, int y) {
 this.x = x;
 this.y = y;

 return this;
}


/**
The hashCode function is used by a HashMap to help find a value associated with a key.  
The hash value doesn't need to be unique, but uniqueness improves performance.  The technique of 
multiplying the integers by primary numbers was taken from Java 2 by Ivor Horton.
*/

public int hashCode() {

  return (13*x + 17*y);

}


public String toString() {
 return "\n"+Integer.toString(x)+" "+Integer.toString(y);
}
}

