package com.fdsapi;  // FormattedDataSet API

import java.sql.*;
/** Interface used to abstract connection to a JDBC source.  This allows the FormattedDataSet to make
 jdbc calls on behalf of the developer, whether they are using a J2EE DataSource or a non-pooled JDBC
 connection.

 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataAccess.htm">View Code</a>
 */

public interface DataAccess 
{
    public DataAccess createInstance() throws SQLException;
    public void setDataSourceName(String dataSourceName);
    public String getDataSourceName();
    public Connection getConnection() throws SQLException;
    public void close() throws SQLException;
    public void closeConnection() throws SQLException;
    public void closeResultSet() throws SQLException;
    public void closeStatement() throws SQLException;
    public boolean connectionIsClosed() throws SQLException;
    public ResultSet getResultSet(String queryCommand) throws SQLException;
    public ResultSetConverter getResultSetConverter(String queryCommand) throws SQLException;
    public int executeUpdate(String updateCommand) throws SQLException;
}

