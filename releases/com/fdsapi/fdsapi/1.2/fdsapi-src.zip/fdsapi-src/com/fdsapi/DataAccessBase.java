package com.fdsapi;  // FormattedDataSet API


import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jamonapi.*;

/** 
 <p>This class is used to connect to a database server and execute SQL against that server.  This
class can be used in any Java code including EJB's. </p>

<p>Some background information about the java.sql.Statement class
Statement - can perform selects, updates, deletes, insert and call stored procs.
If you want to use IN parameters (i.e. ?) then you should use PreparedStatement and if
you want to use OUT parameters you should use CallableStatement.</p>

<p>All of the following will close any of the statements open result sets.</p>

Statement.executeQuery() - returns a single result set.<br>
Statement.executeUpdate() - performs inserts, deletes, updates and DDL.  returns number of rows 
    affected.<br>  
Statement.execute() - can return multiple result sets or update counts.<br>
Statement.close() - automatically closes any open ResultSet.  Statements are closed 
    automatically by the garbage collector.  However it is good practice to close 
    them explicitly.<br>

<p>Connections, ResultSets and Statements are all automatically closed by the garbage collector,
however it is good practice to close them explicitly.</p>

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataAccessBase.htm">View Code</a>

*/
public abstract class DataAccessBase extends java.lang.Object implements DataAccess
{
  protected Connection connection;
  protected Statement statement;
  protected ResultSet resultSet;
  private String dataSourceName;

public void setDataSourceName(String dataSourceName) {
    this.dataSourceName=dataSourceName;
}


public String getDataSourceName() {
    return dataSourceName;
}

protected Statement createStatement() throws SQLException {

    Monitor mon=start("createStatement()");
    try {
      return connection.createStatement();
    }
    finally {
      mon.stop();
    }

}



protected Monitor start(String locator) {
    return AppConstants.start("DataAccess."+locator);
}    


protected ResultSet executeQuery(String query) throws SQLException {

    Monitor mon=start("executeQuery(sql)");
    try {
      return statement.executeQuery(query); // never returns null.
    }
    finally {
      mon.stop();
    }

}


public void close() throws SQLException {
    Monitor mon=start("close()");
    try {
      closeResultSet();
      closeStatement();
    }
    finally {
      closeConnection(mon);
    }
}

 /** Used to ensure that a monitor is stopped even if an exception is thrown in the close method */
private void closeConnection(Monitor mon) throws SQLException {
    try {
        closeConnection();
    } finally {
        mon.stop();
    }
}
   

public void closeConnection() throws SQLException {
    Monitor mon=start("closeConnection()");
    try { 
      if (!connectionIsClosed()) {
        connection.close();
        connection = null;
      }
    }
    finally {
      mon.stop();
    }
}

public boolean connectionIsClosed() throws SQLException {
    return (connection==null || connection.isClosed());
}



public void closeResultSet() throws SQLException {

    Monitor mon=start("closeResultSet()");
    try {
       if (resultSet!=null) {
         resultSet.close();
         resultSet = null;
       }
    }
    finally {
      mon.stop();
    }
}

public void closeStatement() throws SQLException {

    Monitor mon=start("closeStatement()");
    try {
       if (statement!=null) {
         statement.close();
         statement = null;
       }
    }
    finally {
      mon.stop();
    }
}



public ResultSet getResultSet(String queryCommand) throws SQLException {

    Monitor mon=start("getResultSet(sql)");
    try {
        connection = getConnection();
        statement  = createStatement();
        resultSet  = executeQuery(queryCommand);  
        return resultSet;
    }
    finally  {
        mon.stop();
    }

}


public ResultSetConverter getResultSetConverter(String query) throws SQLException {
    Monitor mon=start("getResultSetConverter(query)");;
    try {
        ResultSet rs = getResultSet(query);  // never returns null.
        return new ResultSetConverter(rs);
     }
     finally {
       close(mon);  
     }
}

/** Used to ensure that a monitor is stopped even if an exception is thrown in the close method */
private void close(Monitor mon) throws SQLException {
    try {
        close();
    } finally {
        mon.stop();
    }
}

/*
Executes an SQL INSERT, UPDATE or DELETE statement. In addition, SQL statements that return nothing, such as SQL DDL statements, can be executed.
Parameters:

sql - an SQL INSERT, UPDATE or DELETE statement or an SQL statement that returns nothing

Returns:

    either the row count for INSERT, UPDATE or DELETE statements, or 0 for SQL statements that return nothing
*/
public int executeUpdate(String sql) throws SQLException {

    Monitor mon=start("executeUpdate(sql)");
    try {
        connection = getConnection();
        statement  = createStatement();
        int rowCount   = statement.executeUpdate(sql);
        return rowCount;
    }
    finally  {
       close(mon);
    }


}   
}

