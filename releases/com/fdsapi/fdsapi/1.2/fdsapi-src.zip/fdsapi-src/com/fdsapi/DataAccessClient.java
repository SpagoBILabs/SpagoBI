package com.fdsapi;  // FormattedDataSet API


import java.sql.*;
import com.jamonapi.*;
import java.util.*;

/** <p>Class used to connect to a JDBC data source using direct JDBC connections in lieu of javax.sql.DataSource.
 *  Sample creation of a DataAccess object in Sybase, and MySQL:</p> 
 *
 *  <blockquote><code><pre>
 *  DataAccess da=null;
 *
 *  // Sybase ASE database server
 *  da = new DataAccessClient("com.sybase.jdbc2.jdbc.SybDriver", "jdbc:sybase:Tds:sc2000:5000/databasename", "myusername", "mypassword", false);
 *
 *  // Sybase ASA database server (Note that it is same as ASE)
 *  da = new DataAccessClient("com.sybase.jdbc2.jdbc.SybDriver", "jdbc:sybase:Tds:127.0.0.1:2638/ASADemoDB", "myusername", "mypassword", false);
 *  
 *  // MySQL database server.  Alternative constructor.
 *  da=new DataAccessClient("com.mysql.jdbc.Driver", "jdbc:mysql://localhost/databasename?user=root", false);
 *
 * </pre></code></blockquote>
 *
 *  <p>Note the boolean cacheConnection determines if the connection should be closed after each db interaction.  For
 *  example when a ResultSet is retrieved.  Setting the boolean to true caches the connection (i.e. leaves it open).  Note this class 
 *   is not thread safe and a DataAccessClient would have to be created for each Thread.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataAccessClient.htm">View Code</a>
 */

public class DataAccessClient extends DataAccessBase
{
 private String dbDriver;   // i.e. "com.sybase.jdbc2.jdbc.SybDriver"
                            // or "oracle.jdbc.driver.OracleDriver"
 private String dbUrl;  // "jdbc:sybase:Tds:sc2000:5000/databasename"
                        // or "jdbc:oracle:thin:@:host:port
 private String userName;
 private String passWord;
 private Properties info;
 private boolean cacheConnection=true;
 // the following booleans are used to determine which getConnection() method to call
 private boolean fromUserName=false;
 private boolean fromUrl=false;
 private boolean fromProperties=false;

 /* provide username, password */
 public DataAccessClient(String dbDriver, String dbUrl, String userName, String passWord, boolean cacheConnection) throws SQLException {
     this(dbDriver, dbUrl, userName, passWord, null, cacheConnection); // call private constructor
 }


  /** Provide url only, which will include the username and password.  */
  public DataAccessClient(String dbDriver, String dbUrl, boolean cacheConnection) throws SQLException {
     this(dbDriver, dbUrl, null, null, null, cacheConnection);
  }

  /** provide Properties */
  public DataAccessClient(String dbDriver, String dbUrl, Properties info,  boolean cacheConnection) throws SQLException {
     this(dbDriver, dbUrl, null, null, info, cacheConnection);

  }

  private DataAccessClient(String dbDriver, String dbUrl, String userName, String passWord, Properties info, boolean cacheConnection) throws SQLException {

   try {     
     this.dbDriver=dbDriver;
     this.dbUrl=dbUrl;
     this.userName=userName;
     this.passWord=passWord;
     this.info=info;
     this.cacheConnection=cacheConnection;

     // this info is used to determine what getConnection() method to call
     if (userName!=null && passWord!=null)
       fromUserName=true;
     else if (info==null)
       fromProperties=true;
     else
       fromUrl=true;

     Class.forName(dbDriver);
   } catch (ClassNotFoundException e) {
        throw new SQLException(
         "DataAccessClient message="+e.getMessage());
    }

 }


 /** Factory method that allows this class to clone itself */
 public DataAccess createInstance() throws SQLException {
     if (cacheConnection)
       return this;
     else
       return new DataAccessClient(dbDriver, dbUrl, userName, passWord, info, cacheConnection);

 }



/** Get database connection */

public Connection getConnection() throws SQLException {
    Monitor mon=start("Client.getConnection()");
    try {
        if (connectionIsClosed()) {
            if (fromUserName)           
                connection = DriverManager.getConnection(dbUrl, userName, passWord);
            else if (fromUrl)
                connection = DriverManager.getConnection(dbUrl);
            else if (fromProperties)
                connection = DriverManager.getConnection(dbUrl, info);
            else 
                throw new SQLException("DataAccessClient message=Invalid connection parm");

        }
    }
    finally {
       mon.stop();
    }

    return connection;

}


/** Close open Statements, ResultSets and the Connection */
public void close() throws SQLException {

    Monitor mon=start("close()");
    try {
      closeResultSet();
      closeStatement();
    }
    finally {
      if (!cacheConnection)
        closeConnection();

      mon.stop();
    }

}
}

