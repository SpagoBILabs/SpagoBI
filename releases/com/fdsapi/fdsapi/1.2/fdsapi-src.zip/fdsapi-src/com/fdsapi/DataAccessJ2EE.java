package com.fdsapi;  // FormattedDataSet API


import java.sql.*;
import javax.naming.*;
import javax.sql.DataSource;

import com.jamonapi.*;

/** <p>Class used to connect to a JDBC data source in a J2EE environment using javax.sql.DataSource.  
 *  For example in Sybase:</p> 
 *
 *  // This maps to the jndi resource reference of "jdbc/MyDataSource"<br>
 *  DataAccess da=new DataAccessJ2EE("MyDataSource");  <br>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataAccessJ2EE.htm">View Code</a>
 */


public class DataAccessJ2EE extends DataAccessBase
{
private DataSource dataSource;
private InitialContext initialContext;

/** Use when InitialContext doesn't use the default constructor (for example when a username and password are 
 *  required in the InitialContext constructor.  The dataSourceName maps to the applications DataSource in the jndi
 *  namespace.
 */
public DataAccessJ2EE(InitialContext initialContext, String dataSourceName) {
        setDataSourceName(dataSourceName);
        this.initialContext=initialContext;
}

/** Use when InitialContext uses the default constructor.  The dataSourceName maps to the applications 
 *  DataSource in the jndi namespace.
 */
public DataAccessJ2EE(String dataSourceName) throws SQLException {
    this(createInitialContext(), dataSourceName);
}

/** Use when InitialContext uses the default constructor, and the default DataSource name should be used.  
 *  The dataSourceName maps to the applications DataSource in the jndi namespace.  The default DataSource name
 *  is "DataSource".
 */

public DataAccessJ2EE() throws SQLException {
    this(createInitialContext(), AppConstants.DATASOURCE);
}


private static InitialContext createInitialContext() throws SQLException {
 try {
     return new InitialContext();
   } catch (NamingException e) {
        throw new SQLException(
         "DataAccessJ2EE NamingException message="+e.getMessage());
    }
}

 public DataAccess createInstance() throws SQLException {
     return new DataAccessJ2EE(initialContext, getDataSourceName());

 }



private DataSource getDataSource() throws SQLException {
    try {
     if (dataSource==null) 
        dataSource = (DataSource) initialContext.lookup("java:comp/env/jdbc/"+getDataSourceName()); 
    } catch (NamingException e) {
        throw new SQLException(
         "DataAccessJ2EE NamingException dataSourceName="+getDataSourceName()+", message="+e.getMessage());
    }

    return dataSource;

}

public void  setDataSourceName(String dataSourceName) {
    super.setDataSourceName(dataSourceName);
    dataSource=null;
}



public Connection getConnection() throws SQLException {

    Monitor mon=start("J2EE.getConnection()");
    try {
       return getDataSource().getConnection();
    }
    finally {
       mon.stop();
    }

}
}

