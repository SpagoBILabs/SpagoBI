package com.fdsapi;  // FormattedDataSet API


/** <p>Used to iterate through TabularData objects.  The DataIterator allows the code 
 * to iterate through any form of TabularData (ResultSets, 2 dimensional arrays, ...) with the same
 * code.</p>
 *
 * <p>Note the Java Iterator and Enumerators objects move through the data AND can get the next value also.  
 * The DataIterator can only move through the data.  The TabularData interface has the responsibility of
 * getting the values.  DataIterator's are used to loop through all types of data while keeping track of 
 * the current index.  Iterators and Enum's don't track the current index.</p>
 *
 *<p>Note iteration starts at 1, not 0.  This is even true for data that typically starts at 0 such as 2 dimensional
 * arrays.  This allows the abstraction to be the same for all types of TabularData<p>
 * 
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataIterator.htm">View Code</a>
 */


public interface DataIterator extends java.io.Serializable 
{
    /** Returns the number of the current item.  For example if we are iterating rows then and the current 
     * row was 5 then 5 would be returned.  The current item can be 1 or greater 
     */
    public int getCurrentItemNumber();
    /** Move to the next item.  It returns false when there was no next item (i.e. it has reached the end) */
    public boolean next();
}

