package com.fdsapi;  // FormattedDataSet API


/** <p>Used to iterate through TabularData objects.  The DataIterator allows the code 
 * to iterate through any form of TabularData (ResultSets, 2 dimensional arrays, ...) with the same
 * code.  This class is used to iterate throught a TabularData object when the number of items it contains
 * are known in advance (2 dim arrays satisfy this criterion, but ResultSets do not as you don't know how
 * many rows are in a ResultSet).</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataIteratorBase.htm">View Code</a>
 *
 */

public class DataIteratorBase extends java.lang.Object implements DataIterator
{
private int currentItemNumber=0;  
private int numberOfItems=1; 

protected DataIteratorBase() {
}

/** Number of items that need to be iterated over */
protected DataIteratorBase(int numberOfItems) {
    this.numberOfItems = numberOfItems;
}

/**
Gets the total number of items in the DataSet.
*/
protected int getNumberOfItems() {
    return numberOfItems;
}


/*Get the current item number within the DataSet.  */
public int getCurrentItemNumber() {
    return currentItemNumber;
}

/**Sets the current item number within the DataSet */
protected void setCurrentItemNumber(int currentItemNumber) {
    this.currentItemNumber=currentItemNumber;
}


/**Returns true if there are more items in the DataSet and also moves the internal pointer of the 
 * DataSet to the next available item.
 */


public boolean next() {

    // if there are no more items return false
    if (getCurrentItemNumber()>=getNumberOfItems()) {
            setCurrentItemNumber(0);
            return false;
        }
    else  { // if there are more items return true. 
            setCurrentItemNumber(getCurrentItemNumber()+1);
            return true;
        }
}
}

