package com.fdsapi;  // FormattedDataSet API


import java.sql.ResultSet;

/** <p>Used to iterate through ResultSet TabularData objects.  DataIteratorBase can not be used as
  * the number of items in a ResultSet are not known in advance.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataIteratorResultSetRow.htm">View Code</a>
 */
public class DataIteratorResultSetRow extends DataIteratorBase
{
 ResultSet data;


  protected DataIteratorResultSetRow(ResultSet data)   {
      this.data = data;
  }


 public boolean next() {
    try {
        boolean moreData = data.next();

        if (moreData)
            setCurrentItemNumber(getCurrentItemNumber()+1);
        else
            setCurrentItemNumber(0);

        return moreData;
     } catch (Exception e) {
           throw new RuntimeExceptionBase("Iteration error during ResultSet.next() "+
            "ResulSet="+data+", currentItemNumber="+getCurrentItemNumber(), e);
    }

 }
}

