package com.fdsapi;  // FormattedDataSet API



import java.util.Map;
import com.jamonapi.utils.*;

/**
 <p>This class represents a command to be issued gainst TabularData.   The command can take any action against
 the TabularData.  The current actions all render text, however the DataSet execute() method is generic 
 and so can execute any command.  DataIterator iterates through TabularData executing commands against it vi 
 the DataSet.  DataIterator, TabularData, and DataSets together execute the Gang of 4 Iterator and Command 
 design patterns.  They are also the most fundamental objects behind the FormattedDataSet.</p>
 
 <p>Template objects contain multiple DataSet's.  A DataSet is mapped to a Template tag via Template files/strings.  
 For example you can map a particular DataSet (i.e. command) to a column of the TabularData.</p>
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSet.htm">View Code</a>
*/
public abstract class DataSet extends java.lang.Object implements Cloneable
{
protected TemplateVariables variables;  // ##variables from template
protected DataSetParm dataSetParm;  // various parameters such as the TabularData that are shared in a Template Objects DataSet's
protected String templateTagType;// The type that is associated with the particular DataSet.

/** Increment the underlying TabularData's iterator */
public boolean next() {
    return dataSetParm.getDataIterator().next();
}

/** A Factory method that creates a clone of this DataSet with whatever data that makes this instance unique .*/
public DataSet createFactoryInstance(DataSetFactoryParm parm) {
    DataSet dataSet = createFactoryInstance();
    dataSet.variables = parm.getVariables();
    dataSet.templateTagType=parm.getTemplateTagType();

    return dataSet;
}


/** A Factory method that creates a clone of this DataSet (see gang of 4 "Factory method" pattern).  
 This allows the type of DataSet to be determined at runtime.
 */
 abstract public DataSet createFactoryInstance();


/** Method that sets the DataSetParm for the DataSet instance.
 */
public void setDataSetParm(DataSetParm dsp) {
    try {
        dataSetParm = (DataSetParm) dsp.clone();    
        dataSetParm.setDataIterator(createDataIterator());
    } catch (Exception e) {
       throw new RuntimeExceptionBase("Failure in setting DataSetParms: ", e);
    }

}

/** Log to the standard logging device */
protected void log(String logStr) {
    Utils.logDebug(logStr);
}


/** Iterator factory method */
public DataIterator createDataIterator() {
    return new DataIteratorBase();
}


/**
<p>Note clone() returns a shallow copy of the object.  This means the cloned instance variables of a DataSet will only
clone the references not the underlying objects.  When instance variables are stateless this works ok, but a deeper
copy will have to be implemented if the instance variables are stateful.  </p>

<p>This is an implementation of the Prototype factory pattern as discussed in the Erich Gamma Design Patterns book.</p>

<p>The CloneNotSupportedException could only be thrown if this class didn't implement the Cloneable tag interface.</p>

*/
public Object clone() throws CloneNotSupportedException {
    // makes an exact duplicate of the object with any object references still pointing to the original classes
    // objects.
    DataSet dataSet = (DataSet) super.clone(); 
//    dataSet.dataSetParm = (DataSetParm) dataSetParm.clone();

    return dataSet;
}


/** Execute a command against the specified index.  Index can represent a particular column, cell or other entity */
public abstract void execute(int y);    



/**
This function should be implemented in DataSetDecorator class for the client program to call to get the process 
started.  After the first call the execute(int) method will be called.
*/
public Object execute() {
    return this;
}


/** by default does nothing.  DataSetDecorators provide real behaviour. */
 protected void initialize(String templateContents) {
     
  }
 
 /** <p>Return the value of a template variable.  It will bring back the variable with any of the dynamic
  *  portions populated. For example given the following template variable:
  *  <p>myVariable==##2, ##1</p>
  *  <p>and given the following 2 column row from the tabular data:</p>
  *  Steve Souza<br><br>
  *  <p><blockquote><code><pre><code>String value=getVariableValue("myVariable");  // value will contain "Souza, Steve"</p></pre></code></blockquote>
  *  
  *  Note the variable name is case insensitive.
  */  
 
 protected String getVariableValue(String variableName) {
    return variables.getVariableValue(variableName, dataSetParm);
 }
 
 /** <p>Convenience method that gets the TemplateVariables object associated with the DataSet.</p>
  */   
 protected TemplateVariables getTemplateVariables() {
     return variables;
 }
 
 /** <p>Convenience method that gets the DataSetParm object associated with the DataSet.  DataSetParm has contains TabularData
  * and the StringBuffer that is written too among other things.  There are other convenience methods that make getting
  * information form DataSetParm more direct.
  </p>
  */   
 protected DataSetParm getDataSetParm() {
     return dataSetParm;
 }
 
 /** <p>Convenience method that gets the underlying TabularData object that the DataSet is working on.  
  * There are other convenience methods that make dealing with TabularData objects more direct.</p>
  */   
 protected TabularData getTabularData() {
     return dataSetParm.getTabularData();
 }

 /*<p>Convenience method that makes getting the current cell data easier.  This is simply a call to 
  * the DataSets TabularData object.
  *</p>
  */
 protected Object getCellData() {
     return getTabularData().getCellData();
 }

  /*<p>Convenience method that makes getting to user defined variables easier.</p>
  */

 protected Map getMiscDataMap() {
     return dataSetParm.getMiscDataMap();
 }

  /*<p>Convenience method that makes getting to the DataSets StringBuffer which is used to output the DataSets text.
   </p>
  */
 
 protected StringBuffer getStringBuffer() {
     return dataSetParm.getStringBuffer();
 }
 
 


public String toString() {
    return dataSetParm.getStringBuffer().toString();
}
}

