package com.fdsapi;  // FormattedDataSet API

/** Used as base class for anyone adding a DataSet.
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetBase.htm">View Code</a>
 */
public abstract class DataSetBase extends DataSet {
    
}
