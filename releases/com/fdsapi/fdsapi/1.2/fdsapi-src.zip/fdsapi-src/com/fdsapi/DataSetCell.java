package com.fdsapi;  // FormattedDataSet API


/**
<p>Used to display TabularData cells.  This class is part of the DataSet classes used to display FormattedDataSets.</p>

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCell.htm">View Code</a>
*/

public class DataSetCell extends DataSetCellBase
{
protected DataSetCell() {

}

/** Factory method that creates a new DataSetCell object */
public DataSet createFactoryInstance() {
    return new DataSetCell();
}


/** <p>Method that appends a TabularData cell to the FormattedDataSet text buffer for output.  The index y
 * represents the yth column of the current row of TabularData with indexing starting at 1 (not 0). </p>
 * 
 *<p>For example if the data was String[][] arr={{"(1,1)", "(1,2)"},{"(2,1)", "(2,2)"},};<br>
 * and the current fow was 1 then execute(2) would concatenate "(1,2" to the buffer.</p>
*/
 public void execute(int y)  {
  dataSetParm.getStringBuffer().append(dataSetParm.getTabularData().getCellData());  // returns y column of result sets current row
 }
}

