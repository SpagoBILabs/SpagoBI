package com.fdsapi;  // FormattedDataSet API

/** <p>Used when different text is required for every other row or cell (or any other Template Tag).  
 Sample use in a template that would use a stylesheet entry of to specify different colors for odd and 
 even rows.</p>

&lt;!-- BODY_ROW_PREFIX -->Type==Alternating<br>
Odd==    &lt;tr class="odd"><br>
Even==    &lt;tr class="even"><br>
&lt;!-- BODY_ROW_PREFIX --><br><br>

Every odd row will use &lt;tr class="odd">, and every even row will use &lt;tr class="even">

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellAlternating.htm">View Code</a>
*/
public class DataSetCellAlternating extends DataSetCellBase {
    
    
    public DataSet createFactoryInstance() {
        return new DataSetCellAlternating();
    }
    
    private String getEven() {
        return variables.getVariableValue("Even", dataSetParm);
    }
    
    private String getOdd() {
        return variables.getVariableValue("Odd", dataSetParm);
    }

    /** 
    Use modulo math to determine if this element (which could be a row, col etc) is odd or even and take
    appropriate action by placing the "odd" or "even" template variable contents into the text buffer.
    */
    public void execute(int y) {
        if (y%2==0) // even
          dataSetParm.getStringBuffer().append(getEven());
        else // odd
          dataSetParm.getStringBuffer().append(getOdd());
        
    }
    
}
