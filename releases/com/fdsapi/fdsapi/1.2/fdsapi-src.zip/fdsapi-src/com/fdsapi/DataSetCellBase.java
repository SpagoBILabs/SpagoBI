package com.fdsapi;  // FormattedDataSet API


/** Base class for DataSets that increments data by default for template tags that end in "_data".   The primary added behaviour is to increment data 
 * by default for any template tag type ending in _DATA (i.e. body_cell_data, body_row_data,...)
 * Any template tag type that does not in in _DATA defaults to false (i.e. body_cell_prefix, body_row_suffix )
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellBase.htm">View Code</a>
 */

public abstract class DataSetCellBase extends DataSet
{
    /** Returns true if the template tag is supposed to increment the underlying TabularData */
    public boolean getIncrementData() {
        String incrementDataStr=variables.getIncrementData(dataSetParm);

        if (TemplateConstants.TRUE.equalsIgnoreCase(incrementDataStr))
            return true;
        else if (TemplateConstants.FALSE.equalsIgnoreCase(incrementDataStr))
            return false;
        else
            return getIncrementDataDefault();
    }

    private static String DATA=TemplateConstants.DATA.toUpperCase();

    /** Any template tag type that ends in _DATA defaults to incrementing the data.(i.e. body_cell_data, body_row_data,...)
     * Any template tag type that does not in in _DATA defaults to false (i.e. body_cell_prefix, body_row_suffix).
     */
    private boolean getIncrementDataDefault() {
        return templateTagType.toUpperCase().endsWith(DATA);
    }

    /** Returns the type of DataSet.  For example "Alternating". */
    public String getType() {
        return variables.getType();
    }


    
    /** Return the appropriate DataIterator based on whether or not the data should be incremented or not. */
    public DataIterator createDataIterator() {

        if (getIncrementData())
            return dataSetParm.getTabularData().getColIterator();
        else
            return super.createDataIterator();
    }
}

