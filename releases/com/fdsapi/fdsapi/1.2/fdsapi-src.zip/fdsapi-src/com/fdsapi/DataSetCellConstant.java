package com.fdsapi;  // FormattedDataSet API


/** <p>DataSet type Constant.  It is used in Templates that have a combination of text and dynamic data. Note when a Type is 
  not specifically mentioned the default will be "Constant".</p>
 *
 * <p>Assuming column 1 had the value Steve and Column 2 had the value Souza, the following Template Tag would
 * result in "Souza, Steve"<br>
 * &lt;!-- BODY_CELL_DATA --&gt;##2, ##1&lt;!-- BODY_CELL_DATA --&gt;
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellConstant.htm">View Code</a>
 */
public class DataSetCellConstant extends DataSetCellBase
{
  protected DataSetCellConstant() {
  }


 /** Factory method */
 public DataSet createFactoryInstance() {
    return new DataSetCellConstant();
 }



/** Replace the constant with runtime template tag vairables and append this result to the buffer text stream */
public void execute(int y)  {
    dataSetParm.getStringBuffer().append(variables.getValue(dataSetParm));  // returns y column of result sets current row
}

public Object execute() {
    return variables.getValue(dataSetParm);
}
}

