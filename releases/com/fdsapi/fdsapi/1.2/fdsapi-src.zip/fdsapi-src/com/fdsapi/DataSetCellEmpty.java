package com.fdsapi;  // FormattedDataSet API


/** This is a null object DataSet.  i.e. it does nothing.
 
<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellEmpty.htm">View Code</a> 
 */

public class DataSetCellEmpty extends DataSetCellBase
{
   protected DataSetCellEmpty() {
   }

   public DataSet createFactoryInstance() {
      return new DataSetCellEmpty();
   }


  // because this dataset does nothing it can be a singleton.  i.e. it has no state.

   public void execute(int y)  {
    // this routine does nothing  used for prefixes, data and suffixes that are empty i.e. ""
   }
}

