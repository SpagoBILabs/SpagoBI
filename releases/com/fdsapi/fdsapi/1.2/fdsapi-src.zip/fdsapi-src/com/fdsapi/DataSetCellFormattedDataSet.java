package com.fdsapi;  // FormattedDataSet API


import com.jamonapi.utils.*;

/** DataSet used to create execute FormattedDataSet as a subquery to an outer call to FormattedDataSet. It is also
  used as a base class for some of the other DataSets that call methods like getDropDownListBox(...), and getListBox(...).
 *
 *<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellFormattedDataSet.htm">View Code</a>
 */
public class DataSetCellFormattedDataSet extends DataSetCellBase
{
    protected DataSetCellFormattedDataSet()     {
    }

    FormattedDataSet formattedDataSet = new FormattedDataSet();


    public DataSet createFactoryInstance() {
        return new DataSetCellFormattedDataSet();
    }


  /** Used for a template tag variable of structure "DataSource==myDataSource" or if not provided 
    * it defaults to DataSource
   */
    public String getDataSource() {
        return variables.getDataSource(dataSetParm);
    }

  /** Used for a template tag variable of structure "Query==select * from table where name='##this'"
   */
    public String getQuery() {
        return variables.getQuery(dataSetParm);
    }

  /** Used for a template tag variable of structure "Template==myTemplate".  This template is used to format 
   * the query.
   */
    public String getTemplate() {
        return variables.getTemplate(dataSetParm);
    }

    
  /** Used for a template tag variable of structure "Selected==##this".  For the DataSets that can select an
   item such as DataSetCellDropDownListBox it used to hilite the selected item.  
   */
    public String getSelected() {
        return variables.getSelected(dataSetParm);
    }


  /** Used for a template tag variable of structure "size==5" to size list boxes and drop down list boxes.
   */
    public int getSize() {
        return Integer.parseInt(variables.getSize(dataSetParm));
    }


    public void execute(int y)  {
        try {

            dataSetParm.getStringBuffer().append(
                formattedDataSet.getFormattedDataSet(
                    getDataSource(), // DataSource==myDataSource or it defaults to DataSource
                    getQuery(), // Query==select * from table
                    getTemplate())); // Template=myTemplate
        } catch (Exception e) {
            throw new RuntimeExceptionBase("Error in "+Misc.getClassName(this)+".execute("+y+")", e);
        }      


    }
}

