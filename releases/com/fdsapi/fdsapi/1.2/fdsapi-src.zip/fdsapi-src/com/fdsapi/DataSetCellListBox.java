package com.fdsapi;  // FormattedDataSet API


import com.jamonapi.utils.*;

/** DataSet used to create an HTML list box by executing the specified query. 
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellListBox.htm">View Code</a>
 */

public class DataSetCellListBox extends DataSetCellFormattedDataSet
{
protected DataSetCellListBox()
{

}


public DataSet createFactoryInstance() {
    return new DataSetCellListBox();
}


public void execute(int y)   {
    try {

        dataSetParm.getStringBuffer().append(formattedDataSet.getListBox(
            getDataSource(), // DataSource==myDataSource or it defaults to DataSource
            getQuery(), // Query==select * from table
            getSelected(), // selected==##1 - the item in the list box that will be hilited.
            getSize()));  // size==8 - the display size of the list box
        } catch (Exception e) {
            throw new RuntimeExceptionBase("Error in "+Misc.getClassName(this)+".execute("+y+")", e);
        }      


    }
}

