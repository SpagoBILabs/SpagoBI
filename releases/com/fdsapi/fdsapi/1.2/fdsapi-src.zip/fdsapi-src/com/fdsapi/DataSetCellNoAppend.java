package com.fdsapi;  // FormattedDataSet API


 /** This class is used when the tabularData object contains DataSets.  The appending of the stringBuffer occurs in the
  * tabularData.getCellData() method so the logic of a DataSetCell object would reappend the information. This method
  * simply calls getCellData() and lets it append the data.
  *
  * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellNoAppend.htm">View Code</a>
  */

public class DataSetCellNoAppend extends DataSetCellBase
{
 
protected DataSetCellNoAppend()
{

}


public DataSet createFactoryInstance() {
    return new DataSetCellNoAppend();
}

public void execute(int y) {
  // used to append data in DataSet[] in DataSetFactory.  i.e the side effect puts the string in the buffer.  
  dataSetParm.getTabularData().getCellData();  // returns y column of result sets current row
}
   
}

