package com.fdsapi;  // FormattedDataSet API


import com.jamonapi.utils.*;

/** DataSet used to create an HTML radio button by executing the specified query. 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCellRadioButton.htm">View Code</a>
 */

public class DataSetCellRadioButton extends DataSetCellFormattedDataSet
{
    protected DataSetCellRadioButton()
    {

    }


    public DataSet createFactoryInstance()     {
        return new DataSetCellRadioButton();
    }


    public void execute(int y) {

        try {
            dataSetParm.getStringBuffer().append(
                formattedDataSet.getRadioButton(
                    getDataSource(), // DataSource==myDataSource or it defaults to DataSource
                    getQuery(), // Query==select * from table
                    getSelected())); // selected==##1 - the item that will be selected.
        } catch (Exception e) {
            throw new RuntimeExceptionBase("Error in "+Misc.getClassName(this)+".execute("+y+")", e);
        }      

    }     
}

