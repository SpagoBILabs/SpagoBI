package com.fdsapi;  // FormattedDataSet API

/** DataSet used for columns.

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetCol.htm">View Code</a> 
 
 */
public class DataSetCol extends DataSetDecorator
{
protected DataSetCol() {
    super();
}



public DataSet createFactoryInstance() {
    return new DataSetCol();
}

/** DataSetCol uses the DataIterator from all of its member DataSets to figure out how to 
iterate through itself.  Due to this fact all member DataSets must have their DataIterators created before
the DataSetCol can.   At the time this code was written the ancestor class assumed the opposite of this,
so the code below does not call super.setDataSetParm(dsp).  This is a little ugly and so could use refactoring.
*/    
public void setDataSetParm(DataSetParm dsp) {
    try {
        dataSetParm = (DataSetParm) dsp.clone();    
        setDataSetParmForMap(dataSetParm);
        dataSetParm.setDataIterator(createDataIterator()); 
    } catch (Exception e) {
       throw new RuntimeExceptionBase("DataSetCol.setDataSetParm(...) exception",e);
    }

}    


public DataIterator createDataIterator() {
    return createColDataIterator();
}


private DataIterator createColDataIterator() {

    DataIterator columnIterator=dataSetParm.getTabularData().getColIterator();
    int numCols=0;  
    int i=1;

  // note this implies that all DataSets owned by must be of class type DataSetCellBase!
    DataSetCellBase dataSet;  

/* 
Some DataSetCellBase objects increment the tabular data and others don't.  For example a constant can either decrement
the tabular data current column number or not.  For example if you wanted to use a tabular column for other purposes
than display (i.e. to pass to a stored proc) you might want to increment it still.   The following logic loops figures out 
how many columns will be displayed in the DataSet.  For example say we have a 3 column tabular data set.  Also 
ConstantIncrement below represents a DataSetConstant with its incrementData property set to true and ConstantNoIncrement
represents a DataSetConstant with its incrementData property set to false.  #n represents the tabular data column number.

The following sets numCols to 3
#1    #2 #3 

The following sets numCols to 5
#1    #2 ConstantNoIncrement    ConstantNoIncrement    #3 

The following sets numCols to 3 (The last 2 columns would not be displayed.  This should really be an error 
condition.
#1    #2 ConstantIncrement    ConstantNoIncrement    #3 

numCols will be 4
#1    #2 ConstantNoIncrement ConstantIncrement 

*/
    try 
    {
        boolean moreCols = columnIterator.next();

        while(moreCols)  {
            dataSet = (DataSetCellBase) getDataSet(0,i++);
            numCols++;
            if (dataSet.getIncrementData())
                moreCols = columnIterator.next();
        }
    }
    catch (Exception e) {
        throw new RuntimeException("An Error occurred while iterating through TabularData's columns: "+e.getMessage());
    }

    DataIterator dataIterator = new DataIteratorBase(numCols);

    return dataIterator;
}


public boolean next(int x, int y) {
    // the next line increments tabulardata if that is required.
    data.getDataSet(x, y).next();    

    return next();
}
}

