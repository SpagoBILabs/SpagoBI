package com.fdsapi;  // FormattedDataSet API

/** DataSet used to take different action depending on the specified data.  Sample use in a template<br>

<br>&lt;!-- body_cell_data 0,9 -->Type==Conditional 
if==0 ifValue==0 elseValue==&lt;a href='Main?pageName=contractProductList>##this&lt;/a>&lt;!-- body_cell_data 0,9 -->

<br>if the value in the cell equals 0 the display 0, else display the given href

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetConditional.htm">View Code</a>
*/



public class DataSetConditional extends DataSetCellBase
{

	public DataSet createFactoryInstance() {
        return new DataSetConditional();
    }

    private String getIfCondition() {
        return variables.getVariableValue("if", dataSetParm);
    }

    private String getIfValue() {
        return variables.getVariableValue("ifValue", dataSetParm);
    }

    private String getElseValue() {
        return variables.getVariableValue("elseValue", dataSetParm);
    }


    public void execute(int y) {
		Object currentCell=dataSetParm.getTabularData().getCellData();

		if (currentCell==null || currentCell.toString().trim().equalsIgnoreCase(getIfCondition())) 		
			dataSetParm.getStringBuffer().append(getIfValue());
        else
			dataSetParm.getStringBuffer().append(getElseValue());
    }

}


