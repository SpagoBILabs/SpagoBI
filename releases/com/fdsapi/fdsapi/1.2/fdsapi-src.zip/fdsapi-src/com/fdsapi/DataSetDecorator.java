package com.fdsapi;  // FormattedDataSet API


/**
<p>This class is used to wrap prefixes and suffixes around a DataSet.  This is used to format a DataSet into HTML.  
The general concept is all dynamic HTML (whether it is a cell in a table, a row in a table, the table itself or 
even header information) contains a prefix, a value and a suffix.  </p>


<p>The DataSet heirarchy of objects uses the decorator and composite patterns from the "Design Patterns" book 
by Gamma, Helm, Johnson and Vlissides and published by Addison Wesley.  </p>

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetDecorator.htm">View Code</a> 

*/

public class DataSetDecorator extends DataSet
{
 private   DataSetMap prefix;  // Contains a map of prefixes for this formatter.
 protected DataSetMap data;  // Contains a map of prefixes for this formatter.
 private   DataSetMap suffix;  // Contains a map of suffixes for this formatter.

 protected DataSetDecorator()     {
 }


 public DataSet createFactoryInstance(DataSetFactoryParm dsfParm) {   
    DataSetDecorator dsd=(DataSetDecorator) createFactoryInstance();
    dsd.prefix = DataSetMap.createFactoryInstance(copyParm(dsfParm,TemplateConstants.PREFIX));
    dsd.data =   DataSetMap.createFactoryInstance(copyParm(dsfParm,TemplateConstants.DATA));
    dsd.suffix = DataSetMap.createFactoryInstance(copyParm(dsfParm,TemplateConstants.SUFFIX));

    return dsd;

}

 // clones the DataSetFactoryParm, but changes the templateTagType by appending either
 // prefix, data or suffix
 static private DataSetFactoryParm copyParm(DataSetFactoryParm dsfParm, String templateTagTypeLevel3) {
     // Ex. Take input of body_cell_ and append prefix to it to get body_cell_prefix
     String tagType=dsfParm.getTemplateTagType()+templateTagTypeLevel3;  // ex. body_cell_prefix
     return new DataSetFactoryParm(tagType, dsfParm.getTemplateContents(), dsfParm.getNextDataSet());
 }


public DataSet createFactoryInstance() {
    return new DataSetDecorator();
}



public Object clone() throws CloneNotSupportedException {
    // makes an exact duplicate of the object with any object references still pointing to the original classes
    // objects.
    DataSetDecorator dsd = (DataSetDecorator) super.clone();  
    dsd.prefix  = (DataSetMap) prefix.clone();
    dsd.data    = (DataSetMap) data.clone();
    dsd.suffix  = (DataSetMap) suffix.clone();

    return dsd;
}


public void setDataSetParm(DataSetParm dsp) {
    // copy arguments passed to the created dataSet for variables shared by ALL DataSet types
    super.setDataSetParm(dsp);
    setDataSetParmForMap(dsp);

}

    void setDataSetParmForMap(DataSetParm dsp) {
        prefix.setDataSetParm(dsp);
        data.setDataSetParm(dsp);
        suffix.setDataSetParm(dsp);
    }



 protected void initialize(String templateContents) {
      prefix.initialize(templateContents);
      data.initialize(templateContents);
      suffix.initialize(templateContents);
  }



 public Object execute() {
    // to be called by client.
    execute(1); 

    return this;
 }


public boolean next(int x, int y) {
    return next();
}

public void execute(int y)  {

     while (next(y, dataSetParm.getDataIterator().getCurrentItemNumber())) {
       getPrefix(y, dataSetParm.getDataIterator().getCurrentItemNumber());  // prefix
       getData(y, dataSetParm.getDataIterator().getCurrentItemNumber());  // data
       getSuffix(y, dataSetParm.getDataIterator().getCurrentItemNumber());  // suffix
      }

 }


/**
This method returns the prefix for a particular row, column (i.e. x, y) combination.  For example if the DataSet we are 
working with is a cell then the returned value could be "<td>"

*/

public void getPrefix(int x, int y) {
     prefix.getDataSet(x, y).execute(y);
}

public void getData(int x, int y) {
     data.getDataSet(x, y).execute(y);
 }

protected DataSet getDataSet(int x, int y) {
    return (DataSet) data.getDataSet(x,y);
}


/* package */ void setData(int x, int y, DataSet dataSet) {
    data.setDataSet(x, y, dataSet);
}

/**
Returns the suffix for a particular row, column (i.e. x, y) combination.  For example if the DataSet we are 
working with is a cell then the returned value could be "</td>"

*/

public void getSuffix(int x, int y) {
     suffix.getDataSet(x, y).execute(y);
 }
}

