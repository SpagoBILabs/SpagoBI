package com.fdsapi;  // FormattedDataSet API



import java.util.*;
import com.jamonapi.utils.*;

/**

<p>This class is used to create DataSet objects.  DataSet's are used to turn tabular data into text such as HTML, or XML
(for example an HTML table, or a drop down list box), or to execute any logic against the underlying tabular data.  </p>

<p>The code in this class uses a number of patterns the "Design Patterns" book by Gamma, Helm, Johnson 
and Vlissides and published by Addison Wesley.  It primarily uses the creational patterns:  Abstract Factory,
Builder, Factory Method, and Singleton.  
</p>
 
<p>The general idea of all of the creational patterns is to make the creation of objects simpler and more flexible.
In the case of DataSet's this is particularly important because DataSet's consist of many objects and would be
difficult to create each time by executing all of the individual steps.</p>

<p>Developers may enhance the capabilities of DataSet's by checking there own DataSets into the factory.</p>

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetFactory.htm">View Code</a>
*/
public class DataSetFactory extends java.lang.Object
{
    private static DataSetFactory dataSetFactory = new DataSetFactory();
    private Map dataSetFactoryMasterList=AppMap.createInstance();

    public static DataSetFactory createInstance()  {
        return dataSetFactory;
    }

   /* Log debug message */
   private void log(String logStr) {
     Utils.logDebug(logStr);
   }


    /** Populate the DataSetFactory with its default objects.  Developers may check there own DataSets into 
    the factory.  Note each DataSet knows how to create itself. */
    protected DataSetFactory()  {

        log("\n*DataSetFactory Contructor - start populating DataSetFactory");
        DataSet dataSetCellEmpty = new DataSetCellEmpty();
        DataSet dataSetCellNoAppend = new DataSetCellNoAppend();
        DataSet dataSetCellConstant = new DataSetCellConstant();
        DataSet dataSetCell = new DataSetCell();
        DataSet dataSetRow = new DataSetRow();
        DataSet dataSetCol = new DataSetCol();
        DataSet dataSetDecorator = new DataSetDecorator();
        DataSet dataSetNext = new DataSetNext();
        DataSet dataSetCellFormattedDataSet = new DataSetCellFormattedDataSet();
        DataSet dataSetCellListBox = new DataSetCellListBox();
        DataSet dataSetCellDropDownListBox = new DataSetCellDropDownListBox();
        DataSet dataSetCellRadioButton = new DataSetCellRadioButton();
        DataSet dataSetConditional = new DataSetConditional();
        DataSet dataSetCellAlternating = new DataSetCellAlternating();

        setDataSetFactoryMaster(TemplateConstants.EMPTY, dataSetCellEmpty);
        setDataSetFactoryMaster(TemplateConstants.NOAPPEND, dataSetCellNoAppend);
        setDataSetFactoryMaster(TemplateConstants.CONSTANT, dataSetCellConstant);
        setDataSetFactoryMaster(TemplateConstants.DATA, dataSetCell);
        setDataSetFactoryMaster(TemplateConstants.ROW, dataSetRow);
        setDataSetFactoryMaster(TemplateConstants.COL, dataSetCol);
        setDataSetFactoryMaster(TemplateConstants.DECORATOR, dataSetDecorator);
        setDataSetFactoryMaster(TemplateConstants.NEXT, dataSetNext);
        setDataSetFactoryMaster(TemplateConstants.QUERY, dataSetCellFormattedDataSet);
        setDataSetFactoryMaster(TemplateConstants.LISTBOX, dataSetCellListBox);
        setDataSetFactoryMaster(TemplateConstants.DROPDOWNLISTBOX, dataSetCellDropDownListBox);
        setDataSetFactoryMaster(TemplateConstants.RADIOBUTTON, dataSetCellRadioButton);
        setDataSetFactoryMaster(TemplateConstants.CONDITIONAL, dataSetConditional);
        setDataSetFactoryMaster(TemplateConstants.ALTERNATING, dataSetCellAlternating);

        setDataSetFactoryMaster("HEADER_CONTAINER", dataSetDecorator);
        setDataSetFactoryMaster("HEADER_ROW_CONTAINER", dataSetRow);
        setDataSetFactoryMaster("HEADER_CELL_CONTAINER", dataSetCol);
        setDataSetFactoryMaster("BODY_CONTAINER", dataSetDecorator);
        setDataSetFactoryMaster("BODY_ROW_CONTAINER", dataSetRow);
        setDataSetFactoryMaster("BODY_CELL_CONTAINER", dataSetCol);
        setDataSetFactoryMaster("COMPOSITE_CONTAINER", dataSetDecorator);
        setDataSetFactoryMaster("COMPOSITE_ROW_CONTAINER", dataSetRow);
        setDataSetFactoryMaster("COMPOSITE_CELL_CONTAINER", dataSetCol);

        log("\n*DataSetFactory Contructor - end populating DataSetFactory");

    }



    /** Gets a Factory DataSet or throws a RuntimeException if the DataSet doesn't exist in the factory */
    DataSet getDataSetFactoryMaster(String name)  {
        try {
            return (DataSet) AppMap.get(dataSetFactoryMasterList, name);
        } catch(Exception e) {
            String err=Misc.getClassName(this)+".getDataSetFactoryMaster() error: "+e;
            throw new  RuntimeExceptionBase(err);
        }
    }

    /** 
    <p>Register a DataSet into the factory.  After the DataSet is registered it can be used in templates by 
    entering: Type==email</p>

    <p><b>Sample call:</b></p><blockquote><code><pre>
        DataSetFactory.setDataSetFactoryMaster("email", new EmailDataSet());
     </pre></code></blockquote>
    */
    public void setDataSetFactoryMaster(String type, DataSet dataSet) {
        log("Initializing DataSet Factory Master, name="+type+", class="+Misc.getClassName(dataSet));
        dataSetFactoryMasterList.put(type, dataSet);
    }


    private boolean createDefaultTemplate=true;
    private DataSet[] defaultDataSets;  

    // Default template that all other templates implicitly inherit from.  This allows developers to have
    // values for all locations even if they don't provide them.
    private String defaultTemplate=
"<!-- HEADER_PREFIX -->type==empty<!-- HEADER_PREFIX -->"+
"<!-- HEADER_DATA -->type==next<!-- HEADER_DATA -->"+
"<!-- HEADER_SUFFIX -->type==empty<!-- HEADER_SUFFIX -->"+

"<!-- HEADER_ROW_PREFIX -->type==empty<!-- HEADER_ROW_PREFIX -->"+
"<!-- HEADER_ROW_DATA -->type==next<!-- HEADER_ROW_DATA -->"+
"<!-- HEADER_ROW_SUFFIX -->type==empty<!-- HEADER_ROW_SUFFIX -->"+

"<!-- HEADER_CELL_PREFIX -->type==empty<!-- HEADER_CELL_PREFIX -->"+
"<!-- HEADER_CELL_DATA -->type==data<!-- HEADER_CELL_DATA -->"+
"<!-- HEADER_CELL_SUFFIX -->type==empty<!-- HEADER_CELL_SUFFIX -->"+

"<!-- BODY_PREFIX -->type==empty<!-- BODY_PREFIX -->"+
"<!-- BODY_DATA -->type==next<!-- BODY_DATA -->"+
"<!-- BODY_SUFFIX -->type==empty<!-- BODY_SUFFIX -->"+

"<!-- BODY_ROW_PREFIX -->type==empty<!-- BODY_ROW_PREFIX -->"+
"<!-- BODY_ROW_DATA -->type==next<!-- BODY_ROW_DATA -->"+
"<!-- BODY_ROW_SUFFIX -->type==empty<!-- BODY_ROW_SUFFIX -->"+


"<!-- BODY_CELL_PREFIX -->type==empty<!-- BODY_CELL_PREFIX -->"+
"<!-- BODY_CELL_DATA -->type==data<!-- BODY_CELL_DATA -->"+
"<!-- BODY_CELL_SUFFIX -->type==empty<!-- BODY_CELL_SUFFIX -->"+

"<!-- COMPOSITE_PREFIX -->type==empty<!-- COMPOSITE_PREFIX -->"+
"<!-- COMPOSITE_DATA -->type==next<!-- COMPOSITE_DATA -->"+
"<!-- COMPOSITE_SUFFIX -->type==empty<!-- COMPOSITE_SUFFIX -->"+

"<!-- COMPOSITE_ROW_PREFIX -->type==empty<!-- COMPOSITE_ROW_PREFIX -->"+
"<!-- COMPOSITE_ROW_DATA -->type==next<!-- COMPOSITE_ROW_DATA -->"+
"<!-- COMPOSITE_ROW_SUFFIX -->type==empty<!-- COMPOSITE_ROW_SUFFIX -->"+

"<!-- COMPOSITE_CELL_PREFIX -->type==empty<!-- COMPOSITE_CELL_PREFIX -->"+
"<!-- COMPOSITE_CELL_DATA -->type==noappend<!-- COMPOSITE_CELL_DATA -->"+
"<!-- COMPOSITE_CELL_SUFFIX -->type==empty<!-- COMPOSITE_CELL_SUFFIX -->";


    /** 
    * If the predefined default Template string is not satisfactory it may be replaced.  Be careful when
    * using this method as all templates implicitly inherit from it.
    */
    public void setDefaultTemplate(String defaultTemplate) {
        this.defaultTemplate=defaultTemplate;
    }

    /** 
    Return a copy of the Default composite, body and header DataSets.  All Template objects use this as
    a starting point for the creation of the DataSets defined from the templates.  
    */
    DataSet[] getDefaultDataSets() {
        // The default data sets are only created once and cloned after that.
        if (createDefaultTemplate) {
           log("\n\n** Start Building Default DataSets - DataSetFactory.getDefaultDataSets()");

           defaultDataSets = new DataSetFactoryBuilder(defaultTemplate).getLevel1DataSets();
           createDefaultTemplate=false;

           log("** End Building Default DataSets - DataSetFactory.getDefaultDataSets()\n\n");

        }

        return cloneDataSets(defaultDataSets);

    }



    /* Make a copy of the passed DataSet array */
    DataSet[] cloneDataSets(DataSet[] dsFrom) {
       try {
            DataSet[] dsTo=new DataSet[dsFrom.length];
            for (int i=0; i<defaultDataSets.length; i++)  {
                dsTo[i] = (DataSet) dsFrom[i].clone();
            }

            return dsTo;
       } catch (Exception e) {
            String err=Misc.getClassName(this)+".cloneDataSets() error: "+e;
            throw new  RuntimeExceptionBase(err, e);
        }
    }



/*************** start inner class DataSetFactoryBuilder **********************/
private class DataSetFactoryBuilder {
    private String templateContents;
    private DataSetFactoryBuilder(String templateContents) {
        this.templateContents=templateContents;
    }


/** Return header, body and composite default DataSets */
private DataSet[] getLevel1DataSets() {
    String[] templateTagTypeLevel1 = TemplateConstants.getTagTypeLevel1();  // HEADER, BODY, COMPOSITE
    int rowsLevel1 = templateTagTypeLevel1.length;
    DataSet[] dataSets = new DataSet[rowsLevel1];

    for(int i=0; i<rowsLevel1; i++)   {
            log("\n* Start DataSetFactoryBuilder.getLevel1DataSets(): templateTagTypeLevel1="+templateTagTypeLevel1[i]+", dataSets["+i+"]");
            dataSets[i] = createTagLevel1DataSet(templateTagTypeLevel1[i]); 
            log("* End DataSetFactoryBuilder.getLevel1DataSets(): templateTagTypeLevel1="+templateTagTypeLevel1[i]+", dataSets["+i+"]="+Misc.getClassName(dataSets[i])+"\n");
    }

    return dataSets;

 }


/** Calls createFactoryInstance(...) on all "Container" DataSet's.  These in turn create all DataSet's down the chain
*/
private DataSet createTagLevel1DataSet(String templateTagTypeLevel1) {
    // create all data sets for BODY,HEADER or COMPOSITE .
    DataSet nextDataSet=null;
    String[] templateTagTypeLevel2 = TemplateConstants.getTagTypeLevel2();  // CELL, ROW, EMPTY in that order
    int rowsLevel2 = templateTagTypeLevel2.length;

    for(int i=0; i<rowsLevel2; i++)  {
        // key Ex:  BODY_CELL_, BODY_ROW_, BODY_,...
        // containerKey Ex:  BODY_CELL_CONTAINER, BODY_ROW_CONTAINER, BODY_CONTAINER,...          

        String key=TemplateConstants.getTemplateKey(templateTagTypeLevel1,templateTagTypeLevel2[i], null);
        String containerKey=TemplateConstants.getTemplateKey(templateTagTypeLevel1,templateTagTypeLevel2[i],TemplateConstants.CONTAINER);

        log("\nStart DataSetFactory.DataSetFactoryBuilder: create DataSet factory instances: containerKey="+containerKey);
        DataSetFactoryParm dataSetFactoryParm=new DataSetFactoryParm(key, templateContents, nextDataSet);
        nextDataSet = getDataSetFactoryMaster(containerKey).createFactoryInstance(dataSetFactoryParm);
        log("End DataSetFactory.DataSetFactoryBuilder: create DataSet factory instances: containerKey="+containerKey);

     }

    return nextDataSet;
}


}
/*************** end inner class DataSetFactoryBuilder **********************/
}

