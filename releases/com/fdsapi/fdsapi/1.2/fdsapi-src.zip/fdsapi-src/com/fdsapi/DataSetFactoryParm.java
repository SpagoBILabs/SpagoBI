package com.fdsapi;  // FormattedDataSet API

/** Class used to create a factory instance of DataSetDecorators.

 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetFactoryParm.htm">View Code</a>
*/
public class DataSetFactoryParm implements Cloneable {
    private String templateTagType;
    private String templateContents;
    private DataSet nextDataSet;
    private TemplateVariables variables;
    
    public DataSetFactoryParm(String templateTagType, String templateContents, DataSet nextDataSet) {
        this.templateTagType=templateTagType;
        this.templateContents=templateContents;
        this.nextDataSet=nextDataSet;
    }
    
    public Object clone() throws CloneNotSupportedException {
        // makes an exact duplicate of the object with any object references still pointing to the original classes
        // objects.
        DataSetFactoryParm parm = (DataSetFactoryParm) super.clone(); 
    
        return parm;
    }

    
    public String getTemplateContents() {
        return templateContents;
    }
    
    public void setTemplateContents(String templateContents) {
        this.templateContents=templateContents;
    }
    
    public String getTemplateTagType() {
        return templateTagType;
    }
    
    public DataSet getNextDataSet() {
        return nextDataSet;
    }
    
    public TemplateVariables getVariables() {
        return variables;
    }
    
    public void setVariables(TemplateVariables variables) {
        this.variables=variables;   
    }
    
}
