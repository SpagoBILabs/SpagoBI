package com.fdsapi;  // FormattedDataSet API


import java.util.*;
import com.jamonapi.utils.*;

/**

<p>This class maps DataSets to x,y coordinates.  This class is used to add prefixes and 
suffixes to values in a tabular DataSet (for example a cell or a row).  This allows the separation of data (a ResultSet) from presentation (HTML). </p>

<p>You can define the following types of coordinates for DataSets affixes.  <br>
    1) A DataSet for a particular coordinate (represented by rownumber, columnnumber)<br>
    2) A DataSet for a row (x coordinate) default (represented by rownumber, 0)<br>
    3) A DataSet for a column (y coordinate) default (represented by 0, columnnumber)<br>
    4) An overall default (represented by 0, 0)<br>
</p>

<p>For any coordinate being retrieved with getDataSet(x, y) the order of precedence is 1,2,3 then 4.  For example
if we are displaying the value in coordinate (4,5) of a ResultSet, the following values would be checked to 
determine what DataSet to use.</p>
    1) If (4,5) has an entry then use this value<br>
    2) else if (4,0) has an entry then use this value<br>
    3) else if (0,5) has an entry then use this value<br>
    4) else use the default (0,0) entry which always exists.<br>

<p>(See the main() method which is used for testing for further details.)</p>

<p>Note the flyweight pattern from the Erich Gamma Design Patterns is used to reduce the number of coordinates that
need to be created.</p>

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetMap.htm">View Code</a>
*/
public class DataSetMap extends java.lang.Object implements Cloneable
{


private     Map map = AppMap.createInstance();  // used to a hold coordinate key and its associated string value.
private     Coordinate key = new Coordinate(0,0);  // the key in the HashMap. 

// Ex HEADER_ROW_DATA, HEADER_ROW_PREFIX, COMPOSITE_CELL_SUFFIX,....  
// This value is used to parse the template.
private DataSetFactoryParm parm;  

//private DataSetMap() {
//}

protected DataSetMap(int maxX, int maxY) {
    this.maxX = maxX;
    this.maxY = maxY;
}

private DataSetMap(DataSetFactoryParm parm) {
    this.parm=parm;
    // avoids null exception when initialize() is first called.  This default dataset will later be overwritten
    // by the default template.
    setDataSet(0,0, DataSetFactory.createInstance().getDataSetFactoryMaster(TemplateConstants.EMPTY));
}


// templateTagType = the full 3 level template tag type (i.e. HEADER_PREFIX, HEADER_DATA, HEADER_SUFFIX,
// HEADER_ROW_PREFIX, HEADER_ROW_DATA, HEADER_ROW_SUFFIX, HEADER_CELL_PREFIX, HEADER_CELL_DATA, HEADER_CELL_SUFFIX,...
// BODY..., COMPOSITE...
/* package */ static DataSetMap createFactoryInstance(DataSetFactoryParm p) {
    DataSetMap dataSetMap=new DataSetMap(p);
    dataSetMap.initialize(p.getTemplateContents());
    return dataSetMap;
}


public Object clone() throws CloneNotSupportedException {
    // makes an exact duplicate of the object with any object references still pointing to the original classes
    // objects.
    DataSetMap dsMap = (DataSetMap) super.clone();  

    dsMap.key  = new Coordinate(0,0);
    // shallow copy of map. Note maps aren't cloneable so it must be cast to an AppMap before cloning
    dsMap.map  = (Map) ((AppMap)map).clone(); 
    dsMap.map  = deepCopyMap(dsMap.map);
    dsMap.parm = (DataSetFactoryParm) parm.clone();

    return dsMap;
}

private static void iterate(Map m, Command c) {
    try {
        CommandIterator.iterate(m, c);
    } catch (Exception e) {
       throw new RuntimeExceptionBase("error executing Map Command object", e);
    }
}        

/** Deep copy/clone the map of DataSets by iterating over them and executing the clone command.*/
private Map deepCopyMap(final Map dataSets) {

 class CloneMapCommand implements Command
    {
        public void execute(Object object) throws Exception         {
            Map.Entry mapEntry = (Map.Entry) object;
            DataSet ds = (DataSet) mapEntry.getValue();
            dataSets.put(mapEntry.getKey(), ds.clone());
        }
    }

    Command command = new CloneMapCommand();
    iterate(dataSets, command);

    return dataSets;

}


/** Iterate through the map and set the DataSetParms for all DataSets that it contains */
public void setDataSetParm(final DataSetParm dsp) {

   class DataSetParmCommand implements Command
    {
        public void execute(Object object) throws Exception         {
            Map.Entry mapEntry = (Map.Entry) object;
            DataSet ds = (DataSet) mapEntry.getValue();
            ds.setDataSetParm(dsp);
        }
    }

    Command command = new DataSetParmCommand();

    iterate(map, command);
}

/**
<p>Associate a DataSet with a specified (x,y) coordinate.  The getDataSet(x,y) method will return this DataSet.</p>

<p><b>Sample call: </b></p>
    <blockquote><code><pre>setAffix(1, 100, "<td>");  </pre></code></blockquote>

*/
public void setDataSet(int x, int y, DataSet dataSet) {
        setMaxX(x);
        setMaxY(y);
        map.put(new Coordinate(x, y), dataSet);
    }

private int maxX;
private int maxY;

public void setMaxX(int x) {
    if (maxX < x)
        maxX = x;
}

public void setMaxY(int y) {
    if (maxY < y)
        maxY = y;
}


public int getMaxX() {
    return maxX;
}

public int getMaxY() {
    return maxY;
}

/**
<p>Gets the DataSet value for a specific coordinate.</p>

<p><b>Sample call:</b></p><blockquote><code><pre>
    setDataSet(1, 100, new MyDataSet());
    DataSet ds = getDataSet(1, 100);  
 </pre></code></blockquote>

<p>See the class comment and the main() method to see what happens when a coordinate that is used in the
getDataSet() call doesn't exist.</p>

*/

public DataSet getDataSet(int x, int y) {

    // Note key.setValues() is called so I don't have to create a new key for each if condition.  
    // This is called the flyweight pattern.
    if (map.containsKey(key.setValues(x, y)))          // does the specific coordinate exist.
          return (DataSet) map.get(key);
    else if (map.containsKey(key.setValues(x, 0)) )      // does an x (row) default exist.
          return (DataSet) map.get(key);
    else if (map.containsKey(key.setValues(0, y)) )      // does a y (column) default exist.
          return (DataSet) map.get(key);
    else 
          return (DataSet) map.get(key.setValues(0, 0));  // if no matches then return the affix default.
}



/* package */ void initialize(String templateContents) {
     parm.setTemplateContents(templateContents);
     new DataSetMapParser().parse();
     parm.setTemplateContents(null);  // not required but allows String to be garbage collected
}

private void log(String logStr) {
    Utils.logDebug(logStr);
}


/** 
Inner class used to create DataSetMap Factory instances.  i.e. the default dataset (0,0) and any datasets
specified in a template.  These DataSets will be used to clone other ones at run time.  This inner class is 
only called when a template is being initialized.
**/
private class DataSetMapParser {

    private void parse() {
        populateDefaultFactoryDataSets();  
        populateFactoryDataSets();
    }


    // If this is a DataSetDecorator this logic will continue down the chain.  If it is a regular 
    // DataSet nothing will be done and the code will return immediately.
    private void populateDefaultFactoryDataSets() {
        // When the DataSetMap is initialy created DataSet 0,0 is a null object to avoid a null pointer 
        // exception when calling this method
        getDataSet(0,0).initialize(parm.getTemplateContents());
    }

    // populate DataSetMap's hash map with all data sets by parsing the template.
    private void populateFactoryDataSets() {
        // initialize template reader to work with the current tag type for this DataSetMap.  The value will be 
        // one of 27 entries like body_cell_prefix, body_cell_data, body_cell_suffix, composite_row_data etc.
        TemplateTagReader templateTagReader = TemplateTagReader.createInstance(parm.getTemplateTagType());  // used to parse the template file into Affixes.
        templateTagReader.setSourceString(parm.getTemplateContents());  // typically this string has been read from a file.
        // loop through the buffer of file until there are no more tokens of the current tag type.
        // The templateTagValue contains everything between the start and end tags including all variables.

        while (templateTagReader.next())   {
            DataSet ds = createFactoryDataSet(templateTagReader.getTemplateTagValue());
            setDataSet(templateTagReader.getX(), templateTagReader.getY(), ds);

            log("Initialize template specified DataSet: Template Info="+parm.getTemplateTagType()+"    DataSet="+Misc.getClassName(ds)+
            "     x="+templateTagReader.getX()+
            "     y="+templateTagReader.getY()+
            "    value=("+templateTagReader.getTemplateTagValue()+")");
        }

    /** 
        Called when initializing templates at startup only.  used to populate DataSetMaps.
        pass in a full template tag type such as BODY_CELL_PREFIX, HEADER_ROW_DATA, or COMPOSITE_DATA
     */
      }

    private DataSet createFactoryDataSet(String templateTagValue) {
        // templateTagType=BODY_CELL_PREFIX tagVariable=  type==listbox
        TemplateVariables variables = TemplateVariables.createInstance();
        variables.populateVariables(templateTagValue);
        String type=variables.getType();
        parm.setVariables(variables);
        DataSet dataSet=DataSetFactory.createInstance().getDataSetFactoryMaster(type).createFactoryInstance(parm);

        return dataSet;

    }


}  /*** end DataSetMapInitialize inner class ***/
}

