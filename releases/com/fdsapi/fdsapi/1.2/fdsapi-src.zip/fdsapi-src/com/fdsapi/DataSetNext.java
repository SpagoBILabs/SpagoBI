package com.fdsapi;  // FormattedDataSet API

/** DataSet that simply redirects the call to the next DataSet in line.  It is used when going from the body 
 * DataSet to the row DataSets, and the row DataSets to the cell DataSets.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetNext.htm">View Code</a>
 */
public class DataSetNext extends DataSet
{
    protected DataSetNext() {}

    // It simply returns the nextDataSet in the chain and doesn't create its own DataSet.
    public DataSet createFactoryInstance(DataSetFactoryParm parm) {
        return parm.getNextDataSet();

    }


    public DataSet createFactoryInstance()     {
        return new DataSetNext();
    }


    public void execute(int y) {
        throw new RuntimeExceptionBase("This function is not implemented in this class.");
    }
}

