package com.fdsapi;  // FormattedDataSet API


import java.util.*;
/** Common data shared by all DataSets that build a particular Template object.  There are at least
 * 27 DataSets in each Template object and data such as the TabularData that is being iterated is shared
 * by all of these.   The DataSetParm is an object that passes all of these shareable data values to 
 * each DataSet.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetParm.htm">View Code</a>
 */

public class DataSetParm extends java.lang.Object implements Cloneable
{
    private TabularData tabularData;  // Data that the Template object is taking action against.
    private StringBuffer stringBuffer;  // used to write the FormattedDataSet text to
    private DataIterator dataIterator; // used to iterate through the TabularData
    private Map miscDataMap; // used to contain the misc variables used in the Template file

    public DataSetParm(TabularData tabularData, StringBuffer stringBuffer, Map miscDataMap) {
       this.tabularData=tabularData;
       this.stringBuffer=stringBuffer;
       this.miscDataMap=miscDataMap;
    }

    public Object clone() throws CloneNotSupportedException {
        // makes an exact duplicate of the object with any object references still pointing to the original classes
        // objects.
        DataSetParm dsp = (DataSetParm) super.clone(); 

        return dsp;
    }


    public TabularData getTabularData() {
        return tabularData;
    }

    public StringBuffer getStringBuffer() {
        return stringBuffer;
    }
    
    public Map getMiscDataMap() {
        return miscDataMap;
    }


    public DataIterator getDataIterator() {
        return dataIterator;
    }

    public void setDataIterator(DataIterator dataIterator) {
        this.dataIterator=dataIterator;
    }
}

