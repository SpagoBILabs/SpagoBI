package com.fdsapi;  // FormattedDataSet API

/** DataSet that contains actions for the rows in TabularData. 
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/DataSetRow.htm">View Code</a>
 */
public class DataSetRow extends DataSetDecorator
{
  protected DataSetRow() {}

  public DataSet createFactoryInstance() {
     return new DataSetRow();
  }

  public DataIterator createDataIterator() {    
    return dataSetParm.getTabularData().getRowIterator();
  }
}

