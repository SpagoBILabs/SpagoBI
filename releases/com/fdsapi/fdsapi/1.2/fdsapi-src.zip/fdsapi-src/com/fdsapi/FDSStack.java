

package com.fdsapi;

import java.util.*;

/**
 *
 * Implimentation of a stack.  
 * 
 *  * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/FDSStack.htm">View Code</a>
 */
public class FDSStack {
    
    /** Creates a new instance of FDSStack */
    public FDSStack() {
    }
    
    private LinkedList stack=new LinkedList();
    
    /** Push to the stack */
    public void push(Object item){
            stack.addFirst(item);
    }
        
        /** pop from the stack */
    public Object pop() {
      return stack.removeFirst();
    }
    
    /** get the current top item on the stack, but don't pop. */
    public Object getCurrent() {
     return stack.getFirst();
    }
    
    /** Wipe out anything on the stack i.e. make the stack empty */
    public void reset() {
        stack=new LinkedList();
    }
    
    /** Return how many items are on the stack */
    public int size() {
        return stack.size();
    }
    
    /** Returns true if the stack is empty, false otherwise */
    public boolean isEmpty() {
        return (size()==0) ? true : false;
    }
            
    
}
