package com.fdsapi;  // FormattedDataSet API



import java.sql.*;
import java.util.*;
import java.net.*;
import com.jamonapi.*;
import com.fdsapi.arrays.*;

/**
 * 
 * <p>Using templates and tabular data The FormattedDataSet generates dynamic text such as HTML, XML and more.  The FormattedDataSet
 * makes a clean separation of data and presentation.  The data can be any TabularData such as
 * a ResultSet or a 2 dimensional array.  The formatting is kept in templates and can be reused
 * with any TabularData.  </p>
 * 
 * <p>There are many methods that are overloaded in the FormattedDataSet.  For example there are 12
 * different "getFormattedDataSet(...)" method calls.  The main differences in the methods are the
 * type of TabularData they take as input.  For example a query can be passed in directly, or
 * a query with a DataSourceName, a ResultSetConverter or any other form of TabularData.  Also
 * some of the methods can take a Map which contains miscellaneous data referenced in the Template
 * with ## variable syntax (i.e. ##mapKey).  Finally there are alternative signatures that take 
 * a Template name, or the Template object itself.  Despite the large number of signatures remember that 
 * conceptually all the "getFormattedDataSet(...)" methods do the same thing.</p>
 * 
 * <p>The same principle applies to the multiple signatures of "getDropDownListBox(...)", "getListBox(...)",
 * "getMultiSelectListBox(...)", "getRadioButton(...)", and "getSortedText(...)"</p>
 *
 * <p>Note that the methods for "getDropDownListBox(...)", "getListBox(...)",
 * "getMultiSelectListBox(...)", and "getRadioButton(...)" all take the same format of the TabularData which
 * is dataValue, displayValue (for example "select dataValue, displayValue from table").  These correspond to the
 * html data and display values.  Many of these methods have sample code and output in the javadocs.</p>
 *
 * <p>Note template names are case-insensitive ("mytemplate" is the same as "MYTEMPLATE").</P>
 * 
 *
 * <p><b>Sample Output From Many of the Methods mentioned above follow:</b></p>
 * 
 * <p>1) getFormattedDataSet(...) methods (using the "BasicHtmlTable" template): 
 *   <table border='1' rules='all'>
 *   <th>lastNameValue</th><th>lastNameDisplay</th>
 *   <tr><td>SouzaValue</td><td>SouzaDisplay</td></tr>
 *   <tr><td>BeckValue</td><td>BeckDisplay</td></tr>
 *   <tr><td>ReidValue</td><td>ReidDisplay</td></tr>
 *   <tr><td>HibbertValue</td><td>HibbertDisplay</td></tr>
 *   <tr><td>RichardsValue</td><td>RichardsDisplay</td></tr>
 *   </table>
 * </p>
 *
 *  <p>2) getFormattedDataSet(...) methods (using the "HtmlTable" template):</p> 
 *  <img src="doc-files/htmlTableSample.jpg" id="htmltablesample" />
 *
 * <p>3) getFormattedDataSet(...) methods (using the "xml1" template): 
 * <pre>
 * &lt;rollingstones&gt;
 *  &lt;row rowID='1'&gt;
 *   &lt;First Name&gt;Keith&lt;/First Name&gt;
 *   &lt;Last Name&gt;Richards&lt;/Last Name&gt;
 *  &lt;/row&gt;
 *  &lt;row rowID='2'&gt;
 *   &lt;First Name&gt;Mick&lt;/First Name&gt;
 *   &lt;Last Name&gt;Jagger&lt;/Last Name&gt;
 *  &lt;/row&gt;
 *  &lt;row rowID='3'&gt;
 *   &lt;First Name&gt;Bill&lt;/First Name&gt;
 *   &lt;Last Name&gt;Wyman&lt;/Last Name&gt;
 *  &lt;/row&gt;
 *  &lt;row rowID='4'&gt;
 *   &lt;First Name&gt;Ron&lt;/First Name&gt;
 *   &lt;Last Name&gt;Wood&lt;/Last Name&gt;
 *  &lt;/row&gt;
 *  &lt;row rowID='5'&gt;
 *   &lt;First Name&gt;Charlie&lt;/First Name&gt;
 *   &lt;Last Name&gt;Watts&lt;/Last Name&gt;
 *  &lt;/row&gt;
 *  &lt;/rollingstones&gt;
 *
 * </pre>
 * </p>
 *
 * <p>4) getSortedText(...) methods (using the "sortedHTMLTable" template):</p> 
 *  <img src="doc-files/htmlSortTableSample.jpg" id="htmlsorttablesample" />
 *
 * <p>5) getDropDownListBox(...) methods: 
 *   <select name='lastNameValue' size='1' id='lastNameValue_ID'>
 *   <option value='SouzaValue'>SouzaDisplay
 *   <option value='BeckValue' selected>BeckDisplay
 *   </select>
 * </p>
 *
 * <p>6) getListBox(...) methods:<br>
 *   <select name='lastNameValue' size='5' id='lastNameValue_ID'>
 *   <option value='SouzaValue'>SouzaDisplay
 *   <option value='BeckValue' selected>BeckDisplay
 *   <option value='ReidValue'>ReidDisplay
 *   <option value='HibbertValue'>HibbertDisplay
 *   <option value='RichardsValue'>RichardsDisplay
 *   </select> 
 *   </p>
 * 
 * <p>7) getMultiSelectListBox(...) methods:<br>
 *   <select name='lastNameVal' size='5' id='lastNameVal_ID' multiple='MULTIPLE'>
 *   <option value='SouzaValue' selected>SouzaDisplay
 *   <option value='BeckValue' selected>BeckDisplay
 *   <option value='ReidValue'>ReidDisplay
 *   <option value='HibbertValue'>HibbertDisplay
 *   <option value='RichardsValue'>RichardsDisplay
 *   </select>
 *  </p>
 * 
 * <p>8) getRadioButton(...) methods:<br>
 *    <input  name=lastNameValue value=SouzaValue type=radio>SouzaDisplay
 *    <input  name=lastNameValue value=BeckValue checked type=radio>BeckDisplay
 *    <input  name=lastNameValue value=ReidValue type=radio>ReidDisplay
 *    <input  name=lastNameValue value=HibbertValue type=radio>HibbertDisplay
 *    <input  name=lastNameValue value=RichardsValue type=radio>RichardsDisplay 
 *    </p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/FormattedDataSet.htm">View Code</a>
 */

public class FormattedDataSet extends java.lang.Object implements java.io.Serializable
{

 /** FormattedDataSet may either be created with a constructor or the createInstance() method */
 public FormattedDataSet() {}
 private final Map NULLMAP=new HashMap();
// private ArrayConverter arrayConverter=new ArrayConverter();
  private ArrayConverter arrayConverter=null;

 private static FormattedDataSet formattedDataSet=new FormattedDataSet();
 /** <p>Returns a singleton version of the FormattedDataSet.  It is the equivalent of calling the public 
  * constructor except this method returns a singleton.  Each FormattedDataSet instance is 
  * thread safe no matter how it is created.</p>
  * 
  * <b>Sample Call:</b><br><br><blockquote><code><pre>
  * FormattedDataSet fds=FormattedDataSet.createInstance();
  * String html=fds.getFormattedDataSet("select * from table", "htmlTable");
  * </blockquote></code></pre>
 */
 public static FormattedDataSet createInstance()  {
        return formattedDataSet;
 }
  
 /** <p>Pass in an array of template names and files to be parsed into Template objects contained in the 
  * FormattedDataSet instance.  The array takes a logical template name and a file.  The logical 
  * template name can then be referenced in calls to getFormattedDataSet.  Note although this routine 
  * takes an Object[][] it will typically be passed a String[][].  An Object[][] was taken so 
  * the ResultSetConverter.getResultSet() method can be passed directly.</p>
  *
  * <p>Note in the example below the template name "line_item_template" is parsed using 2 files.  Order
  * is important.  The first file in the array is parsed first and then the second.  If there any
  * conflicting template tags then the second files values will overwrite the first.  </p>
  *
  * 
  * <b>Sample call:</b> If the sample code was put in a jsp within a WAR then the template 
  *  files referenced would be found in the WAR subdirectory called "/templates" off of 
  *  the root.<br><br>
  * <blockquote><code><pre>
  * &lt;%!
  * FormattedDataSet fds=FormattedDataSet.createInstance();
  *
  * <b>public void jspInit()</b> {
  * String path=getServletContext().getRealPath("/");
  * String s[][] = { 
  *   {"line_item_template", path+"templates/sorted_table_template.html"},
  *   {"line_item_template", path+"templates/line_item_template.html"},
  *   {"myXMLtemplate", path+"templates/xml.html"},
  * };
  *
  * fds.initialize(s);
  * } %&gt;</pre></code></blockquote><br><br>
  *
  * <b>Sample call of a template from the jsp follows:</b><br><br>
  * <blockquote><code><pre>&lt;%= fds.getFormattedDataSet("select * from table", "myXMLTemplate") %&gt;</pre></code></blockquote>
  */
 public void initialize(Object[][] templateFiles) {
     // convert Object[][] to String[][]
     String[][] templates=ResultSetUtils.createInstance().convert(templateFiles);
     getTemplates().initialize(templates);
 }
 
 private static Templates defaultTemplates=null; // initialized lazily
 private Templates templates=defaultTemplates;

 /**
  * Returns the templates that belong to the FormattedDataSet. Individual Template objects can
  * be manipulated from the Templates object.
  *
  * @see Templates
  */
 public Templates getTemplates() {
     /* 
     Note lazy initialization of the Templates object is required.  If it is created at the time 
     of the FormattedDataSet creation a RuntimeException is thrown.  This is due to the fact that 
     The FormattedDataSet is required when the Templates class is created (via the DataSetFactory 
     constructor) and the Templates class would be required in the FormattedDataSet constructor.  
     Lazy initialization avoids this problem.
     */
     if (defaultTemplates==null) {
            templates=defaultTemplates=new Templates();
            return templates;
     } else
        return templates;
 }
 
 /** Returns a Template object which can be manipulated programmatically.
  *
  *  <p>
  *  <b>Sample call:</b><br><br><blockquote><code><pre>
  *  FormattedDataSet fds=new FormattedDataSet();
  *  Template template=fds.getTemplate("xml");
  *  </pre></code></blockquote></p>
  *
  * @see Template
  */
  public Template getTemplate(String templateName) {
      return getTemplates().get(templateName);
  }
  
 /** Check in a template object to be used in subsequent calls to FormattedDataSet.
  *
  *  <p>
  *  <b>Sample call:</b><br><br><blockquote><code><pre>
  *  FormattedDataSet fds=new FormattedDataSet();
  *  fds.putTemplate("myxml", new Template());
  *  </pre></code></blockquote></p>
  */
  public void putTemplate(String templateName, Template template) {
      getTemplates().put(templateName, template);
  }
  
 /* made private because I'm not sure if this makes sense or not */
 private void setTemplates(Templates templates) {
     this.templates=templates;
 }
 
 private DataAccess dataAccessFactory=null;
 
 /** <p>This method sets the DataAccess interface that will be called by the FormattedDataSet when 
  *  Database interaction is required.  For example there will be a different DataAccess class
  *  used for a J2EE application than a stand alone Java app. </p>
  *
  *  <b>Sample Call:</b><br><br><blockquote><code><pre>
  *  FormattedDataSet fds=FormattedDataSet.createInstance();
  *  DataAccess dataAccessFactory=new DataAccessJ2EE(new InitialContext(), "MyDataSource");
  *  fds.setDataAccessFactory(dataAccessFactory);
  *  </pre></code></blockquote>
  *
  * @see DataAccess, DataAccessClient, DataAccessJ2EE, DataAccessBase
  */
 public void setDataAccessFactory(DataAccess dataAccessFactory) {
     this.dataAccessFactory=dataAccessFactory;
 }
 
 
 private DataAccess getDataAccessFactory() throws SQLException {
     if (dataAccessFactory==null) {
         dataAccessFactory=new DataAccessJ2EE();
         return dataAccessFactory;
     } else     
         return dataAccessFactory;
 }

 /** Return the underlying DataAccess object. This allows developers to execute direct SQL with the 
  * FormattedDataSet's DataAccess object.
  */
 
 public DataAccess getDataAccess() throws SQLException {
    return getDataAccessFactory().createInstance();   
 }
       
 
/** Execute a query against the default datasource (named jdbc/DataSource) and format the results 
 * by using the specified template.  This method will execute the query using the FormattedDataSet's 
 * DataAccess interface.  Note the FormattedDataSet can handle all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b> The following sample will execute the query and format the results as an HTML table.<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String html=fds.getFormattedDataSet("select * from table", "htmlTable");
 * </pre></code></blockquote></p>
 */
public String getFormattedDataSet(String query, String templateName)  throws SQLException {
    return getFormattedDataSet(AppConstants.DATASOURCE, query, templateName);
}

/** Execute a query against the default datasource (named jdbc/DataSource) and format the results 
 * by using the specified template.  This method will execute the query using the FormattedDataSet's 
 * DataAccess interface.  Note FormattedDataSet handles all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b> The following sample will execute the query and format the results as an HTML table.<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String html=fds.getFormattedDataSet("select * from table", fds.getTemplate("htmlTable").copy());
 * </pre></code></blockquote></p>
 */
public String getFormattedDataSet(String query, Template template)  throws SQLException {
    return getFormattedDataSet(AppConstants.DATASOURCE, query, NULLMAP, template);
}

/** Execute a query against the default DataSource (jdbc/DataSource) and format the results by using 
 * the specified template, also accepting a Map which can be used to specify dynamic template 
 * variables. This method will execute the query using the FormattedDataSet's DataAccess interface.  
 * Note FormattedDataSet handles all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b>The following sample will execute the query and format the results as an HTML table.<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * Map map=new HashMap();
 * map.put("date", new Date()); // if template has ##date the date will be dynamically replaced with it
 * String html=fds.getFormattedDataSet("select * from table", map, "htmlTable");
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(String query, Map miscData, String templateName)  throws SQLException {
    return getFormattedDataSet(AppConstants.DATASOURCE, query, miscData, templateName);
}


/** Execute a query against the named datasource (named jdbc/MyDataSource) and format the results 
 * by using the specified template.  This method will execute the query using the FormattedDataSet's 
 * DataAccess interface.  Note FormattedDataSet handles all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b><br><br><blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String html=fds.getFormattedDataSet("myDataSource", "select * from table", "htmlTable");
 * </pre></code></blockquote></p>
 */
public String getFormattedDataSet(String dataSource, String query, String templateName) throws SQLException {
    return getFormattedDataSet(dataSource, query, NULLMAP, templateName);
}

/** Execute a query against the named datasource (named jdbc/MyDataSource) and format the results 
 * by using the specified template.  Also accept a Map which can be used to specify dynamic template 
 * variables. This method will execute the query using the FormattedDataSet's 
 * DataAccess interface.  Note FormattedDataSet handles all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b><br><br><blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * Map map=new HashMap();
 * map.put("date", new Date()); // if template has ##date the date will be dynamically replaced with it
 * String html=fds.getFormattedDataSet("myDataSource", "select * from table", map, "htmlTable");
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(String dataSource, String query, Map miscData, String templateName) throws SQLException {
 return getFormattedDataSet(dataSource, query, miscData, getTemplate(templateName));
}

/** Execute a query against the named datasource (named jdbc/MyDataSource) and format the results 
 * by using the specified Template object.  Also accept a Map which can be used to specify dynamic template 
 * variables. This method will execute the query using the FormattedDataSet's 
 * DataAccess interface.  Note FormattedDataSet handles all JDBC calls.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * Map map=new HashMap();
 * map.put("date", new Date()); // if template has ##date the date will be dynamically replaced with it
 * Template template=fds.getTemplate("htmlTable").copy();// clone template so as not to change the original
 * template.initialize("body_cell_data", 0, 2, "##this-##date");
 * String html=fds.getFormattedDataSet("myDataSource", "select * from table", map, template);
 * </pre></code></blockquote></p>
 */
public String getFormattedDataSet(String dataSource, String query, Map miscData, Template template) throws SQLException {
    Monitor mon=start("getFormattedDataSet(sql)");;
    DataAccess dataAccess=null;
    try {
        dataAccess = getDataAccessFactory().createInstance();
        dataAccess.setDataSourceName(dataSource);
        ResultSet rs = dataAccess.getResultSet(query);  // never returns null.
        // For the hypersonic database the ResultSet implements both the ResultSet and ResultSetMetaData interface.
        // This causes a problem as the TabularDataFactory always hits the first one (ResultSet) and 
        // returns the matching ResultSet for both ResultSet and ResultSetMetaData.  I think the access
        // jdbc driver has the same issue.  The explicit TabularData constructors below get around this 
        // problem.
        return getFormattedDataSet(new TabularDataRSMD(rs.getMetaData()), new TabularDataResultSet(rs), miscData, template);
     }
     finally {
       try {
          if (dataAccess!=null) 
            dataAccess.close();  
       } finally {
          mon.stop();
       }
     }

}

/** Execute the query against the named DataSource, and return a ResultSetConverter object.  The ResultSetConverter represents
 *  the ResultSet and ResultSetMetaData as arrays.  This allows the data to more easily be sorted,
 *  cached and manipulated in general.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * ResultSetConverter rsc=fds.getResultSetConverter("myDataSource", "select * from table");
 * </pre></code></blockquote></p>
 *  
 */
public ResultSetConverter getResultSetConverter(String dataSource, String query) throws SQLException {
    Monitor mon=start("getResultSetConverter(dataSource, query)");;
    try {
        DataAccess dataAccess = getDataAccessFactory().createInstance();
        dataAccess.setDataSourceName(dataSource);
        return dataAccess.getResultSetConverter(query); 
     }
     finally {
       mon.stop();
     }
    
}

/** Execute the query against the default DataSource (jdbc/DataSource) and return a ResultSetConverter object.  The ResultSetConverter represents
 *  the ResultSet and ResultSetMetaData as arrays.  This allows the data to more easily be sorted,
 *  cached and manipulated in general.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * ResultSetConverter rsc=fds.getResultSetConverter("select * from table");
 * </pre></code></blockquote></p>
 *  
 */

public ResultSetConverter getResultSetConverter(String query) throws SQLException {
    return getResultSetConverter(AppConstants.DATASOURCE, query);
}

/** Get the ArrayConverter that is set for any arrays.  The arrayConverter will format for display
 ** any arrays or ResultSetConverters passed to the getSorted text method.
 */
public ArrayConverter getArrayConverter() {
    return arrayConverter;
}

/** Set the ArrayConverter that is used to Format any passed in data to the getSortedText routines */
public void setArrayConverter(ArrayConverter arrayConverter) {
    this.arrayConverter=arrayConverter;
}


/** Format the passed data using the passed template.  Note both the header, and body must either implement
 * the TabularData interface or be objects that have been registered with the TabularDataFactory.
 *
 * <p>
 * <b>Sample Call:</b> (using array TabularData):<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String[]header={"fname", "lname"};
 * Object[][] body={{"jeff", "beck"}, {"william", "reid"}};
 * String html=fds.getFormattedDataSet(header, body, "htmlTable");
 * </pre></code></blockquote></p>
 *
 * <p><b>Sample Output:</b>  Note the "htmltable" output looks best when formatteddataset.css is included</p>
 * <p align="center"><img src="doc-files/htmlTableSample.jpg" id="htmltablesample2" /></p>
 */

public String getFormattedDataSet(Object header, Object body, String templateName) {
    return getFormattedDataSet(header, body, NULLMAP, templateName);
}


/** Format the passed data using the passed template and pass in dynamic template variables.  Note both the header, and body must either implement
 * the TabularData interface or be objects that have been registered with the TabularDataFactory.
 *
 * <p>
 * <b>Sample Call (using String[], and Object[][] which are both predefined TabularData types):</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String[]header={"fname", "lname"};
 * Object[][] body={{"jeff", "beck"}, {"william", "reid"}};
 * Map map=new TreeMap();
 * map.put("rootElement", "guitarists");
 * String html=fds.getFormattedDataSet(header, body, map, "xml1");
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(Object header, Object body, Map miscData, String templateName) {
       return getFormattedDataSet(header, body, miscData, getTemplate(templateName));
}

/** Format the passed data using the passed template object and pass in dynamic template variables.  Note both the header, and body must either implement
 * the TabularData interface or be objects that have been registered with the TabularDataFactory.
 *
 * <p>
 * <b>Sample Call (using String[], and Object[][] which are both predefined TabularData types):</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String[]header={"fname", "fullname"};
 * Object[][] body={{"jeff", "beck"}, {"william", "reid"}};
 * Map map=new TreeMap();
 * map.put("rootElement", "guitarists");
 * Template template=fds.getTemplate("xml1").copy();// clone so as not to change the original
 * template.initialize("body_cell_data", 0, 2, "##1 ##2");
 * String html=fds.getFormattedDataSet(header, body, map, template);
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(Object header, Object body, Map miscData, Template template) {
    Monitor mon=mon=start("getFormattedDataSet(all)");
    try {
       // FDS works ok when this check is not done (i.e. no exception is thrown).  However, some templates
        // such as htmltable would return table tags with no content in this case.  As the developer probably
        // wouldn't want to display this I return a null instead, so they can check for this and displays something
        // else if this happens.  Note if either a header or a body is passed the template method is called.
        // This allows for example the header to be displayed even if the ResultSet has no data.
       if (header==null && body==null)
          return null;
       else 
          return template.execute(header, body, miscData).toString();
    } finally {
       mon.stop();
    }
}

/** Format the ResultSetConverter using the passed template.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * String html=fds.getFormattedDataSet(fds.getResultSetConverter("select * from table"), "htmlTable");
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(ResultSetConverter rsConverter, String templateName) {
    return getFormattedDataSet(rsConverter.getMetaData(), rsConverter.getResultSet(), templateName);
}

/** Format the ResultSetConverter using the passed template and pass in dynamic template variables.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * Map map=new HashMap();
 * map.put("rootElement", "guitarists");
 * String html=fds.getFormattedDataSet(fds.getResultSetConverter("select * from guitarists"), map, "xml1");
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(ResultSetConverter rsConverter, Map miscData, String templateName) {
    return getFormattedDataSet(rsConverter, miscData, getTemplate(templateName));
}

/** Format the ResultSetConverter using the passed template object and pass in dynamic template variables.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=new FormattedDataSet();
 * Template template=fds.getTemplate("xml1").copy(); // so as not to change the original
 * template.initialize("body_cell_data",0,2,"##2, ##1"); // i.e. beck, jeff in col 2
 * String html=fds.getFormattedDataSet(fds.getResultSetConverter("select * from guitarists"), map, template);
 * </pre></code></blockquote></p>
 */

public String getFormattedDataSet(ResultSetConverter rsConverter, Map miscData, Template template) {
    return getFormattedDataSet(rsConverter.getMetaData(), rsConverter.getResultSet(), miscData, template);
}



/**
 * Sort and format the input on the specified sort column and order (ascending, or descending).  Formatting will be done
 * by the passed in Template object.   Also a Map is passed in that contains extra information accessible in 
 * the template.<br>
 *
 * Note the sortCol will sort the body (Object[][]) using the specified sortOrder ("asc", "desc" are valid).  
 * To sort the first column use a sortCol value of 1 (in the array this would be specified by index 0).  
 * A value greater than the number of columns or an invalid sortOrder throws an exception.<br>
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 *  FormattedDataSet fds=new FormattedDataSet();
 *  Map miscData=new HashMap();
 *  miscData.put("myVar", "HelloWorld");
 *  miscData.put("sortPageName", "mypage.jsp");
 *  Template template=new Template();
 *  ...
 *  // sorts column 2 (array index 1) in ascending order.  possibilites for the sortOrder field are "asc" or "desc"
 *  String html=fds.getSortedText(header, body, miscData, 2, "asc", template); // header=Object[] and body=Object[][]
 * </pre></code></blockquote></p>
 **/
public String getSortedText(Object[] header, Object[][]body, Map miscData, int sortCol, String sortOrder, Template template) {
    int cols=header.length;
    int sortColIndex=sortCol-1; // sortCol starts at 1, and sortColIndex starts at 0.
    String[] sortOrderArr=new String[cols];
    String[] sortOrderGifArr=new String[cols];
    /** 
      Every time the user clicks on a column we should sort according to the sortOrder and toggle the sort order 
      so if the user clicks on the column again it will have the opposite sort order.  All other columns will 
      default to descending order.
     */
    for (int i=0; i<cols; i++) {
        sortOrderArr[i]="desc";
        sortOrderGifArr[i]="";
    }

    Object imagesDirEntry=miscData.get("imagesDir");
    String imagesDir="";
    if (imagesDirEntry!=null)
      imagesDir=imagesDirEntry.toString();
    
    sortOrderArr[sortColIndex]=toggleSortOrder(sortOrder);  // toggle asc to desc or vice versa
    sortOrderGifArr[sortColIndex]="<img src='"+imagesDir+sortOrder+".gif'>";  // put gif indicating sort order in html.

    if (miscData.get("query")==null)
        miscData.put("query", "");
    
    miscData.put("sortOrder", sortOrderArr);  // referenced in template as ##sortOrderThis
    miscData.put("sortOrderGif", sortOrderGifArr); // ##sortOrderGifThis
    ArrayComparator.sort(body, sortColIndex, sortOrder);
    
    // Format the data if an ArrayConverter has been set.
    if (getArrayConverter()!=null)
      body=getArrayConverter().convert(body);  

    return getFormattedDataSet(header, body, miscData, template);
}


/**
 * Sort and format the input on the specified sort column and order (ascending, or descending).  Formatting will be done
 * by the Template object associated with the template name.   Also a Map is passed in that contains extra information accessible in 
 * the template.<br>
 *
 * <p>
 * <b>Sample Call:</b> See other getSortedText(...) methods for an example.
 * </p>
 */

public String getSortedText(Object[] header, Object[][]body, Map miscData, int sortCol, String sortOrder, String templateName) {
    return getSortedText(header, body, miscData, sortCol, sortOrder, getTemplate(templateName));
}

/**
 * Sort and format the ResultSetConverter on the specified sort column and order (ascending, or descending).  Formatting will be done
 * by the Template object associated with the template name.   Also a Map is passed in that contains extra information accessible in 
 * the template.<br>
 * <p>
 * <b>Sample Call: Note the "sortedHTMLTable" template used in the code sample is a default template and so will
 *  so will work out of the box.</b><br><br>
 * <blockquote><code><pre>
 *  FormattedDataSet fds=new FormattedDataSet();
 *  String query="select * from table";
 *  ResultSetConveter rsc=fds.getResultSetConverter(query);
 *  Map miscData=new HashMap();
 *  miscData.put("myVar", "HelloWorld");
 *  miscData.put("sortPageName", "mypage.jsp");
 *  // query must be encoded.  this gets put in the clickable header.
 *  miscData.put("query", "&query="+java.net.URLEncoder.encode(query));
 *  ...
 *  // sorts column 2 (array index 1) in ascending order.  possibilites for the sortOrder field are "asc" or "desc"
 *  String html=fds.getSortedText(rsc, miscData, 2, "asc", "sortedHTMLTable"); // header=Object[] and body=Object[][]
 * </pre></code></blockquote></p>
 */

public String getSortedText(ResultSetConverter rsConverter, Map miscData, int sortCol, String sortOrder, String templateName) {
    return getSortedText(rsConverter.getMetaData(), rsConverter.getResultSet(), miscData, sortCol, sortOrder, templateName);
}

/**
 * Sort and format the query on the specified sort column and order (ascending, or descending).  Formatting will be done
 * by the Template object associated with the template name.   The default DataSource will be used.  
 * Also a Map is passed in that contains extra information accessible in the template.<br>
 *
 * <p>
 * <b>Sample Call:</b> See other getSortedText(...) methods for an example.</p>
 */

public String getSortedText(String query, Map miscData, int sortCol, String sortOrder, String templateName) throws SQLException {
    return getSortedText(AppConstants.DATASOURCE, query, miscData, sortCol, sortOrder, templateName);
}

/**
 * Sort and format the query on the specified sort column and order (ascending, or descending).  Formatting will be done
 * by the Template object associated with the template name.   The specified DataSource will be used.  
 * Also a Map is passed in that contains extra information accessible in the template.<br>
 *
 * <p>Note this method uses the deprecated URLEncoder.encode(String) which was deprecated in 1.4 and
 * replaced by a different method.  However, to keep this library compatible with JDK 1.2 I elected to use
 * the deprecated method instead.  When jdk 1.2 becomes less pervasive the jdk 1.4 method should be used instead.
 * </p>
 *
 * <p>
 * <b>Sample Call:</b> See other getSortedText(...) methods for an example.</p>
 */

public String getSortedText(String dataSource, String query, Map miscData, int sortCol, String sortOrder, String templateName) throws SQLException {
    // For the href clickable to work correctly the query must be encoded.
    // ex.
    // original=select * from musician where fname like 'B%'
    // encoded=select+*+from+musician+where+fname+like+%27B%25%27
    miscData.put("query", "&query="+URLEncoder.encode(query));
    return getSortedText(getResultSetConverter(dataSource, query), miscData, sortCol, sortOrder, templateName);
}

/* toggle between asc and desc */
private String toggleSortOrder(String sortOrder) {
    return (sortOrder==null || "asc".equalsIgnoreCase(sortOrder)) ? "desc" : "asc";
}

/**
 * Using the specified query and DataSource display an html drop down listbox.  The passed selectedItem will
 * be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getDropDownListBox("MyDataSourceName", "select dataValue, displayValue from table", "selectedDataValue");
 * </pre></code></blockquote></p>
 */

public String getDropDownListBox(String dataSource, String query, String selectedItem) throws SQLException {
    return getDropDownListBox(dataSource, query, NULLMAP, selectedItem);
}

/**
 * Using the specified query and DataSource display an html drop down listbox (extra info can be passed in via a Map).  
 * The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getDropDownListBox("MyDataSourceName", "select dataValue, displayValue from table", map, "selectedDataValue");
 * </pre></code></blockquote></p>
 */

public String getDropDownListBox(String dataSource, String query, Map miscData, String selectedItem) throws SQLException {
    String listBox=getFormattedDataSet(dataSource, query, miscData, TemplateConstants.DROPDOWNLISTBOX);
    listBox=sizeList(listBox, 1);
    return formatList(listBox, selectedItem);
}

/**
 * Using the specified query and the default DataSource display an html drop down listbox.  The passed selectedItem will
 * be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getDropDownListBox("select dataValue, displayValue from table", "selectedDataValue");
 * </pre></code></blockquote></p>
 */
public String getDropDownListBox(String query, String selectedItem)  throws SQLException {
    return getDropDownListBox(AppConstants.DATASOURCE, query, selectedItem);
}

/**
 * Using the specified query and default DataSource display an html drop down listbox (extra info can be passed in via a Map).  
 * The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getDropDownListBox("select dataValue, displayValue from table", map, "selectedDataValue");
 * </pre></code></blockquote></p>
 */
public String getDropDownListBox(String query, Map miscData, String selectedItem)  throws SQLException {
    return getDropDownListBox(AppConstants.DATASOURCE, query, miscData, selectedItem);
}

/**
 * Using the specified data (which has to either implement TabularData or have been checked into the TabularData factory)
 * display an html drop down listbox.  The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String[] header={"lastNameValue", "lastNameDisplay"};
 * String[][] body={{"SouzaValue", "SouzaDisplay"}, {"BeckValue", "BeckDisplay"}};
 * String html=fds.getDropDownListBox(header, body, "BeckValue");
 * </pre></code></blockquote></p>
 *
 * <p><b>Sample Output:</b></p>
 * <select name='lastNameValue' size='1' id='lastNameValue_ID'>
 * <option value='SouzaValue'>SouzaDisplay
 * <option value='BeckValue' selected>BeckDisplay
 * </select>
 */
public String getDropDownListBox(Object header, Object body, String selectedItem)  {
    return getDropDownListBox(header, body, NULLMAP, selectedItem);
}

/**
 * Using the specified data (which has to either implement TabularData or have been checked into the TabularData factory)
 * display an html drop down listbox.  Misc data can also be passed in via a Map.  The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String[] header={"lastNameValue", "lastNameDisplay"};
 * String[][] body={{"Souza", "Souza"}, {"Beck", "Beck"}};
 * Map map=new HashMap();
 * map.put("myVar", "myVarValue");
 * String html=fds.getDropDownListBox(header, body, "Beck");
 * </pre></code></blockquote></p>
 */
public String getDropDownListBox(Object header, Object body, Map miscData, String selectedItem)  {
    String listBox=getFormattedDataSet(header, body, miscData, TemplateConstants.DROPDOWNLISTBOX);
    listBox=sizeList(listBox, 1);
    return formatList(listBox, selectedItem);
}


/**
 * Using a ResultSetConverter display an html drop down listbox.  
 * The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select lnameValue, lnameDisplay from table");
 * String html=fds.getDropDownListBox(rsc, "Beck");
 * </pre></code></blockquote></p>
 */
public String getDropDownListBox(ResultSetConverter rsc, String selectedItem)  {
    return getDropDownListBox(rsc.getMetaData(), rsc.getResultSet(), selectedItem);
}

/**
 * Using a ResultSetConverter display an html drop down listbox.  
 * The passed selectedItem will be highlighted.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select lnameValue, lnameDisplay from table");
 * Map map=new HashMap();
 * map.put("myVar", "myVarValue");
 * String html=fds.getDropDownListBox(rsc, map, "Beck");
 * </pre></code></blockquote></p>
 */
public String getDropDownListBox(ResultSetConverter rsc, Map miscData, String selectedItem)  {
    return getDropDownListBox(rsc.getMetaData(), rsc.getResultSet(), miscData, selectedItem);
}

// ListBoxes

/**
 * Using the specified query and DataSource display an html listbox.  
 * The passed selectedItem will be highlighted, and the listbox will be as big as the passed in
 * size specifies. Note except for the size parameter getListBox(...) methods work the same as 
 * getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getListBox("MyDataSource", "select dataValue, displayValue from table", "selectedDataValue", 10);
 * </pre></code></blockquote></p>
 */
public String getListBox(String dataSource, String query, String selectedItem, int size) throws SQLException  {
    return getListBox(dataSource, query, NULLMAP, selectedItem, size);
}

/**
 * Using the specified query and a named DataSource display an html listbox (extra info can be passed in via a Map).  
 * The passed selectedItem will be highlighted.  Note except for the size parameter getListBox(...) methods work the same as 
 * getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br><blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getListBox("MyDataSource", "select dataValue, displayValue from table", map, "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */

public String getListBox(String dataSource, String query, Map miscData, String selectedItem, int size) throws SQLException  {
    String listBox=getFormattedDataSet(dataSource, query, miscData, TemplateConstants.LISTBOX);
    listBox=sizeList(listBox, size);
    return formatList(listBox, selectedItem);
}


/**
 * Using the specified query and default DataSource display an html listbox.  
 * The passed selectedItem will be highlighted.  Note except for the size parameter getListBox(...) methods work the same as 
 * getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getListBox("select dataValue, displayValue from table", "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */
public String getListBox(String query, String selectedItem, int size) throws SQLException {
    return getListBox(AppConstants.DATASOURCE, query, selectedItem, size);
}

/**
 * Using the specified query and default DataSource display an html listbox (extra info can be passed in via a Map).  
 * The passed selectedItem will be highlighted.  Note except for the size parameter getListBox(...) methods work the same as 
 * getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getListBox("select dataValue, displayValue from table", map, "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */
public String getListBox(String query, Map miscData, String selectedItem, int size) throws SQLException {
    return getListBox(AppConstants.DATASOURCE, query, miscData, selectedItem, size);
}

/**
 * Using the specified data (which can either be a TabularData interface or an Object that can implement this interface)
 * display an html listbox. The passed selectedItem will be highlighted.  
 * Note except for the size parameter getListBox(...) methods work the same as getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call: Using ResultSet and ResultSetMetaData as the TabularData types (The code below assumes the ResultSet has already been
 * opened)</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getListBox(resultSet.getMetaData(), resultSet, "BeckValue", 5);
 * </pre></code></blockquote></p>
 *
 * <p><b>Sample Output:</b><br>
  <select name='lastNameValue' size='5' id='lastNameValue_ID'>
  <option value='SouzaValue'>SouzaDisplay
  <option value='BeckValue' selected>BeckDisplay
  <option value='ReidValue'>ReidDisplay
  <option value='HibbertValue'>HibbertDisplay
  <option value='RichardsValue'>RichardsDisplay
  </select> 
  </p>

 */
public String getListBox(Object header, Object body, String selectedItem, int size)  {
    return getListBox(header, body, NULLMAP, selectedItem, size);
}

/**
 * Using the specified data (which can either be a TabularData interface or an Object that can implement this interface)
 * display an html listbox (extra info may be passed in to the template via a Map). The passed selectedItem will be highlighted.  
 * Note except for the size parameter getListBox(...) methods work the same as getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call: Using ResultSet and ResultSetMetaData as the TabularData types (The code below assumes the ResultSet has already been
 * opened)</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getListBox(resultSet.getResultSetMetaData(), resultSet, map, "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */
public String getListBox(Object header, Object body, Map miscData, String selectedItem, int size)  {
    String listBox=getFormattedDataSet(header, body, miscData, TemplateConstants.LISTBOX);
    listBox=sizeList(listBox, size);
    return formatList(listBox, selectedItem);
}

/**
 * Using a ResultSetConverter display an html listbox (extra info may be passed in to the template via a Map). 
 * The passed selectedItem will be highlighted.  Note except for the size parameter getListBox(...) methods 
 * work the same as getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * String html=fds.getListBox(rsc, map, "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */
public String getListBox(ResultSetConverter rsc, String selectedItem, int size) {
    return getListBox(rsc.getMetaData(), rsc.getResultSet(), selectedItem, size);
}

/**
 * Using a ResultSetConverter display an html listbox (extra info may be passed in to the template via a Map). 
 * The passed selectedItem will be highlighted.  Note except for the size parameter getListBox(...) methods 
 * work the same as getDropDownListBox(...) methods.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getListBox(rsc, map, "selectedDataValue", 5);
 * </pre></code></blockquote></p>
 */
public String getListBox(ResultSetConverter rsc, Map miscData, String selectedItem, int size) {
    return getListBox(rsc.getMetaData(), rsc.getResultSet(), miscData, selectedItem, size);
}

// Multi-select ListBoxes

/**
 * Using the specified query and a named DataSource display an html multi-select listbox.  
 * All values in the passed selectedItems array will be highlighted/selected.  The size of the multi-select list
 * box is also passed.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};  
 * String html=fds.getMultiSelectListBox("MyDataSource", "select dataValue, displayValue from table", selectedValues, 5);
 * </pre></code></blockquote></p>
 */
public String getMultiSelectListBox(String dataSource, String query, String[] selectedItems, int size) throws SQLException  {
    return getMultiSelectListBox(dataSource, query, NULLMAP, selectedItems, size);
}

/**
 * Using the specified query and a named DataSource display an html multi-select listbox (extra info can be passed in via a Map).  
 * The passed selectedItems array will be highlighted/selected.  The size parameter specifies the size of the
 * multi-select listbox.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getMultiSelectListBox("MyDataSource", "select dataValue, displayValue from table", map, selectedValues, 5);
 * </pre></code></blockquote></p>
 */
public String getMultiSelectListBox(String dataSource, String query, Map miscData, String[] selectedItems, int size) throws SQLException  {
    String listBox=getFormattedDataSet(dataSource, query, miscData, TemplateConstants.MULTISELECTLISTBOX);
    listBox=sizeList(listBox, size);
    listBox=highLightMultiSelect(listBox, selectedItems);
    return listBox;
}

/**
 * Using the specified query and the default DataSource display an html multi-select listbox.  
 * All values in the passed selectedItems array will be highlighted/selected.  The size of the multi-select list
 * box is also passed.
 *
 * <p>
 * <b>Sample Call:</b><br><br><blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * // both values will be selected in the listbox
 * String html=fds.getMultiSelectListBox("select dataValue, displayValue from table", selectedValues, 5);
 * </pre></code></blockquote></p>
 */

public String getMultiSelectListBox(String query, String[] selectedItems, int size) throws SQLException {
    return getMultiSelectListBox(AppConstants.DATASOURCE, query, selectedItems, size);
}

/**
 * Using the specified query and the default DataSource display an html multi-select listbox (extra info can be passed in via a Map).  
 * The passed selectedItems array will be highlighted/selected.  The size parameter specifies the size of the
 * multi-select listbox.
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getMultiSelectListBox("select dataValue, displayValue from table", map, selectedValues, 5);
 * </pre></code></blockquote></p>
 */

public String getMultiSelectListBox(String query, Map miscData, String[] selectedItems, int size) throws SQLException {
    return getMultiSelectListBox(AppConstants.DATASOURCE, query, miscData, selectedItems, size);
}

/**
 * Use the specified header and body to display an html multi-select lisbox (which must either be an implementation of the TabularData interface or the Objects must 
 * be in the TabularData factory).  The passed selectedItems array will be highlighted/selected.  The size parameter specifies the size of the
 * multi-select listbox.
 *
 * <p>
 * <b>Sample Call: The example below uses ResultSetMetaData and ResultSets both of which are forms of TabularData</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getMultiSelectListBox(resultSet.getMetaData(), resultSet, selectedValues, 5);
 * </pre></code></blockquote></p>
 *
 * <p><b>Sample Output:</b></p><br>
<select name='lastNameValue' size='5' id='lastNameValue_ID' multiple='MULTIPLE'>
<option value='SouzaValue' selected>SouzaDisplay
<option value='BeckValue' selected>BeckDisplay
<option value='ReidValue'>ReidDisplay
<option value='HibbertValue'>HibbertDisplay
<option value='RichardsValue'>RichardsDisplay
</select>
</p>
 */
public String getMultiSelectListBox(Object header, Object body, String[] selectedItems, int size)  {
    return getMultiSelectListBox(header, body, NULLMAP, selectedItems, size);
}

/**
 * Use the specified header and body to display an html multi-select listbox (which must either be an implementation of the TabularData interface or the Objects must 
 * be in the TabularData factory. Also Extra info may be passed in via a Map) The passed selectedItems array will be highlighted/selected.  The size parameter specifies the size of the
 * multi-select listbox.
 *
 * <p>
 * <b>Sample Call: The example below uses ResultSetMetaData and ResultSets both of which are forms of TabularData</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getMultiSelectListBox(resultSet.getMetaData(), resultSet, selectedValues, 5);
 * </pre></code></blockquote></p>
 */

public String getMultiSelectListBox(Object header, Object body, Map miscData, String[] selectedItems, int size)  {
    String listBox=getFormattedDataSet(header, body, miscData, TemplateConstants.MULTISELECTLISTBOX);
    listBox=sizeList(listBox, size);
    listBox=highLightMultiSelect(listBox, selectedItems);
    return listBox;
}

/**
 * Using a ResultSetConverter display an html multi-select listbox.  The passed selectedItems array will 
 * be highlighted/selected.  The size parameter specifies the size of the multi-select listbox.
 *
 * <p>
 * <b>Sample Call: The example below uses ResultSetMetaData and ResultSets both of which are forms of TabularData</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getMultiSelectListBox(rsc, selectedValues, 5);
 * </pre></code></blockquote></p>
 */
public String getMultiSelectListBox(ResultSetConverter rsc, String[] selectedItems, int size)  {
    return getMultiSelectListBox(rsc.getMetaData(), rsc.getResultSet(), selectedItems, size);
}

/**
 * Using a ResultSetConverter display an html multi-select listbox (extra info may be passed into the template via a Map).
 * The passed selectedItems array will be highlighted/selected.  The size parameter specifies the size of the
 * multi-select listbox.
 *
 * <p>
 * <b>Sample Call: The example below uses ResultSetMetaData and ResultSets both of which are forms of TabularData</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * // both values will be selected in the listbox
 * String[] selectedValues={"SouzaValue", "BeckValue"};
 * String html=fds.getRadioButton(rsc, map, selectedValues, 5);<br>
 * </pre></code></blockquote></p>
 */
public String getMultiSelectListBox(ResultSetConverter rsc, Map miscData, String[] selectedItems, int size)  {
    return getMultiSelectListBox(rsc.getMetaData(), rsc.getResultSet(), miscData, selectedItems, size);
}

/** Method that can be used to highlight selected entries in a multi-select listbox **/
protected String highLightMultiSelect(String listBox, String[] selectedItems) {
    // If the value is not null then select items in passed array, else simply return the listbox.
    if (selectedItems!=null) {
     for (int i=0; i<selectedItems.length; i++)
       listBox=formatList(listBox, selectedItems[i]);
    }
       
    return listBox;
    
}




// RadioButtons

/**
 * Using the specified query and DataSource display an HTML radio-button listbox.  
 * A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getRadioButton("MyDataSource", "select dataValue, displayValue from table", "selectedDataValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(String dataSource, String query, String selectedItem) throws SQLException {
    return getRadioButton(dataSource, query, NULLMAP, selectedItem);
}

/**
 * Use the specified query and DataSource to display an HTML radio-button listbox.  
 * A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getRadioButton("MyDataSource", "select dataValue, displayValue from table", "selectedDataValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(String dataSource, String query, Map miscData, String selectedItem) throws SQLException {
    String radioButton = getFormattedDataSet(dataSource, query, miscData, TemplateConstants.RADIOBUTTON);
    return formatRadioButton(radioButton, selectedItem);
}

/**
 * Using the specified query and the default DataSource display an HTML radio-button listbox.  
 * A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getRadioButton("select dataValue, displayValue from table", "selectedDataValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(String query, String selectedItem) throws SQLException {
    return getRadioButton(AppConstants.DATASOURCE, query, selectedItem);
}

/**
 * Use the specified data (Either the TabularData interface or an object that has been placed in the TabularData
 * factory.) to display an html radio button listbox.  A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b> The sample uses a ResultSet and ResultSetMetaData, however other types of TabularData are
 * also supported via this method.<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * String html=fds.getRadioButton(resultSet.getMetaData(), resultSet, "BeckValue");
 * </pre></code></blockquote></p>
 *
 * <p><b>Sample Output:</b></p>  
 *
<input  name=lastNameValue value=SouzaValue type=radio>SouzaDisplay
<input  name=lastNameValue value=BeckValue checked type=radio>BeckDisplay
<input  name=lastNameValue value=ReidValue type=radio>ReidDisplay
<input  name=lastNameValue value=HibbertValue type=radio>HibbertDisplay
<input  name=lastNameValue value=RichardsValue type=radio>RichardsDisplay
 */

public String getRadioButton(Object header, Object body, String selectedItem)  {
    return getRadioButton(header, body, NULLMAP, selectedItem);
}

/**
 * Use the specified data (Either the TabularData interface or an object that has been placed in the TabularData
 * factory) to display an html radio button listbox (extra info may be passed in via a Map).  A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b> The sample uses a ResultSet and ResultSetMetaData, however other types of TabularData are
 * also supported via this method.<br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getRadioButton(resultSet.getMetaData(), resultSet, map, "BeckValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(Object header, Object body, Map miscData, String selectedItem)  {
    String radioButton = getFormattedDataSet(header, body, miscData, TemplateConstants.RADIOBUTTON);
    return formatRadioButton(radioButton, selectedItem);
}

/**
 * Use a ResultSetConverter to display an html radio button listbox.  A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * String html=fds.getRadioButton(rsc, "BeckValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(ResultSetConverter rsc, String selectedItem)  {
    return getRadioButton(rsc.getMetaData(), rsc.getResultSet(), NULLMAP, selectedItem);
}

/**
 * Use a ResultSetConverter to display an html radio button listbox (extra info accessible in the template can 
 * be passed in via a Map).  A value is passed in for the highlighted/selected data value.  
 *
 * <p>
 * <b>Sample Call:</b><br><br>
 * <blockquote><code><pre>
 * FormattedDataSet fds=FormattedDataSet.createInstance();
 * ResultSetConverter rsc=fds.getResultSetConverter("select dataValue, displayValue from table");
 * Map map=new HashMap();
 * map.put("date", new Date()); // referenced in template with ##date
 * String html=fds.getRadioButton(rsc, map, "BeckValue");
 * </pre></code></blockquote></p>
 */
public String getRadioButton(ResultSetConverter rsc, Map miscData, String selectedItem)  {
    return getRadioButton(rsc.getMetaData(), rsc.getResultSet(), miscData, selectedItem);
}




/** Returns true if the string is null or empty */
private boolean isEmpty(String string) {
    return (string==null || "".equals(string.trim()));
}

/* Call JAMon monitoring */
private Monitor start(String locator) {
    return AppConstants.start("FormattedDataSet."+locator);

}

/* Log debug message */
private void log(String logStr) {
   Utils.logDebug(logStr);
}

/** Enable/Disable debugging.  This enables/disables logging for all classes in the FormattedDataSet API. 
 * Debugging is disabled by default.
 */
public void setDebug(boolean debug) {
    Utils.setDebug(debug);
}

/** Enable/Disable debugging.  This determines if debug mode is currently enabled. */
public boolean getDebug() {
    return Utils.getDebug();
}


/** Change the size of an html listbox passed in as a String */
protected String sizeList(String listBox, int size) {
    return AppConstants.replaceString(listBox, "1", String.valueOf(size));
}


/** Select/hightlight an item in an html list box */
protected String formatList(String listBox, String selectedItem)  {
    // If no item was selected return the list box as is, else select 'selectedItem' as the default value
    if (isEmpty(selectedItem))
        return listBox;
    else {
        // Replace 
        //      <option value='SouzaValue'>SouzaDisplay 
        //  with 
        //      <option value='SouzaValue' selected>SouzaDisplay 
        selectedItem = "'"+selectedItem+"'";  
        listBox = AppConstants.replaceString(listBox, selectedItem, selectedItem+" selected");
        return listBox;
      }

}



/** Select/highlight an item in an html radio button list box */
protected String formatRadioButton(String radioButton, String selectedItem)  {
    if (isEmpty(selectedItem))
        return radioButton;
    else {
        // Replace <INPUT value=ssouza name=groupname type=radio>ssouza<br>
        // With <INPUT value=ssouza checked name=groupname type=radio>ssouza<br>
        radioButton = AppConstants.replaceString(radioButton, selectedItem+" ", selectedItem+" checked ");
        return radioButton;
    }
}



/** Test code for the FormattedDataSet */
public static void main (String args[]) throws Exception {

    String[] header={"FirstName", "LastName"};
    String[][] body={
                      {"SouzaValue", "1SouzaDisplay"},
                      {"BeckValue",  "2BeckDisplay"},
                      {"ReidValue",  "3ReidDisplay"},
                      {"OsterbergValue", "4OsterbergDisplay"},
                     };
    String[] selectedItems={"SouzaValue", "ReidValue"};

    Monitor mon1=MonitorFactory.start();
    FormattedDataSet fds = new FormattedDataSet();
    fds.setDebug(true);
    ColBoundary.setDebug(true);  // a very verbose testing mode that isn't enabled by developers, but only when testing FDS

    Utils.log("\n\n"+fds.getListBox(header, body, "BeckValue", 2));
    // The first call to fds counts initialization of factories, so I'm leaving it out ofthe timings    
    Monitor mon2=MonitorFactory.start();  
    Utils.log("\n\n"+fds.getDropDownListBox(header, body, "SouzaValue"));
    Utils.log("\n\n"+fds.getMultiSelectListBox(header, body, selectedItems, 10));
    Utils.log("\n\n"+fds.getRadioButton(header, body, "BeckValue"));
     
    Utils.log("\n\n"+
                    "<names>\n"+
                        fds.getFormattedDataSet(header, body, "xml")+
                     "</names>"
                    );
    
    Map miscData=new HashMap();
    miscData.put("rootElement", "mynames");
    miscData.put("sortPageName", "MySortPage.jsp");
        
    Utils.log("\n\n"+fds.getFormattedDataSet(header, body, miscData, "xml1"));
    Utils.log("\n\n"+fds.getFormattedDataSet(header, body, miscData, fds.getTemplate("xml1")));
    Utils.log("\n\ncol 1 desc\n"+fds.getSortedText(new ResultSetConverter(header, body), miscData, 1, "desc", "sortedHTMLTable"));

    Utils.log("\n\nnull data - display header\n"+fds.getFormattedDataSet(header, null, "basicHtmlTable"));
    Utils.log("\n\nnull header - display data\n"+fds.getFormattedDataSet(null, body, "basicHtmlTable"));
    Utils.log("\n\nnull header and data - return null\n"+fds.getFormattedDataSet((String[])null, null, "basicHtmlTable"));
    
    miscData.put("query", "&query=select * from tablename");
    miscData.put("imagesDir", "images/");
    Utils.log("\n\ncol 2 asc\n"+fds.getSortedText(new ResultSetConverter(header, body), miscData, 2, "asc", "sortedHTMLTable"));

    Utils.log("\nTime executing 7 calls to getFormattedDataSet() (excludes initialization): "+mon2.stop());                   
    Utils.log("\nTime executing all 8 calls to getFormattedDataSet() (mostly initialization time): "+mon1.stop());
    
}


}

