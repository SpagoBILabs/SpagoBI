/*
 * NullConverter.java
 *
 * Created on February 20, 2005, 4:02 PM
 */

package com.fdsapi;

/**
 *
 * Converter that simply takes an object as input and returns it unchanged.  This is a noop or
 * a Null object implementation.  It is a stateless object as it does nothing!
 * 
 *  <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/NullConverter.htm">View Code</a>
 */
public class NullConverter implements Converter {
    // Being as this object has not state there is no reason to continually create one.
    private static final Converter NULL_SINGLETON=new NullConverter();
    
    /** Creates a new instance of NullConverter */
    public NullConverter() {
    }
    
    public Object convert(Object inputObj) {
        return inputObj;
    }
    
    public Converter createInstance() {
        return NULL_SINGLETON;
    }
    
}
