package com.fdsapi;  // FormattedDataSet API



import java.util.*;
import org.apache.oro.text.regex.*;
import com.jamonapi.utils.*;

/** <p>This class is used to run Regular Expressions.  It uses the jakarta projects ORO regular expression parser. 
 * Java 1.2 did not have regular expressions built into the language.  By abstracting the concept of Regular Expressions
 * into a class I control dependencies of ORO are not embedded throughtout my code and only this class needs to be 
 * changed if I want to go to the newer java 1.4 Regular Expression approach.  If I do this the FormattedDataSet
 * API will not work with java 1.2 (not desireable at this time).</p> 
 *
 * <p>This code requires jakartas ORO jar to be compiled: (http://jakarta.apache.org/oro/)</p>
 *
 * <p>Sample usage from main method:</p>
 * <blockquote><code><pre>
 *  final String RE="##(hello|world)"; 

    RegularExpression re=new RegularExpression(RE);
    re.setSourceString("##hello ##miscData1 ##steve ##souza ##world ##this ##rownum ##headerthis ##3");

    while (re.next()) {
        System.out.println(re.getParen(0));
        System.out.println(re.getParen(1));>
    }
 * </pre></code></blockquote>

 *<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/RegularExpression.htm">View Code</a>
 */
public class RegularExpression 
{
    private PatternCompiler compiler=new Perl5Compiler();  // compiles the regular expression
    private Pattern pattern;  // holds the regular expression
    private PatternMatcher matcher=new Perl5Matcher(); // holds the current match
    private PatternMatcherInput input;  // holds input string that should be searched


    public RegularExpression(String regularExpressionStr) {
        try {
            // Regexpression processes multiple lines like they are one and ignores case in the search.
            pattern=compiler.compile(regularExpressionStr,Perl5Compiler.CASE_INSENSITIVE_MASK | Perl5Compiler.SINGLELINE_MASK);
        } catch(Exception e) {
            String err=Misc.getClassName(this)+" contructor error: "+e;
            throw new  RuntimeExceptionBase(err, e);
        }            

    }

    /** Creates a RegularExpression object with the specified regular expression*/

    public static RegularExpression createInstance(String regularExpressionStr)  {
          return new RegularExpression(regularExpressionStr);
    }

    /** Get contents of the passed paren number */
    public String getParen(int parenNumber)     {
        return matcher.getMatch().group(parenNumber);
    }

    /** Set source string to be searched for the regular expression passed into the constructor */
    public void setSourceString(String sourceString)     {
        input=new PatternMatcherInput(sourceString);
    }

    /** returns true while the input still has pattern matches.  */
    public boolean next()     {
        return matcher.contains(input,pattern);
    }


    public String[] split(String stringToSplit)     {
        Collection results=new ArrayList();

        Util.split(results, matcher, pattern, stringToSplit);
        String[] string = new String[results.size()];
        results.toArray(string);

        return string;
    }

  /** Sample code for testing. */
  public static void main(String[] args) throws Exception {
    final String RE="##(hello|world)";  

    RegularExpression re=new RegularExpression(RE);
    re.setSourceString("##hello ##miscData1 ##steve ##souza ##world ##this ##rownum ##headerthis ##3");

    while (re.next()) {
        System.out.println(re.getParen(0));
        System.out.println(re.getParen(1));
    }

    }
}

