package com.fdsapi;  // FormattedDataSet API


import java.sql.*;
import com.jamonapi.*;
import com.fdsapi.arrays.*;
/** <p>Class that converts a Java ResultSet to an Object[][] array.  Some advantages of doing this
 * are:</p><br>
 * 1) The data can be manipulated after the database connection is closed<br>
 * 2) The data can be cached<br>
 * 3) Array functions such as sort may be used on the data<br>
 * 4) Data Can be serialized<br>
 * 5) Data can be iterated over many times in any direction<br>
 * 6) You can get the number of rows within a ResultSetConverter (you can't do this with ResultSets)<br>
 * 
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/ResultSetConverter.htm">View Code</a>
 */

public class ResultSetConverter extends java.lang.Object
{
   private final String[] metaData;// contains column name of the ResultSet (ResultSet metadata)
   private final Object[][] resultSet;// 2 dimensional array version of the ResultSet
   private ArrayHeaderLocator locator;

   /** Convert the ResultSet to a ResultSetConverter.  Note the ResultSet will be iterated through
    * in this constructor and so if the ResultSet only supports one iteration an exception will be 
    * thrown if the calling code attempts iteration a second time.
    */
   public ResultSetConverter(ResultSet rs) throws SQLException {
        Monitor mon=AppConstants.start("ResultSetConverter(ResultSet)");
        try {
            ResultSetUtils rsu=ResultSetUtils.createInstance();

            metaData  = rsu.getColumnNames(rs.getMetaData());
            resultSet = rsu.resultSetToObjectArray(rs);
            locator   = new ArrayHeaderLocator(metaData, true);
        }
        finally {
           mon.stop();
        }

   }

   /** A constructor that supports converting header and body arrays to a ResultSetConverter */
   public ResultSetConverter(String[] metaData, Object[][] resultSet) {
       this.metaData=metaData;
       this.resultSet=resultSet;
       // true means throw exceptions if column name doesn't exit in ArrayHeaderLocator
       this.locator = new ArrayHeaderLocator(metaData, true);

   }


   /** Returns at 1 dimensional array of column names from the ResultSet. */
   public String[] getMetaData() {
       return metaData;
   }

   /** Returns a 2 dimensional array containing the data in the ResultSet */
   public Object[][] getResultSet() {
       return resultSet;
   }

   /** Returns true if the ResultSet has no rows */
   public boolean isEmpty() {
       return getRowCount()==0;
   }

   /** Returns the number of rows in the ResultSet */
   public int getRowCount() {
       return (resultSet==null) ? 0 : resultSet.length;
   }

   /** Returns the number of columns in the ResultSet */
   public int getColumnCount() {
     return (metaData==null) ? 0 : metaData.length;   
   }
   
   /** Returns the data at the specified row, col location.  Being as the data is an array
    * the row and column indices start at 0 and not 1.
    **/
   public Object getCellData(int row, int col) {
       return resultSet[row][col]; 
   }
   
   /** Returns the data at the specified row, col location with the col location corresponding
    * to the position of the passed in column name.  Being as the data is an array
    * the row index starts at 0 and not 1.
    **/
   public Object getCellData(int row, String colName) {
       return resultSet[row][locator.getColNum(colName)];
   }

}

