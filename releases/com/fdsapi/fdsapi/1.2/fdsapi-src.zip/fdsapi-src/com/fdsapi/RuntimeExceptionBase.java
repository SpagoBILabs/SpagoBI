package com.fdsapi;  // FormattedDataSet API


import java.io.*;

/** RuntimeException used in FormattedDataSet code.  It can also hold the original Exception. 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/RuntimeExceptionBase.htm">View Code</a>
 */
public class RuntimeExceptionBase extends RuntimeException {
    Exception exception;
    public RuntimeExceptionBase() {
        
    }
    
    public RuntimeExceptionBase(String exceptionStr) {
        super(exceptionStr);
        log("RuntimeExceptionBase error: "+exceptionStr);
        printStackTrace();
    }
    
    public RuntimeExceptionBase(String exceptionStr, Exception e) {
        super(exceptionStr);
        exception=e;
        log("RuntimeExceptionBase error: "+exceptionStr);
        exception.printStackTrace();
    }
    
    /* get Stack trace as message */
    public String getStackTraceAsString() {
        if (exception==null) {
            return "";
        } else {
            PrintWriter writer=new PrintWriter(new StringWriter());
            exception.printStackTrace(writer);
            return writer.toString();
        }
    }
    

    /* Log debug message */
   private void log(String logStr) {
     Utils.log(logStr);
  }

    
}
