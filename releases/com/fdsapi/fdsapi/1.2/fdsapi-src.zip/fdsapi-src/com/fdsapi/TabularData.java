package com.fdsapi;  // FormattedDataSet API

/** <p>A shared abstraction for all types of TabularData (1 and 2 dimensional arrays, result sets, result set metadata
and many other types of data can be viewed as a the same with this interface.  The abstraction is cell based 
and cells start at (1,1) (even arrays).  The getCellData() methods retrieve any cell data on the current row only.  
Arrays can retrieve cells on any row, but result sets can't so I made the abstraction work to the more
limited ResultSets capability.  This limitation also means that data can only iterated through once.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularData.htm">View Code</a>
*/

public interface TabularData extends java.io.Serializable
{
// note there is probably a common shared abstraction between this class and dataset.  this should be put in some 
// form of iterator.  and instantiate 2 iterators.  one for rows and one for cells!!!!!

    /** Return cell data in the current rows specified column */
    public Object getCellData(int col); 
    
    /** Return current cell data (the current row and current column) */
    public Object getCellData();    

    /** Return the Iterator that can iterate through the TabularData's rows */
    public DataIterator getRowIterator();

    /** Return the Iterator that can iterate through the TabularData's columns */
    public DataIterator getColIterator();

    /** Factory method that returns a TabularData instance.  The passed object is the underlying 
     data that will be iterated (i.e. ResultSet, Object[][] etc)
     */
    public TabularData createInstance(Object data);

    /** Get the Header (which is also TabularData) */
    public TabularData getHeader();
    
    /** Set the Header (which is also TabularData) */
    public void setHeader(TabularData header);

    public int NOTUSED=-1;
}

