package com.fdsapi;  // FormattedDataSet API

/** TabularData for Object[] that allows the FormattedDataSet to support them. 
<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularData1DimArray.htm">View Code</a> 
 
 */
public class TabularData1DimArray extends TabularDataBase
{
private Object[] data;


public TabularData1DimArray() {
}

public TabularData1DimArray(Object[] data) {
  this(data, 1, (data==null) ? 0 : data.length);
}

protected TabularData1DimArray(Object[] data, int numRows, int numCols) {
    super(numRows, numCols);
    this.data=data;
}


/** Note to make arrays indices start at 1 rather than 0 1 is subtracted from the iterator to get the 
proper data value.
*/

private int getCurrentCol() {
    return colIterator.getCurrentItemNumber()-1;
}

public Object getCellData(int col) {
  return data[col-1];  
}

public Object getCellData() {
  return data[getCurrentCol()];
}


public TabularData createInstance(Object data) {
    Object[] castedData=(Object[]) data;
    return new TabularData1DimArray(castedData);
}
}

