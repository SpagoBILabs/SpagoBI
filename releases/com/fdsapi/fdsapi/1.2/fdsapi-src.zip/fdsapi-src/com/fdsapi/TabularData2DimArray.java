package com.fdsapi;  // FormattedDataSet API

/** TabularData for Object[][] that allows the FormattedDataSet to support them. 
<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularData2DimArray.htm">View Code</a> 
 */

public class TabularData2DimArray extends TabularDataBase
{
private Object[][] data;


public TabularData2DimArray() {

}

public TabularData2DimArray(Object[][] data) {
    this(data, (data==null) ? 0 : data.length, (data==null || data.length==0) ? 0 : data[0].length);
}

protected TabularData2DimArray(Object[][] data, int numRows, int numCols) {
    super(numRows, numCols);
    this.data=data;
}

  /**
Used to return the column (y) value of the current row in the result set.  Note that the x parameter is ignored, 
but included to make the interface consistent with ancestor interfaces.

*/

private int getCurrentRow() {
    return rowIterator.getCurrentItemNumber()-1;
}

private int getCurrentCol() {
    return colIterator.getCurrentItemNumber()-1;
}

public Object getCellData(int col) {
  return data[getCurrentRow()][col-1];  
}

public Object getCellData() {
  return data[getCurrentRow()][getCurrentCol()];  
}

public TabularData createInstance(Object data) {
    Object[][] castedData = (Object[][]) data;
    return new TabularData2DimArray(castedData);
}
}

