package com.fdsapi;  // FormattedDataSet API

/** Base class for TabularData that provides standard default behaviour for the TabularData interface.
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataBase.htm">View Code</a>
 */
public abstract class TabularDataBase extends java.lang.Object implements TabularData
{
    protected DataIterator rowIterator;
    protected DataIterator colIterator;
    private TabularData headerTabData=TabularDataEmpty.createInstance();

    protected TabularDataBase() {
    }

    protected TabularDataBase(int numRows, int numCols) {
        createRowIterator(numRows);
        createColIterator(numCols);
    }

    abstract public Object getCellData(int col);
    abstract public Object getCellData();
    abstract public TabularData createInstance(Object data);

    public DataIterator getRowIterator() {
        return rowIterator;
    }


    public DataIterator getColIterator() {
        return colIterator;
    }

    protected void createRowIterator(int numRows) {
        rowIterator = createIterator(numRows);
    }

    protected void createColIterator(int numCols) {
        colIterator = createIterator(numCols);
    }

    private DataIterator createIterator(int numElements) {
        return new DataIteratorBase(numElements);
    }

    public TabularData getHeader() {
        return headerTabData;
    }

    public void setHeader(TabularData header) {
        headerTabData=header;
    }
}

