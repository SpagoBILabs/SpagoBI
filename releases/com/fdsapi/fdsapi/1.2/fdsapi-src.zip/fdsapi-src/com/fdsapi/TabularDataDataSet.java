package com.fdsapi;  // FormattedDataSet API

/** TabularData for DataSet[] that allows the FormattedDataSet to support them. This is a bizarre one as
 DataSet[] are now viewed as TabularData (usually DataSets contain TabularData).  It is used for grouping 
 header, body and composite DataSets together. 
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataDataSet.htm">View Code</a>
 */


public class TabularDataDataSet extends TabularDataBase
{
private DataSet[] data;


public TabularDataDataSet() {

}

public TabularDataDataSet(DataSet[] data) {
  this(data, data.length, 1);    
}

protected TabularDataDataSet(DataSet[] data, int numRows, int numCols) {
    super(numRows, numCols);
    this.data=data;
}



public Object getCellData(int col) {
  return data[rowIterator.getCurrentItemNumber()-1].execute();  
}


public Object getCellData() {    
  return data[rowIterator.getCurrentItemNumber()-1].execute();  
}


public TabularData createInstance(Object data) {
    DataSet[] castedData = (DataSet[])data;
    return new TabularDataDataSet(castedData);

}

}

