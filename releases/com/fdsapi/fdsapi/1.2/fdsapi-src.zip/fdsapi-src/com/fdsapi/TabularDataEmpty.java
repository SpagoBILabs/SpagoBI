package com.fdsapi;  // FormattedDataSet API

/** Null TabularData object.  Null objects allow code to be written the same way whether an object exists
 * or doesn't (i.e. the null object).  This is a refactoring mentioned in Martin Fowler's Refactoring book.
 *
 *
 *<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataEmpty.htm">View Code</a>
 */

public class TabularDataEmpty extends TabularDataBase
{
    public TabularDataEmpty() {

    }


    protected TabularDataEmpty(int numRows, int numCols) {
        super(numRows, numCols);
    }

    private static TabularData tabularData = new TabularDataEmpty(NOTUSED, NOTUSED);

    public static TabularData createInstance() {
        return tabularData;
    }

// these methods should never need to be called as the rowcount and columncount will always be 0.

    public Object getCellData(int col) {
        return "";
    }

    public Object getCellData()  {
        return "";
    }

    public TabularData createInstance(Object data) {
        return tabularData;
    }
}

