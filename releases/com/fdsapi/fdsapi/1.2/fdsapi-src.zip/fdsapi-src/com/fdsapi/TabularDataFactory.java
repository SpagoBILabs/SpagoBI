package com.fdsapi;  // FormattedDataSet API


import java.sql.*;
import java.util.*;
import com.jamonapi.utils.Logger;
import com.jamonapi.utils.Misc;

/** 
Class used to create all forms of Tabular Data such as 2 dimensional arrays and ResultSets have 
the same interface. This is an example of the Gang of 4 Facade and Factory design patterns.  
Developers may also check there own types of TabularData into the factory.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataFactory.htm">View Code</a>
*/

public class TabularDataFactory extends java.lang.Object
{
    private Collection factories = new ArrayList();  
    static private TabularDataFactory tabularDataFactory = new TabularDataFactory();

    /** Create a TabularDataFactory */
    public static TabularDataFactory createInstance() {
        return tabularDataFactory;
    }

/* Log debug message */
private void log(String logStr) {
   Utils.logDebug(logStr);
}


    protected TabularDataFactory()    {
        // The factory is searched in order for matches so the more specific the data type the sooner it should appear
        // in the list.  This way String[][] will match Object[][] before Object[]. This means that order is important
        // in the following calls to addTabularDataFactory()
        log("**** TabularDataFactory Constructor - start populating TabuldarDataFactory");
        addTabularDataFactory(null, new TabularDataEmpty());  // null object for TabularData
        addTabularDataFactory(ResultSet.class, new TabularDataResultSet());
        addTabularDataFactory(ResultSetMetaData.class, new TabularDataRSMD());
        addTabularDataFactory(DataSet[].class, new TabularDataDataSet());
        addTabularDataFactory(Object[][].class, new TabularData2DimArray());
        addTabularDataFactory(Object[].class, new TabularData1DimArray());
        log("**** TabularDataFactory Constructor - end populating TabuldarDataFactory");

    }



    static private class TabularDataFactoryEntry  {
        protected TabularDataFactoryEntry(Class factoryKey, TabularData factory) {
            this.factoryKey = factoryKey;
            this.factory    = factory;
            className       = (factoryKey==null) ? null : factoryKey.getName();
        }

        public Class factoryKey;
        public TabularData factory;
        public String className;
    }





    // TabularData objects also serve as their own factory.
    public void addTabularDataFactory(Class factoryKey, TabularData factory) {
        log("Initializing TabularDataFactory="+factoryKey);
        factories.add(new TabularDataFactoryEntry(factoryKey, factory));
    }



    /** <p>Return a TabularData object for the passed in Object.  If the passed in object type (or one of its 
    ancestors) is not in the factory then a RuntimeException will be returned.</p>
    
    <b>Sample Call:</b><br><blockquote><code><pre>
     * TabularData tabData=TabularDataFactory.createInstance().getTabularData(resultSet);
     * </pre></code></blockquote>
    */
    public TabularData getTabularData(Object data) {
        // If data passed was already TabularData there is no need to do anything further.
        if (data instanceof TabularData)
            return (TabularData) data;
        
        Class dataClass = (data==null) ? null : data.getClass();
        String dataClassName = (data==null) ? null : data.getClass().getName();

        TabularData factory=null;
        TabularDataFactoryEntry factoryEntry;

        /* 
        look for an exact data type match first.  If this fails look to see that the passed data is directly 
        assignable to a Class type in the factory.  Both tests are done to avoid having an exception type 
        thrown for a datatype that is valid such as String[][] (It matches on Object[][]).  
        Note it would also match on Object[] so the order of the elements in the ArrayList is important.  
        It selects the first one that is found.
        */
        Iterator iterator = factories.iterator();

        while (iterator.hasNext()) {
                // Check to see if the passed in object is a class lower in the inheritance chain.
                // If so the parents factory will work (i.e. Object[][] factory will work for any 2 dim
                // object array such as String[][])
                factoryEntry = (TabularDataFactoryEntry) iterator.next();

                // avoid null exceptions with String.equals() with this if
                // this if matches on the null object being passed
                if (factoryEntry.className==null) {
                   // both are null so return the factory entry
                   if (dataClassName==null)  {
                     factory = factoryEntry.factory;
                     break;
                   }
                }                   
                // The data class is the same or the data class can be typecast to factory key type
                else if (factoryEntry.className.equals(dataClassName) || 
                       factoryEntry.factoryKey.isAssignableFrom(dataClass))  
                   {
                        factory = factoryEntry.factory;
                        break;
                    }
            }


        // The type was not in the factory
        if (factory==null)  {
                String errorMsg=Misc.getClassName(this)+" error.  The following data type does not have a TabularData factory: "+data.getClass().getName();
                throw new  RuntimeExceptionBase(errorMsg);
        } else {
            return factory.createInstance(data);
        }

    }
}

