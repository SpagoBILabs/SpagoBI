package com.fdsapi;  // FormattedDataSet API

import java.sql.*;

/** TabularData for ResultSetMetaData that allows the FormattedDataSet to support them. 
 *
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataRSMD.htm">View Code</a>
 *
 */

public class TabularDataRSMD extends TabularDataBase
{
 private ResultSetMetaData data;

public TabularDataRSMD() {

}

public TabularDataRSMD(ResultSetMetaData data) throws SQLException {
  this(data, 1, data.getColumnCount());
}

protected TabularDataRSMD(ResultSetMetaData data, int numRows, int numCols) {
    super(numRows, numCols);
    this.data = data;
}


public Object getCellData(int col) {
  try {
        return data.getColumnLabel(col);  
  } catch (Exception e) {
      throw new RuntimeExceptionBase("Error getting cell data for column: "+col, e);
  }      

}


public Object getCellData() {
    try {
        return data.getColumnLabel(colIterator.getCurrentItemNumber());  
    } catch (Exception e) {
      throw new RuntimeExceptionBase("Error getting cell data for column: "+colIterator.getCurrentItemNumber(), e);
    }      

}

public TabularData createInstance(Object data) {
    try {
        ResultSetMetaData castedData = (ResultSetMetaData)data;
        return new TabularDataRSMD(castedData);
    } catch (Exception e) {
      throw new RuntimeExceptionBase("Error getting ResultSetMetaData column count.");
    }      


}
}

