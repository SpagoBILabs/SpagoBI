package com.fdsapi;  // FormattedDataSet API

import java.sql.*;
import com.jamonapi.utils.*;

/** TabularData for ResultSets that allows the FormattedDataSet to support them.
 
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TabularDataResultSet.htm">View Code</a>
 */

public class TabularDataResultSet extends TabularDataBase
{
private ResultSet data;

public TabularDataResultSet() {
}

public TabularDataResultSet(ResultSet data) throws SQLException {
   this(data, NOTUSED, data.getMetaData().getColumnCount());
}
protected TabularDataResultSet(ResultSet data, int numRows, int numCols) {
    super(numRows, numCols);
    this.data = data; // see note in creatRowIterator() below
    rowIterator=new DataIteratorResultSetRow(data);
}

public Object getCellData(int col) {
  try {
        return data.getObject(col);  // returns column of result sets current row
  } catch (Exception e) {
      throw new RuntimeExceptionBase("Error in "+Misc.getClassName(this)+".getCellData("+col+")", e);
  }      

}



public Object getCellData() {
  try {
    return data.getObject(colIterator.getCurrentItemNumber());  // returns column of result sets current row
  } catch (Exception e) {
      throw new RuntimeExceptionBase("Error in "+Misc.getClassName(this)+"getCellData("+colIterator.getCurrentItemNumber()+")", e);
  }      

}


protected void createRowIterator(int numRows) {
    // no op because creating the rowIterator depends on data being assigned already.  When createRowIterator()
    // is called from the parent classes constructor data has not been assigned yet.  creating a data iterator is
    // done in this classes constructor instead.
}


public TabularData createInstance(Object data) {
    try {
        ResultSet castedData = (ResultSet)data;
        return new TabularDataResultSet(castedData);
  } catch (Exception e) {
      throw new RuntimeExceptionBase("Error getting ResultSetMetaData Column count "+Misc.getClassName(this), e);
  }      

}
}

