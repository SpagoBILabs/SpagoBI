package com.fdsapi;  // FormattedDataSet API


import java.util.*;
import com.jamonapi.*;
import com.jamonapi.utils.*;

/** Object that represents a file/String template in memory.  Template files are parsed once into a Template
 * object and the program uses this format from that point on.  
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/Template.htm">View Code</a>
 */

public class Template extends java.lang.Object implements Cloneable
{
  // There will be one DataSetMap entry in the dataSetsMaps Map 
  // for each of the template tag types supported by templates.  
  // At the time of this writing there were 27 of them 
  // (i.e. body_cell_prefix, body_cell_data etc.).  This class 
  // will parse the template and make an in memory version of it.

/*

phase I fixes
- i temporarily made colboundary return empty string when an entry doesn't exist in the hashmap() for miscdata.  this
 *should be configurable to either throw an exception or return empty string 
- revisit exceptions vs runtimeexceptions.  maybe at least have methods throw SQLException 4/22/03
- make fds, templates cloneable, make sure classpath at the server level doesn't cause problems.
- change getTemplates().get(templateName) to getTemplate(templateName);
- allow use of tabulardata not in factory
x - take out of powerj and into netbeans
- repackage with jamon.  
- change templates to put everything but value in comment
- add dataset formatter capability (chained formatters ##1.dollar, and/or formatter==caps.encode
- reformat tags <!-- type==query query==select * from table -->

- ???fix formatted data set to work with new Object[0] and new Object[0][0] or fix the iterators????

- add chained datasets i.e. 0,1 calls display data and email.
- somehow make inheritance work even if the whole template is body_row_data
- add sort template default, and alternating table template
- add xml tabulardata interface

- check synchronization and access level for methods
- ???get datasetfactory not to have to matter the order that things were loaded in
- ??have templates work against tabular data directly without using tabdatafactory as an option

- update template users guide
- make logging by application
- better template parsing erros
- inherit from DataSetBase not DataSet
- move the concept of odd even outside of the dataset and give the ability to declaratively specify this in 
the template for all datasets (maybe body_cell_data 0,1,2 i.e every even or body_cell_data -->every=2

- add monitoring (ability to add prefix to monitoring i.e. cors), add logging options
- change package name
- can DataIterator be changed to an enumeration or Iterator
- create containers in default template string
- clean up conflicting clases between jamonapi and gsawebdev (appconstants and resultsetutils)
- code metrics
*/

  private TabularDataFactory tabularDataFactory;
  private DataSetFactory dataSetFactory;
  private DataSet[] factoryDataSets; // body, header, composite used as a factory object and cloned
  private int bufferSize=TemplateConstants.DEFAULT_BUFFERSIZE;
  private String contents="";
  private int initializeNum=0;

  public Template() {
      tabularDataFactory=TabularDataFactory.createInstance();
      dataSetFactory=DataSetFactory.createInstance();
      factoryDataSets=dataSetFactory.getDefaultDataSets();
  }
  
  /** Performs action to be Taken against the TabularData */
  public Object execute(Object headerData, Object bodyData) {
      // creates a HashMap() to avoid a null pointer Exception in ColBoundary, but 
      // the HashMap() is really just a null object.
      return execute(headerData, bodyData, new HashMap());
  } 


  /** Performs action to be Taken against the TabularData and pass in a map of extra 
   info accessed by the Template (##variables)*/
  public Object execute(Object headerData, Object bodyData, Map miscDataMap) {

       final int HEADER=0;
       DataSet[] ds=dataSetFactory.cloneDataSets(factoryDataSets);
       int rowsLevel1 = TemplateConstants.getTagTypeLevel1().length; // 3 header, body, composite
       DataSet[] compositeData = new DataSet[rowsLevel1-1];  // an entry for header and body
       Object[] data = {headerData, bodyData, compositeData};
       StringBuffer buffer=new StringBuffer(getBufferSize());
       TabularData headerTabData=null;

       for(int i=0; i<rowsLevel1; i++) {
            TabularData tabData = tabularDataFactory.getTabularData(data[i]);
            if (i==HEADER) 
                headerTabData=tabData;
            
            // header, body and composite should all share the same header so ##header1 and ##headerThis returns the 
            // same data in all
	    tabData.setHeader(headerTabData);  
            ds[i].setDataSetParm(new DataSetParm(tabData, buffer, miscDataMap));

            if (i<(rowsLevel1-1))  // don't execute this line for the composite i.e. the last item in the loop.
                compositeData[i] = ds[i];
       }

   // execute composite DataSet which will in turn execute the header and body DataSets.
   return ds[2].execute();

  }

  
  
  
  public Object clone() throws CloneNotSupportedException {
    Template template = (Template) super.clone(); 
    template.tabularDataFactory=TabularDataFactory.createInstance();
    template.dataSetFactory=DataSetFactory.createInstance();
    template.factoryDataSets=template.dataSetFactory.cloneDataSets(template.factoryDataSets);

    return template;
 }
  
  

 /** Same action as clone however clone returns an Object that must be cast and copy casts to a Template.
  *  Copy is the preferred method.
  *
  */
 public Template copy() {
     Template t=null;
     try {
       t = (Template) clone();
     } catch (CloneNotSupportedException e) {
       log("This Exception should never happen!:" +e);
     }
    
     return t;
 }
 
 /**
  * <p>Method that allows you to programmatically alter the Template object (similar to parsing a Template)</p>
  * <b>Sample call:</b>
  * 
  * <blockquote><code><pre> 
  *     Template template=new Template();
  *     template.intialize("body_cell_data", 0, 4, "##this, ##this");
  * </pre></code></blockquote>
  */
  public void initialize(String templateTag, int row, int col, String value) {
      initialize("<!-- "+templateTag+" "+row+","+col+" -->"+value+"<!-- "+templateTag+" "+row+","+col+" -->");
  }


 /**
  * <p>Method that allows you to programmatically alter the Template object by passing a String representation of a Template
  * to this method.  This method is called when Template files are parsed.</p>
  *
  * <b>Sample call:</b>
  * <blockquote><code><pre> 
  *     Template template=new Template();
  *     template.intialize("<!-- BODY_CELL_DATA 0,4 --><img src='##this.gif' alt='##this'><!-- BODY_CELL_DATA 0,4 -->");
  * </pre></code></blockquote>
  */
  
  synchronized public void initialize(String templateContents) {
   int rowsLevel1 = TemplateConstants.getTagTypeLevel1().length; // 3 body, header, composite
   contents+="\n\nTemplate initialize call #"+ (++initializeNum)+"\n"+templateContents;

   for(int i=0; i<rowsLevel1; i++) 
        factoryDataSets[i].initialize(templateContents);
  }
  
  /** get The contents of the Template String */
  public String getContents() {
      return contents;
  }


  private int getBufferSize() {
      return bufferSize;
  }

  /** Set the buffer size for this template.  This MAY help performance and memory consumption if you 
   * know the typical size of the text being generated.  Don't assume it will.  I have changed it before
   * with no measurable effect on performance.
   */
  public void setBufferSize(int size) {
      bufferSize=size;
  }

  
  /* Log the message */
  private void log(String logStr) {
     Utils.log(logStr);
  }


/**
This method has sample code that is used to test the DataSetFactory as well as many of the classes used in 
implementing DataSets such as the DataSetMap and TemplateReader classes
*/

public static void main(String args[]) throws Exception {

  Monitor mon=MonitorFactory.start();
  Utils.setDebug(true);  // enable verbose messages
  Template template1=new Template();
  Template template2=new Template();
  String[] header={" col1  ", " col2  ", " col3 ",};
  String[][] body={    {" (1,1) ", " (1,2) ", " (1,3) ",},
                        {" (2,1) ", " (2,2) ", " (2,3) ",},
                        {" (3,1) ", " (3,2) ", " (3,3) ",},};


  String templateContents =

    "********* Table Header info"+
    "<!-- HEADER_PREFIX -->\nheader_prefix\n<!-- HEADER_PREFIX -->"+
    "<!-- HEADER_SUFFIX -->header_suffix\n<!-- HEADER_SUFFIX -->"+

    "<!-- HEADER_ROW_PREFIX -->header_row_prefix\n<!-- HEADER_ROW_PREFIX -->"+
    "<!-- HEADER_ROW_SUFFIX -->header_row_suffix\n<!-- HEADER_ROW_SUFFIX -->"+

    "<!-- HEADER_CELL_PREFIX -->header_cell_prefix this=##this, headerThis=##headerThis<!-- HEADER_CELL_PREFIX -->"+
    "<!-- HEADER_CELL_SUFFIX -->header_cell_suffix\n<!-- HEADER_CELL_SUFFIX -->"+

    "********* Table body info"+
    "<!-- BODY_PREFIX -->body_prefix\n<!-- BODY_PREFIX -->"+
    "<!-- BODY_SUFFIX -->body_suffix\n<!-- BODY_SUFFIX -->"+

    "<!-- BODY_ROW_PREFIX -->body_row_prefix\n<!-- BODY_ROW_PREFIX -->"+
    "<!-- BODY_ROW_PREFIX 0,2 -->body_2ndrow_prefix\n <!-- BODY_ROW_PREFIX 0,2 -->"+
    "<!-- BODY_ROW_SUFFIX -->body_row_suffix\n<!-- BODY_ROW_SUFFIX -->"+

    "<!-- BODY_CELL_PREFIX -->body_cell_prefix<!-- BODY_CELL_PREFIX -->"+
    "<!-- BODY_CELL_DATA 0,1 -->body_cell_DATA 0,1<!-- BODY_CELL_DATA 0,1 -->"+
    "<!-- BODY_CELL_DATA 0,2 -->body_cell_DATA 0,2 ## should not match ##myVariableA ##myVariableB ##arr1 ##arr2 ##arrThis ##intArr1 ##intArrThis(##1 ##2 ##3 ##this rowNum=##rowNum colNum=##colNum headerThis=##headerThis header1=##header1 header2=##header2)##header2<!-- BODY_CELL_DATA 0,2 -->"+
    "<!-- BODY_CELL_DATA 0,3 -->body_cell_DATA 0,3<!-- BODY_CELL_DATA 0,3 -->"+
    "<!-- BODY_CELL_DATA 0,4 -->body_cell_DATA 0,4<!-- BODY_CELL_DATA 0,4 -->"+
    "<!-- BODY_CELL_DATA 0,5 -->body_cell_DATA 0,5<!-- BODY_CELL_DATA 0,5 -->"+
    "<!-- BODY_CELL_SUFFIX -->body_cell_suffix\n<!-- BODY_CELL_SUFFIX -->"+
    "<!-- BODY_CELL_PREFIX 0,2 -->body_cell_prefix 0,2<!-- BODY_CELL_PREFIX 0,2 -->"+
    "<!-- BODY_CELL_SUFFIX 0,2 -->body_cell_suffix 0,2\n<!-- BODY_CELL_SUFFIX 0,2 -->"+
    "<!-- BODY_CELL_PREFIX 2,3 -->body_cell_prefix 2,3<!-- BODY_CELL_PREFIX 2,3 -->"+
    "<!-- BODY_CELL_SUFFIX 2,3 -->body_cell_suffix 2,3\n<!-- BODY_CELL_SUFFIX 2,3 -->"+
    "<!-- BODY_CELL_PREFIX 2,0 -->body_cell_prefix 2,0<!-- BODY_CELL_PREFIX 2,0 -->"+
    "<!-- BODY_CELL_SUFFIX 2,0 -->body_cell_suffix 2,0\n<!-- BODY_CELL_SUFFIX 2,0 -->"+

    "********* Table composite info"+
    "<!-- COMPOSITE_PREFIX -->composite_prefix\n<!-- COMPOSITE_PREFIX -->"+
    "<!-- COMPOSITE_SUFFIX -->composite_suffix\n<!-- COMPOSITE_SUFFIX -->"+

    "<!-- COMPOSITE_ROW_PREFIX -->composite_row_prefix\n<!-- COMPOSITE_ROW_PREFIX -->"+
    "<!-- COMPOSITE_ROW_SUFFIX -->composite_row_suffix\n<!-- COMPOSITE_ROW_SUFFIX -->"+

    "<!-- COMPOSITE_CELL_PREFIX -->composite_cell_prefix<!-- COMPOSITE_CELL_PREFIX -->"+
    "<!-- COMPOSITE_CELL_SUFFIX -->composite_cell_suffix\n<!-- COMPOSITE_CELL_SUFFIX -->";

    template1.initialize(templateContents);
    template2.initialize("<!-- BODY_ROW_SUFFIX -->type==constant value==\n<!-- BODY_ROW_SUFFIX -->"+
        "<!-- HEADER_ROW_SUFFIX -->type==constant value==\n<!-- HEADER_ROW_SUFFIX -->");



    Monitor mon2=MonitorFactory.start();
    Map map=new HashMap();
    map.put("myVariableA", "ValueMyVariableA");
    map.put("arr", new String[]{"miscData1", "miscData2"});
    map.put("intArr", new int[]{100,200});

    System.out.println(template1.execute(header, body, map));
    System.out.println(template2.execute(header, body));
    System.out.println(template2.execute(header, body));  // display a 2nd time
    System.out.println(template2.copy().execute(header, body));  // display a 3rd time
    

    System.out.println("Total time for displaying of data: "+mon2.stop());
    System.out.println("Total Execution time (parsing, and displaying): "+mon.stop());
    
    System.out.println("****Template contents="+template2.getContents());

}
}

