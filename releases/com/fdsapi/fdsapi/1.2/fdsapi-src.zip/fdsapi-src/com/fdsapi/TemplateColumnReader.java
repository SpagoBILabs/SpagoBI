package com.fdsapi;  // FormattedDataSet API

/** Support class for parsing Template files/Strings.   It breaks the Template tag values at boundaries
 * such as a template tag variable (i.e. ##myVar).  Different Objects are created depending on the contents
 * of the contents of each column boundary (i.e. ##this, will create a different object than ##myVar).  However,
 * this class doesn't have knowledge of what different objects are created.  It only knows to break the tokens
 * up at the column boundaries.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateColumnReader.htm">View Code</a>
 */
public class TemplateColumnReader extends TemplateReader
{
     protected TemplateColumnReader(String regularExpressionStr)  {
          super(regularExpressionStr);
     }


    public static TemplateColumnReader createInstance()  {
        return new TemplateColumnReader(TemplateConstants.TEMPLATE_COLUMN_REGEXP);
    }


    public String getColumnValue()     {
          return getParen(TemplateConstants.TEMPLATE_COLUMN_VALUE_PAREN);
     }



    public static void main(String args[]) throws Exception     {
        String query="select * from table where fname=##1 and lname=##4 ##delme ##header20 ##RowNum and ##colNum ##headerThis and finally ##header1";
        TemplateColumnReader test = TemplateColumnReader.createInstance();
        test.setSourceString(query);

        String s[]=test.split(query);
        for(int i=0; i<s.length; i++)
            System.out.println("i="+i+" "+s[i]);

        while (test.next())
            System.out.println("columnValue=="+test.getColumnValue());
    }
}

