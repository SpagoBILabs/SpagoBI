package com.fdsapi;  // FormattedDataSet API

/**
Constants and utilities used in other FormattedDataSet API classes.
 *
 *
<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateConstants.htm">View Code</a>
*/

final public class TemplateConstants extends java.lang.Object
{
    
    final static String TRUE="TRUE";
    final static String FALSE="FALSE";
    final static String DEFAULT="DEFAULT";
    final static String CONTAINER="CONTAINER";


    // Template tag type = level1_level2_level3
    // Template tag type Level1
    final static String TEMPLATE_TAG_TYPE_SEPARATOR="_";

    final static String HEADER="HEADER";    // indicates a data sets header.
    final static String BODY="BODY";          // indicates a data sets body.
    final static String COMPOSITE="COMPOSITE";    // the header and body grouped together in a display are
                                                        // called the composite.
    // Template tag type Level2
    final static String PREFIX="PREFIX";        // tag indicating whether or not the affix is a prefix or suffix
    final static String DATA="DATA";
    final static String SUFFIX="SUFFIX";

    // Template tag type Level3
    final static String EMPTY_LEVEL2="";
    final static String CELL="CELL";            // the cell i.e. row, column combination in a data set.
    final static String ROW="ROW";                // the row in a data set


    final static String TEMPLATE_VARIABLE_SEPARATOR="==";  // used like type==listbox or query==select * from table

    final public static String getTemplateTagTypeRegExp(String templateTagType)
    {
    // The following regular expression 
    // templateTagType should be a string like BODY_ROW_PREFIX or HEADER_CELL_SUFFIX
     return "<!--\\s*"+templateTagType+"\\s*(\\d+)\\s*(,)\\s*(\\d+)\\s*-->"+
                    "(.*)"+  
                    "<!--\\s*"+templateTagType+"\\s*\\1\\s*\\2*\\s*\\3*\\s*-->"+
                    "|<!--\\s*"+templateTagType+"\\s*-->"+
                    "(.*)"+
                    "<!--\\s*"+templateTagType+"\\s*-->";
    }

    final static int TEMPLATE_TAG_VALUE_PAREN1=4;  
    final static int TEMPLATE_TAG_VALUE_PAREN2=5;  
    final static int TEMPLATE_TAG_X_VALUE_PAREN=1;
    final static int TEMPLATE_TAG_Y_VALUE_PAREN=3;
    // TemplateVariableReader constants
    final static String TEMPLATE_VARIABLE_REGEXP="(^(.*?)|\\s(.*?))"+TEMPLATE_VARIABLE_SEPARATOR+"\\s*(\\w+)";
    final static int TEMPLATE_VARIABLE_PAREN=4;
    final static int TEMPLATE_VARIABLE_VALUE1_PAREN=2;
    final static int TEMPLATE_VARIABLE_VALUE2_PAREN=3;

    // TemplateColumnReader constants


    final static String ROW_NUM="rowNum";
    final static String COL_NUM="colNum";
    final static String CURRENT_COL="this";
    final static String CURRENT_COL_HEADER="headerThis";
    // Arbitrary number that can't be positive.  used to represent the "this" column above.
    //final static int CURRENT_COL_NUMBER=-98321856;  
    //final static int NO_COL_NUMBER=-123456799;

    
    /** 
     The following regular expression matches ##variables.  Matches are not case sensitive.  i.e.
     ##THIS would match and so would ##this.  At this time the possible ##variables are:
        ##1
        ##this
        ##rowNum
        ##colNum
        ##headerThis
        ##header1 (i.e. a number)
        ##myUserDefinedVariable (can be anything after ##)
     */
    
    final static String TEMPLATE_COLUMN_REGEXP=
    "##("+                      // Look for all variables starting with ##
        "\\d+"+"|"+                 //##1 or
        "[0-9a-z_A-Z]+"+        // Note this matches any word (must have at least 1 character after ##
    ")"; 
/*    
    "##("+                       // Look for all variables starting with ##
        "\\d+"+"|"+                 //##1 or
        CURRENT_COL+"|"+            //##this or
        ROW_NUM+"|"+                //##rowNum or
        COL_NUM+"|"+                //##colNum or
        CURRENT_COL_HEADER+"|"+     //##headerThis or
        HEADER+"\\d+"+"|"+          //##header1
        "logic"+                    //##myMiscVariable
    ")"; 
*/


    //final static String TEMPLATE_COLUMN_REGEXP="##(\\w*)";

    final static int TEMPLATE_COLUMN_VALUE_PAREN=1;


    /* 
    The following codes are used to check for the template file tokens.  The format of the tokens is:
    The general format of the tags is begin tag+value+end tag

        <!-- BODY_ROW_PREFIX --><tr><!-- BODY_ROW_PREFIX -->  // defaults to coordinate 0,0
        <!-- BODY_ROW_PREFIX 1 --><tr><!-- BODY_ROW_PREFIX 1 -->  // 1,0
        <!-- BODY_ROW_PREFIX 1,2 --><tr><!-- BODY_ROW_PREFIX 1,2 -->  // 1,2

    The following constants help build these strings.   
    */

    final static int DEFAULT_BUFFERSIZE=25000;
    final static int LISTBOX_BUFFERSIZE=2000;
    final static int TABLE_BUFFERSIZE=25000;
    final static int RADIO_BUTTON_BUFFERSIZE=2000;




    // attribute types.  If any elements are added here they should also be placed in TemplateVariables as a 
    // get method.  For example getIncrementData().

    final static String TYPE="TYPE";
    final static String DATASET_DEFAULT_TYPE = TYPE+TEMPLATE_VARIABLE_SEPARATOR+DEFAULT;
    final static String INCREMENT_DATA="INCREMENTDATA";
    final static String VALUE="VALUE";
    final static String TEMPLATE="TEMPLATE";
    final static String DATASOURCE="DATASOURCE";
    final static String SELECTED="SELECTED";
    final static String SIZE="SIZE";

    final static String DATASOURCE_DEFAULT="DataSource";


//    final static String ATTRIBUTESEPARATOR="=";

    // Types of data sets.  This will be used in a templates type= field.  for example type=constant.
    // defined below final static String DATA;  
    // The following are case insensitive i.e basicHTMLTable is the same as basichtmltable
    final static String CONSTANT="CONSTANT";
    final static String NOAPPEND="NOAPPEND";
    final static String EMPTY="EMPTY";
    final static String COL="COL";
    final static String DECORATOR="DECORATOR";
    final static String NEXT="NEXT";
    final static String LISTBOX="LISTBOX";
    final static String DROPDOWNLISTBOX="DROPDOWNLISTBOX";
    final static String MULTISELECTLISTBOX="MULTISELECTLISTBOX";
    final static String RADIOBUTTON="RADIOBUTTON";
    final static String BASICHTMLTABLE="BASICHTMLTABLE";// plain
    final static String HTMLTABLE="HTMLTABLE";  // fancier looks best with stylesheet
    final static String SORTEDHTMLTABLE="sortedHTMLTable";// fancy requires stylesheet
    final static String XML="XML";
    final static String XML1="XML1";
    final static String BLANK="BLANK";
    final static String CSV="CSV";
    final static String DELIMITED="DELIMITED";
    final static String QUERY="QUERY";
    final static String ALTERNATING="ALTERNATING";
    final static String CONDITIONAL="CONDITIONAL";


    //final static String START_COMMENT="<!--";  
    //final static String END_COMMENT="-->";
    //final static int    END_COMMENT_LEN=END_COMMENT.length();


    public final static String[] getTemplateTagTypes() 
    {
        String[] templateTagTypes = new String[tagTypeLevel1.length * tagTypeLevel2.length * tagTypeLevel3.length];
        int l=0;

        for (int i=0; i<tagTypeLevel1.length; i++)  //HEADER, BODY, COMPOSITE
            for (int j=0; j<tagTypeLevel2.length; j++) // CELL, ROW, EMPTY
                for (int k=0; k<tagTypeLevel3.length; k++) // PREFIX, DATA, SUFFIX
                    {
                     // i.e. BODY_PREFIX 
                    templateTagTypes[l++] = getTemplateKey(tagTypeLevel1[i], tagTypeLevel2[j], tagTypeLevel3[k]);
                    }


        return templateTagTypes;
    }


    public final static String getTemplateKey( 
                                String templateTagTypeLevel1,
                                String templateTagTypeLevel2,
                                String templateTagTypeLevel3)

    {
        // returns strings like BODY_ROW_CELL or table_body_row_cell or BODY_CELL etc.
        templateTagTypeLevel1 = (templateTagTypeLevel1==null) ? "" : templateTagTypeLevel1+TEMPLATE_TAG_TYPE_SEPARATOR;
        templateTagTypeLevel2 = (templateTagTypeLevel2==null || EMPTY_LEVEL2.equals(templateTagTypeLevel2)) ? 
                                    "" : templateTagTypeLevel2+TEMPLATE_TAG_TYPE_SEPARATOR;
        templateTagTypeLevel3 = (templateTagTypeLevel3==null) ? "" : templateTagTypeLevel3;

        return templateTagTypeLevel1+templateTagTypeLevel2+templateTagTypeLevel3;

    }



    // order matters here.
    final static String[]tagTypeLevel1 = {HEADER, BODY, COMPOSITE};
    final static String[] getTagTypeLevel1()     {
        return tagTypeLevel1;
    }

    final static String[] tagTypeLevel2 = {CELL, ROW, EMPTY_LEVEL2};
    final static String[] getTagTypeLevel2()     {
        return tagTypeLevel2;
    }

    final static String tagTypeLevel3[] = {PREFIX, DATA, SUFFIX};
    final static String[] getTagTypeLevel3()    {
        return tagTypeLevel3;
    }
}

