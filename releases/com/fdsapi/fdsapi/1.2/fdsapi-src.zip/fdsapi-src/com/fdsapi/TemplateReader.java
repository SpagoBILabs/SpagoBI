package com.fdsapi;  // FormattedDataSet API


/**
This is a utility class used to parse templates.  It uses the RegularExpression class
to accomplish this.

<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateReader.htm">View Code</a>
*/

public abstract class TemplateReader extends java.lang.Object
{
     private RegularExpression regularExpression;

     protected TemplateReader(String regularExpressionStr)   {
          regularExpression = RegularExpression.createInstance(regularExpressionStr);

     }


     public boolean next()   {
          return regularExpression.next();
     }


     public void setSourceString(String sourceString)  {
          regularExpression.setSourceString(sourceString);
     }



    public String getParen(int parenNumber) {
        return regularExpression.getParen(parenNumber);
    }


    public String[] split(String stringToSplit)  {
        return regularExpression.split(stringToSplit);
    }
}

