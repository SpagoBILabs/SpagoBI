package com.fdsapi;  // FormattedDataSet API

/**
 This is a utility class used to parse templates.  It abstracts concepts such as the value of the template tag and
 its x,y coordinate so in the future templates may be created in a different format (say XML) without having
 these effects ripple throughout the FormattedDataSet API.
<br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateTagReader.htm">View Code</a>
*/
public class TemplateTagReader extends TemplateReader
{
  // a long (as opposed to an int) is used for the constants below so when getValue(int, long) is called the parameters can't be transposed as they
  // could be if the function getValue(int, int) was called.
  static final private long XY=0; // used when looking for an XY temlate column coordinate
  static final private long TAGVALUE=1;  // used when looking for a template tag value

   protected TemplateTagReader(String regularExpressionStr) {
          super(regularExpressionStr);
     }


/** This routine is used to hide the implementation of using regular expressions. */

    public static TemplateTagReader createInstance(String templateTagType)  {
        // replace the TEMPLATETAGTYPE marker with the passed templateTagType (i.e. something like
        // BODY_CELL_DATA or HEADER_ROW_PREFIX
        return new TemplateTagReader(TemplateConstants.getTemplateTagTypeRegExp(templateTagType));
    }


     public int getX()   {
         return getNumber(TemplateConstants.TEMPLATE_TAG_X_VALUE_PAREN);
     }

     public int getY()   {
         return getNumber(TemplateConstants.TEMPLATE_TAG_Y_VALUE_PAREN);
     }

    private int getNumber(int parenNumber)   {
        return Integer.parseInt(getValue(XY, parenNumber));
    }


    public String getTemplateTagValue()  {
        return getValue(TAGVALUE, TemplateConstants.TEMPLATE_TAG_VALUE_PAREN1);
     }


    private String getValue(long type, int parenNumber)   {   
        String value=getParen(parenNumber);

        // value will be null if there was no value in the parenNumber passed into this routine.
        if (value==null && type==XY)
            return "0";
        else if (value==null && type==TAGVALUE)
            return getParen(TemplateConstants.TEMPLATE_TAG_VALUE_PAREN2);
        else 
            return value;
    }




public static void main(String args[]) throws Exception { 
// Some invalid template tag formations follow
// No tags defined in file - tested valid
// Last entry in file not a tag - tested valid

    TemplateTagReader test = TemplateTagReader.createInstance("BODY_ROW_PREFIX");

    test.setSourceString("abc<!-- BODY_ROW_PREFIX -->first valid 0,0<!-- BODY_ROW_PREFIX -->XXX"+
        "<!-- BODY_ROW_PREFIX 2 -->invalid 2,0 <!-- BODY_ROW_PREFIX 2 -->XXX"+
        "<!-- BODY_ROW_PREFIX 20,20  -->second valid\nsouza 20,20<!-- BODY_ROW_PREFIX 20,20 -->"+
        "<!-- BODY_CELL_PREFIX   -->invalid 0,0 not used cause it is cell not row<!-- BODY_CELL_PREFIX   -->"+
        "<!-- BODY_ROW_PREFIX 20,    0 -->third valid 20,0<!-- BODY_ROW_PREFIX 20,0 -->"+
        "<!-- BODY_ROW_PREFIX 0,    22 -->fourth valid O,22<!-- BODY_ROW_PREFIX 0,22 -->"+
        "<!-- BODY_ROW_PREFIX a,    22 -->invalid<!-- BODY_ROW_PREFIX a,22 -->"+
        "<!-- BODY_ROW_PREFIX Z,0 -->invalid Z,0<!-- BODY_ROW_PREFIX z,0 -->"+
        "<!-- BODY_ROW_PREFIX ,0 -->invalid ,0<!-- BODY_ROW_PREFIX ,0 -->"+
        "<!-- BODY_ROW_PREFIX 10,0 -->fifth valid 10,0<!-- BODY_ROW_PREFIX 10,0 -->"+
        "<!-- BODY_ROW_PREFIX 1,0 -->invalid 10,0<!-- zzzND_BODY_ROW_PREFIX 1,0 -->"+
        "<!-- BODY_ROW_PREFIX 2, -->invalid  2,<!-- BODY_ROW_PREFIX 2, -->"+
        "more data at the end");

    while (test.next())
        System.out.println("x=="+test.getX()+", y=="+test.getY()+", template tag value=="+test.getTemplateTagValue());


}
}

