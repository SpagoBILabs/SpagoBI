package com.fdsapi;  // FormattedDataSet API

/** Classed used in parsing templates to read the variables of the format: variable==myValue.

 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateVariableReader.htm">View Code</a> 
 
 */

public class TemplateVariableReader extends TemplateReader
{
    protected TemplateVariableReader(String regularExpressionStr)  {
        super(regularExpressionStr);
    }

// NOTE THIS CLASS REVERSES THE VARIABLES TO SOMETHING LIKE THE FOLLOWING TO ALLOW THE REGULAR EXPRESSION TO WORK.  
// AFTERWARDS VALUES ARE REVERSED BACK TO NORMAL BEFORE BEING RETURNED TO THE CLIENT:
// For example say the sourceString is QUERY== select * from table then it is reversed to
// elbat morf * tceles ==YREUQ, then the expressions is matched and the values are reversed again to be returned as 
// their normal value.  this is the only way I could see to parse the string properly.  If this problem is figured out
// there is no reason to reverse the strings back and forth.
    public void setSourceString(String sourceString)    {
        super.setSourceString(new StringBuffer(sourceString).reverse().toString());
    }


    public static TemplateVariableReader createInstance()   {
        return  new TemplateVariableReader(TemplateConstants.TEMPLATE_VARIABLE_REGEXP);
    }


    public String getVariableValue()     {
        if (getParen(TemplateConstants.TEMPLATE_VARIABLE_VALUE1_PAREN)==null)
            return new StringBuffer(getParen(TemplateConstants.TEMPLATE_VARIABLE_VALUE2_PAREN)).reverse().toString();
        else 
            return new StringBuffer(getParen(TemplateConstants.TEMPLATE_VARIABLE_VALUE1_PAREN)).reverse().toString();

    }


    public String getVariable()     {
        return new StringBuffer(getParen(TemplateConstants.TEMPLATE_VARIABLE_PAREN)).reverse().toString();
    }

   public static void main(String args[])  throws Exception {
    TemplateVariableReader test = TemplateVariableReader.createInstance();
    test.setSourceString("  selected== type==query template==listbox   query   ==select * from table TESTVAR   == TESTVAL\nafter return     ");

    while (test.next())
        System.out.println("variable=("+test.getVariable()+"), value=("+test.getVariableValue()+")");

   }


}

