package com.fdsapi;  // FormattedDataSet API


import java.util.*;
import com.jamonapi.utils.AppMap;

/** <p>Object that allows code to find out the values stored in template tag variables after dynamic substitution.</p>
 *  
 * At runtime an example like this would replace all ## references: myVar=##this, ##1, ##2, ##date<br>
 *
 * Methods that take DataSetParm can replace the template tag variables contents at runtime with data from the TabularData.  
 * Methods that don't take DataSetParms do not replace template tag variable values with data at runtime.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/TemplateVariables.htm">View Code</a>
 */

public class TemplateVariables extends java.lang.Object
{
    private Map variablesMap = AppMap.createInstance();


    public static TemplateVariables createInstance()  {
        TemplateVariables variables = new TemplateVariables();

        variables.setVariable(TemplateConstants.TYPE, TemplateConstants.CONSTANT);
        variables.setVariable(TemplateConstants.INCREMENT_DATA, TemplateConstants.DEFAULT);
        variables.setVariable(TemplateConstants.DATASOURCE, AppConstants.get(AppConstants.DATASOURCE));
        return variables;
    }



/** Returns the variable value with no dynamic values.
i.e. if the variable was : dataSource==##this then 
variables.getVariableValue("dataSource") would return ##this
*/
public String getVariableValue(String variableName) {
    return getVariable(variableName).toString();
 }

/** Returns the variable value dynamic values. 
i.e. if the variable was : dataSource==##this 
and the value in this cell within the tabular data was "production" then 

variables.getVariableValue("dataSource") would return "production"
*/

public String getVariableValue(String variableName, DataSetParm dataSetParm) {
    return getVariable(variableName).getVariableValue(dataSetParm);
 }



/************** START inner classes*/

 static class VariableEntry  {
        ColBoundary[] colBoundary;
        String variableValue;

        // variable==##rowNum, ##colNum

        VariableEntry(String variableValue) {
            this.variableValue = variableValue;
            TemplateColumnReader colReader = TemplateColumnReader.createInstance();
            String[] boundarySplit = colReader.split(variableValue);

            colBoundary = new ColBoundary[boundarySplit.length];

            colReader.setSourceString(variableValue);

            for (int i=0; i<boundarySplit.length; i++)          {
                if (colReader.next()) 
                    colBoundary[i] = ColBoundary.createInstance(boundarySplit[i], colReader.getColumnValue());
                else 
                    colBoundary[i] = ColBoundary.createInstance(boundarySplit[i], null);

            }

         }

        String getVariableValue()       {
             return variableValue;
        }

        public String toString()        {
            return variableValue;
        }


        String getVariableValue(DataSetParm dataSetParm) {
            StringBuffer stringBuffer = new StringBuffer();

            for (int i=0; i<colBoundary.length; i++)
               colBoundary[i].getVariableValue(stringBuffer, dataSetParm);

            return stringBuffer.toString();
        }



 }

 /*************** END inner classes */


 public void setVariable(String variableName, String variableValue)  {
    variablesMap.put(variableName, new VariableEntry(variableValue)); 
 }

 private VariableEntry getVariable(String variableName) {
     if (variablesMap.containsKey(variableName))
        return (VariableEntry) variablesMap.get(variableName);
     else
        throw new RuntimeExceptionBase("The specified variable did not exist: "+variableName);
 }

 /** Iterate throught template tag entry populating TemplateVariables 
 Ex. <br>

 type==Constant incrementData==true<br>

 would iterate through both variables and populate type and incrementData as the variable names and
 Constant and true as their values.  Value would have the whole string (i.e. type==Constant incrementData==true)
 */
  public void populateVariables(String sourceString)  {
    TemplateVariableReader variableReader = TemplateVariableReader.createInstance();
    variableReader.setSourceString(sourceString);  // used to parse data

    // if value=some value was not specified then use the full string for value.
    setVariable(TemplateConstants.VALUE, sourceString);  

    while (variableReader.next())
        setVariable(variableReader.getVariable(), variableReader.getVariableValue());

 }


/** Returns value in variables of format "type==" */
 public String getType()  {
    return getVariableValue(TemplateConstants.TYPE).trim();
 }


/** Returns value in variables of format "value==" */
 public String getValue()  {
     return getVariableValue(TemplateConstants.VALUE);
 }

/** Returns value in variables of format "incrementData==##this" */
// no exception due to the fact that this variable is always initialized in createInstance()
 public String getIncrementData(DataSetParm dataSetParm)  {
     return getVariableValue(TemplateConstants.INCREMENT_DATA, dataSetParm).trim();
 }


/** Returns value in variables of format "DataSource==##this" */
// no exception due to the fact that this variable is always initialized in createInstance()
 public String getDataSource(DataSetParm dataSetParm)  {
     return getVariableValue(TemplateConstants.DATASOURCE, dataSetParm).trim();
 }

 
 /** Returns value in variables of format "value==##this" */
 public String getValue(DataSetParm dataSetParm)  {
     return getVariableValue(TemplateConstants.VALUE, dataSetParm);
 }



 /** Returns value in variables of format "template==##this" */
 public String getTemplate(DataSetParm dataSetParm) {
     return getVariableValue(TemplateConstants.TEMPLATE, dataSetParm).trim();
 }


 /** Returns value in variables of format "selected==##this" */
 public String getSelected(DataSetParm dataSetParm) {
     return getVariableValue(TemplateConstants.SELECTED, dataSetParm);
  }


 /** Returns value in variables of format "size==##this" */
 public String getSize(DataSetParm dataSetParm)  {
     return getVariableValue(TemplateConstants.SIZE, dataSetParm).trim();
  }



  /** Returns value in variables of format "query==##this" */
public String getQuery(DataSetParm dataSetParm) {
     return getVariableValue(TemplateConstants.QUERY, dataSetParm);
  }


/** Iterator that goes through all of a template tags variables.*/
 public Iterator iterator()  {
     return variablesMap.keySet().iterator();
 }


 /** Test code and sample usage */
 public static void main (String args[]) throws Exception
 {
     // the following lines of code are to ensure AppConstants are properly initialized.
     // Note some variables (type, size, datasource and incrementData) have their values trimmed due to the fact that their variable values
     // should only have 1 word (i.e. type==listbox, size==4, dataSource=DataSource and incrementData==true).  Other values such as
     // query== select * from table are not trimmed.

    String[][] data={
                            {"(1,1)", "(1,2)"},
                            {"(2,1)", "(2,2)"},
                          };
    int row=1;

    TabularData td=new TabularData2DimArray().createInstance(data);
    DataSetParm dsp=new DataSetParm(td, new StringBuffer(), AppMap.createInstance());

    TemplateVariables test = TemplateVariables.createInstance();
    test.populateVariables("    before1stattribute query==exec  getJobTitlesHistory '##1' type==   listbox   selection==##2, ##1 "+
                    "request==exec request     template==   table     incrementData==  true    value==hello \nworld  dataSource==    myDataSource   size==  123   "+
                    "allTest== thiscell=##this cellincol1=##1, rowNum=##rowNum, colNum=##colNum "+
                    "testVariable==##rowNum, ##colNum ##headerThis ##header1");

    while (td.getRowIterator().next())  // iterate through the tabular data accessing variables.  note dynamic replacement of ##num at run time.
      while (td.getColIterator().next())
        {

        Utils.log("\n\n****Row"+row++);
        Utils.log("Direct variable access: the following values are automatically trimmed");
        Utils.log("type==("+test.getType()+")");
        Utils.log("size==("+test.getSize(dsp)+")");
        Utils.log("dataSource==("+test.getDataSource(dsp)+")");
        Utils.log("template==("+test.getTemplate(dsp)+")");
        Utils.log("incrementData==("+test.getIncrementData(dsp)+")");

        Utils.log("\nAccess to all variables via an iterator (values are not trimmed)");
        for(Iterator iter=test.iterator(); iter.hasNext(); )    {
            String variableName = iter.next().toString();
            Utils.log(variableName+"==("+test.getVariableValue(variableName, dsp)+")");
        }
      }

 }



}

