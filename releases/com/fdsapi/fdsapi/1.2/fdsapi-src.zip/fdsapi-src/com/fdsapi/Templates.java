package com.fdsapi;  // FormattedDataSet API

import java.util.*;
import com.jamonapi.utils.*;
import com.jamonapi.*;
/** Object that contains individual Template objects.  
 *
   * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/Templates.htm">View Code</a>
*/

public class Templates extends java.lang.Object
{
  private Map templatesMap=Collections.synchronizedMap(AppMap.createInstance());

  /** 
  Populates html table, listbox, drop down list box and radio button default templates.  These may be 
  overwritten by developers if they desire.
   *
  */

  public Templates() {
      new DefaultTemplates().initialize();

  }

  /**
  Adds a new Template or if the template already exists it appends/overwrites any existing template tag variables.
  The internals of this method are synchronized.
  */
  public void put(String templateLogicalName, Template template) {
      templatesMap.put(templateLogicalName, template);
  }

  /**
  Returns an existing Template or null if the template doesn't exist.  
  The internals of this method are synchronized.
  */
  public Template get(String templateLogicalName) {
      return (Template) templatesMap.get(templateLogicalName);
  }


  /**
  Removes an existing Template or performs no action if the template doesn't exist.  
  The internals of this method are synchronized.
  */
  public void remove(String templateLogicalName) {
      templatesMap.remove(templateLogicalName);
  }
  
/* Log debug message */
private void log(String logStr) {
   Utils.logDebug(logStr);
}



  /**  
  <p>Loop through each template file, read the template file, parse it and populate the Templates object
  with the parsed templates. The format of the array is:</p>

  <p>logicalTemplateName,   fully qualified template file location</p>

  <p>For example</p>
  table,     \my dir\my subdir\table1.html<br>
  table,     \my dir\table2.html<br>
  salaries,  \my dir\salaries.html<br>

  <p>Any conflicting entries in the table1.html will be overwritten by table2.html.</p>
  
  <p>If the template name already exists it will be inherited from not created from scratch.</p>

  */ 
  public void initialize(String[][] templateFiles)  {

    try {
        log("**Start populating templates from files\n");
        int templateRows=templateFiles.length;
        Monitor mon=null;

        for (int i=0; i<templateRows; i++)  {
            mon=MonitorFactory.start("Templates.initialize()");
            String templateLogicalName = templateFiles[i][0];  // i.e. table
            String templateFileName    = templateFiles[i][1];  // i.e \mydir\mysubdir\table.html

            log("**Start Initializing template templateName="+templateLogicalName+", templateFile="+templateFileName);

            String fileContents = FileUtils.getFileContents(templateFileName);  // read contents of file into string
            createFactoryTemplate(templateLogicalName, fileContents);
            log("**End Initializing template templateName="+templateLogicalName+", templateFile="+templateFileName+", Time="+mon.stop());

        }

        log("**End populating templates from files.  Total time="+mon+"\n");
    } catch (Exception e) {
        throw new RuntimeExceptionBase("error initializing template files"+e);
    }
  }


  /**  Returns the given Template or creates a new one if it doesn't exist */
  private Template getTemplate(String templateLogicalName)   {
      if (templatesMap.containsKey(templateLogicalName)) 
        return get(templateLogicalName);
      else 
        return new Template();
  }

  /** 
  Create a Factory Template from a template file.  This method parses the template to create the Template object.
  This Template will be used to clone Templates like it at run time.
  */
  private void createFactoryTemplate(String templateLogicalName, String templateContents) {
         Template template=getTemplate(templateLogicalName);
         template.initialize(templateContents);
         put(templateLogicalName, template);
  }



/** 
Creates default templates (allows users to initialy use templates without learning how to create them).
A default template is created for the following html display formats: table, drop down list box, list box
and radio button.  To change what the defaults look like change the template strings below.  Note changing
these strings may effect the FormattedDataSet class though.
*/


private class DefaultTemplates {
    void initialize() {
            Monitor mon=MonitorFactory.start();

            log("*Start Initializing default Templates.");

            log("\n*Start creating Default basic HTML table template");
            createFactoryTemplate(TemplateConstants.BASICHTMLTABLE, basicTable);
            log("*End creating Default basic HTML table template");

            log("\n*Start creating Default HTML table template");
            createFactoryTemplate(TemplateConstants.HTMLTABLE, htmlTable);
            log("*End creating Default HTML table template");

            log("\n*Start creating SortedHTMLTable template");
            createFactoryTemplate(TemplateConstants.SORTEDHTMLTABLE, sortedHTMLTable);
            log("*End creating SortedHTMLTable template");
            
            log("\n*Start creating Default dropDownListBox template");
            createFactoryTemplate(TemplateConstants.DROPDOWNLISTBOX, listBox);
            log("*End creating Default dropDownListBox template");

            log("\n*Start creating Default listBox template");
            createFactoryTemplate(TemplateConstants.LISTBOX, listBox);
            log("*End creating Default listBox template");

            log("\n*Start creating Default multi-select listBox template");
            createFactoryTemplate(TemplateConstants.MULTISELECTLISTBOX, listBox);
            get(TemplateConstants.MULTISELECTLISTBOX).initialize(multiSelectListBox);
            log("*End creating Default multi-select listBox template");


            log("\n*Start creating Default radioButton template");
            createFactoryTemplate(TemplateConstants.RADIOBUTTON, radioButton);
            log("*End creating Default radioButton template");

            log("\n*Start creating Default XML template");
            createFactoryTemplate(TemplateConstants.XML, xml);
            log("*End creating Default XML template");

            log("\n*Start creating Default XML1 template");
            createFactoryTemplate(TemplateConstants.XML1, xml1);
            log("*End creating Default XML1 template");

            log("\n*Start creating blank template");
            createFactoryTemplate(TemplateConstants.BLANK, blank);
            log("*End creating blank template");
            
            log("\n*Start creating CSV template");
            createFactoryTemplate(TemplateConstants.CSV, csv);
            log("*End creating CSV template");

            log("\n*Start creating delimited template");
            createFactoryTemplate(TemplateConstants.DELIMITED, delimited);
            log("*End creating delimited template");

            log("*End Initializing default Templates.  Total time="+mon.stop());

    }        


    String basicTable= 
        "<!-- COMPOSITE_PREFIX --><table border='1' rules='all'>\n<!-- COMPOSITE_PREFIX -->"+
        "<!-- COMPOSITE_SUFFIX --></table>\n<!-- COMPOSITE_SUFFIX -->"+

        "<!-- HEADER_ROW_SUFFIX -->\n<!-- HEADER_ROW_SUFFIX -->"+
        "<!-- HEADER_CELL_PREFIX --><th><!-- HEADER_CELL_PREFIX -->"+
        "<!-- HEADER_CELL_SUFFIX --></th><!-- HEADER_CELL_SUFFIX -->"+

        "<!-- BODY_ROW_PREFIX --><tr><!-- BODY_ROW_PREFIX -->"+
        "<!-- BODY_ROW_SUFFIX --></tr>\n<!-- BODY_ROW_SUFFIX -->"+

        "<!-- BODY_CELL_PREFIX --><td><!-- BODY_CELL_PREFIX -->"+
        "<!-- BODY_CELL_SUFFIX --></td><!-- BODY_CELL_SUFFIX -->";
    
    
    // Note formatteddataset.css, should be available for this report to look as good as possible.
    String htmlTable=
        "<!-- COMPOSITE_PREFIX -->\n<table class='layoutMain' border cellpadding='0' cellspacing='0' width='100%' align='center'>\n"+
        "<tr bgcolor='#FFFFFF'>\n"+
        "<td><table border='0' cellpadding='2' cellspacing='1' width='100%'>\n<!-- COMPOSITE_PREFIX -->"+
        "<!-- COMPOSITE_SUFFIX --></table></td>\n"+
        "</tr>\n"+
        "</table>\n"+
        "<!-- COMPOSITE_SUFFIX -->"+

        "<!-- HEADER_ROW_PREFIX -->    <tr><!-- HEADER_ROW_PREFIX -->"+
        "<!-- HEADER_ROW_SUFFIX -->    </tr><!-- HEADER_ROW_SUFFIX -->"+
        "<!-- HEADER_ROW_PREFIX 1,0 -->   <tr class='sectHead'><!-- HEADER_ROW_PREFIX 1,0 -->"+
        "<!-- HEADER_ROW_SUFFIX 1,0 -->\n"+
        "    </tr>\n<!-- HEADER_ROW_SUFFIX 1,0 -->"+
        "<!-- HEADER_CELL_PREFIX -->\n"+
        "    <th><!-- HEADER_CELL_PREFIX -->"+
        "<!-- HEADER_CELL_SUFFIX --></th><!-- HEADER_CELL_SUFFIX -->"+

        "<!-- BODY_ROW_PREFIX -->Type==Alternating Odd==   <tr class='odd'>\n Even==   <tr class='even'>\n<!-- BODY_ROW_PREFIX -->"+
        "<!-- BODY_ROW_SUFFIX -->   </tr>\n<!-- BODY_ROW_SUFFIX -->"+
        "<!-- BODY_CELL_PREFIX -->    <td><!-- BODY_CELL_PREFIX -->"+
        "<!-- BODY_CELL_SUFFIX --></td>\n<!-- BODY_CELL_SUFFIX -->"+
        "<!-- body_cell_data -->Type==Conditional if==null ifValue==&nbsp; elseValue==##this<!-- body_cell_data -->";
    
    // Note formatteddataset.css, and asc.gif and desc.gif should be available for this report to look as good as possible.
    String sortedHTMLTable=htmlTable+
        "<!-- HEADER_CELL_DATA --><a style='color:white;' href=\"##sortPageName?sortCol=##colNum&sortOrder=##sortOrderThis##query\">##this</a><br>##sortOrderGifThis<!-- HEADER_CELL_DATA -->";

    String listBox=
        "<!-- HEADER_ROW_SUFFIX -->\n<!-- HEADER_ROW_SUFFIX -->"+
        "<!-- HEADER_CELL_PREFIX 0,1 --><select name='<!-- HEADER_CELL_PREFIX 0,1 -->"+
        "<!-- HEADER_CELL_SUFFIX 0,1 -->' size='1' id='##1_ID'><!-- HEADER_CELL_SUFFIX 0,1 -->"+
        "<!-- HEADER_CELL_DATA -->Type==EMPTY<!-- HEADER_CELL_DATA -->"+
        "<!-- HEADER_CELL_DATA 0,1 -->Type==DATA<!-- HEADER_CELL_DATA 0,1 -->"+
        "<!-- BODY_SUFFIX --></select>\n<!-- BODY_SUFFIX -->"+
        "<!-- BODY_ROW_PREFIX --><option value='<!-- BODY_ROW_PREFIX -->"+
        "<!-- BODY_ROW_SUFFIX -->\n<!-- BODY_ROW_SUFFIX -->"+
        "<!-- BODY_CELL_SUFFIX 0,1 -->'><!-- BODY_CELL_SUFFIX 0,1 -->";

     // Will inherit from listBox
     String multiSelectListBox=
             "<!-- HEADER_CELL_SUFFIX 0,1 -->' size='1' id='##1_ID' multiple='MULTIPLE'><!-- HEADER_CELL_SUFFIX 0,1 -->";

     String radioButton=
        "<!-- HEADER_DATA -->Type==EMPTY<!-- HEADER_DATA -->"+
        "<!-- BODY_PREFIX -->\n<!-- BODY_PREFIX -->"+
        "<!-- BODY_ROW_DATA --><input  name=##header1 value=##1 type=radio>##2\n<!-- BODY_ROW_DATA -->";

     String xml=
        "<!-- HEADER_DATA --><!-- HEADER_DATA -->"+
        "<!-- BODY_ROW_PREFIX --> <row rowID='##rowNum'>\n<!-- BODY_ROW_PREFIX -->"+
        "<!-- BODY_CELL_PREFIX -->  <##headerThis><!-- BODY_CELL_PREFIX -->"+
        "<!-- BODY_CELL_SUFFIX --></##headerThis>\n<!-- BODY_CELL_SUFFIX -->"+
        "<!-- BODY_ROW_SUFFIX --> </row>\n<!-- BODY_ROW_SUFFIX -->";
     
     String xml1=
        "<!-- COMPOSITE_PREFIX --><##rootElement>\n<!-- COMPOSITE_PREFIX -->"+
        "<!-- COMPOSITE_SUFFIX --></##rootElement>\n<!-- COMPOSITE_SUFFIX -->"+
        xml;

     // good for "select @@version" and queries that return a result set of 1 string
     String blank=
        "<!-- HEADER_DATA -->Type==Empty<!-- HEADER_DATA -->"; 
     
     // Comma Separated Values output
     String csv=
        "<!-- HEADER_DATA -->Type==Empty<!-- HEADER_DATA -->"+
        "<!-- BODY_CELL_PREFIX -->,<!-- BODY_CELL_PREFIX -->"+
        "<!-- BODY_CELL_PREFIX 0,1 --><!-- BODY_CELL_PREFIX 0,1 -->"+
        "<!-- BODY_ROW_SUFFIX -->\n<!-- BODY_ROW_SUFFIX -->";
     
     // Same as CSV, but the developer can provide a different delimiter
     String delimited=
        "<!-- HEADER_DATA -->Type==Empty<!-- HEADER_DATA -->"+
        "<!-- BODY_CELL_PREFIX -->##delimiter<!-- BODY_CELL_PREFIX -->"+
        "<!-- BODY_CELL_PREFIX 0,1 --><!-- BODY_CELL_PREFIX 0,1 -->"+
        "<!-- BODY_ROW_SUFFIX -->\n<!-- BODY_ROW_SUFFIX -->";

} /*** end inner class ***/

/** Test and sample usage for the Templates class */
public static void main(String[] args) throws Exception  {
  Monitor mon=MonitorFactory.start();
  Utils.setDebug(true); // enable log messages/debugging
  Templates templates=new Templates();
  String[] header={"stateCode", "stateName",};
  String[][] body={
                   {"AL", "Alaska",},
                   {"CA", "California",},
                   {"VA", "Virginia",},
                   {"MD", "Maryland",},
                  };


  Template template=templates.get("htmlTable");
  System.out.println("\n\n"+template.execute(header, body));


  template=templates.get("dropDownListBox");
  System.out.println("\n"+template.execute(header, body));

  template=templates.get("listBox");
  System.out.println("\n"+template.execute(header, body));

  header=new String[]{"stateCode", "stateName",};
  body=new String[][]
      {
         {"AL", "Alaska",},
         {"CA", "California",},
         {"VA", "Virginia",},
         {"MD", "Maryland",},
       };

  template=templates.get("radioButton");
  System.out.println("\n"+template.execute(header, body));

  template=templates.get("basicHTMLTable");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("htmlTable");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("sortedHTMLTable");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("xml");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("xml1");
  Map miscData=new HashMap();
  miscData.put("rootElement", "statesRootElement");
  System.out.println("\n\n"+template.execute(header, body, miscData));
  
  template=templates.get("blank");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("csv");
  System.out.println("\n\n"+template.execute(header, body));

  template=templates.get("delimited");
  miscData.put("delimiter", "||");
  System.out.println("\n\n"+template.execute(header, body, miscData));
  
  // test alternating and conditional DataSets by inheriting from the table template.
  Monitor mon2=MonitorFactory.start();
  template=(Template) templates.get("htmlTable").clone();
  template.initialize("<!-- BODY_ROW_PREFIX -->Type==Alternating "+
                        "Odd==<tr class='odd'> "+
                        "Even==<tr class='even'>"+
                        "<!-- BODY_ROW_PREFIX -->");
  template.initialize("<!-- body_cell_data 0,1 -->Type==Conditional "+
                        "if==VA ifValue==##this(conditional worked) elseValue==##this"+
                        "<!-- body_cell_data 0,1 -->");
  System.out.println("\n\n"+template.execute(header, body));
  System.out.println("Execution time for inheriting a template (cloning/overriding 2 tags) and executing: "+mon2.stop());

  System.out.println("\n\nTotal execution time: "+mon.stop());

}
}

