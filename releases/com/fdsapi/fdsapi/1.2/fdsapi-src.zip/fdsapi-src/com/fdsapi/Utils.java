package com.fdsapi;  // FormattedDataSet API


import java.util.*;
import javax.servlet.http.*;

/** Miscellaneous utility classes.  
 <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/Utils.html">View Code</a>
 *
 */

public class Utils {
    
    
 /** returns true if the argument is null or the empty String.  */
  public static boolean isEmpty(String str) {
      return (str==null) ? true : str.equals("");
  }
  
  
  /* <p>return parameters in an http request as a key value pair table.  Note the key can be repeated as would
  be the case when a multi-select list box was in a form and submitted in the request.</p>
  
  <p><b>Example:</b></p>
    key1 value1<br>
    key2 value2<br>
    key2 value3<br> 
    
  */
  public static String[][] getParameters(HttpServletRequest request) {
      List list=new ArrayList();
      Enumeration enum=request.getParameterNames();
      
      while (enum.hasMoreElements()) {
          String name=enum.nextElement().toString();
          String[] values=request.getParameterValues(name);
          
          if (values!=null) {
              for (int i=0; i<values.length; i++) {
                  String[] row={name, values[i]};
                  list.add(row);
              }
          }
      }
              
      // convert array list to 2 dim array.
      String[][] arr=null;
      if (list.size()>0) {
        arr=new String[list.size()][];

        Iterator iter=list.iterator();
        for (int i=0; iter.hasNext(); i++)
            arr[i]=(String[]) iter.next();
      }
       
     return arr;
      
  }
  
  /** Converts a 1 dimensional array of objects to a 1 dimensional array of Strings. */
  public static String[] convert(Object[] data) {
      if (data==null)
         return null;
      else {
      
        String[] strData=new String[data.length];
        for (int i=0;i<data.length;i++) 
           strData[i]=(data[i]==null ? null : data[i].toString());
      
        return strData;
      }
  }
  
      
   /** Duplicates all entries of the 2 dim array, and puts the original pointer of the data in the slots */
    public static Object[][] copy(Object[][] data) {
       if (data==null)
         return null;
       else {
         // first copy the array that holds the row pointers
         int size=data.length;
         Object[][] copyData=new Object[size][];
         System.arraycopy(data,0, copyData,0,size);
         
         // copy each row and put the pointer to the row in the outer array
         for (int i=0;i<size;i++)
            copyData[i]=copy(data[i]);
         
         return copyData;
       }
    }
    
        
    
    /** Called when all columns in a 1 dimentional array should be copied */
    public static Object[] copy(Object[] originalRow) {
       if (originalRow==null) 
         return null;
       else {
         int numCols=originalRow.length;
         Object[] rowCopy=new Object[numCols];
         // copies originalRow into rowCopy startint at index 0 in both arrays and copying all cols (numCols)
         System.arraycopy(originalRow,0,rowCopy,0,numCols);
         return rowCopy;
       } 
    }
    

  /** Using a regular expression - split the passed in string along token boundaries */
   public static String[] split(String reStr, String splitStr) {
        RegularExpression re=new RegularExpression(reStr);
        return re.split(splitStr);
        
    }
   
   public static String getREMatch(String reStr, String sourceStr, int matchNum) {
        RegularExpression re=new RegularExpression(reStr);
        re.setSourceString(sourceStr);
        String matchStr=null;
        while (re.next())
            matchStr=re.getParen(matchNum);
        
        return matchStr;
        
    }

   

    
  static boolean debug=false;
  public static void setDebug(boolean debugFlag) {
      debug=debugFlag;
  }
  
  public static boolean getDebug() {
      return debug;
  }
  
  
  public static void log(Object msg) {
      System.out.println(msg);
  }
  
  public static void logDebug(Object msg) {
      if (debug)
        System.out.println(msg);
  }
    
}






