
package com.fdsapi.arrays;

import java.util.*;
import java.text.*;
import com.fdsapi.*;
import com.jamonapi.*;

/**
 *  Mention either can overwrite data in input array with converted data or copy the output into
 *  another array.  By default it allocates a new array and puts the converted data into 
 *  a new array of the same size of the input array.
 *
 * Note calling the convert methods is thread safe IF the various set.../remove... methods are not
 * called during this operation which can often be the case if the application for example creates
 * the ArrayConverter class at startup.
           setTypeConverter(Object.class, new ConverterNumToString(new ConverterDateToString()));
        setTypeConverter(Number.class, new ConverterNumToString());

 setTypeConverter(Date.class, new ConverterDateToString());
 *
 * * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ArrayConverter.htm">View Code</a>

 *
 */
public class ArrayConverter implements Cloneable {
    
    // set to true if data in original input array should be overwritten as opposed to allocating
    // a new array to hold the results of the convert
    private boolean overWriteExistingArray=false;  
    // used to return the appopriate Converter objects
    private ArrayConverterFactory factory;
    // used to map column names to numbers.  This allows arrays to have the concept of column 
    // names.
    private ArrayHeaderLocator headerLocator=new ArrayHeaderLocator();
    
    /** Creates a new instance of ArrayConverter*/
    public ArrayConverter() {
        factory=new ArrayConverterFactory();        
        setDefaultConverter();
    }
    
    /** Creates a new instance of ArrayConverter and allows you to use colnames from a header when
     setting column converters.
     */
    public ArrayConverter(String[] header) {
       this();
       setArrayHeaderLocator(header);
    }

    /** Creates a new instance of ArrayConverter and when convert is called if true is passed the 
     array passed into the convert method will be used in place to contain the resulting data, thus
     saving the the array creation for the output.  If false is passed the array will be created.  false
     is also the default value if a boolean isn't provided.  Remember because Converters can change
     the type of an Object (say from Date to String) the original array must be type compatible if it
     is used for output.
     */
    public ArrayConverter(boolean overWriteExistingArray) {
        this();
        setOverWriteExistingArray(overWriteExistingArray);
    }

    /** Creates an instance that allows for column converters to be set by name, and allows the 
     * developer to indicate whether they want the output array to be the original array or not
     */
    public ArrayConverter(String[] header, boolean overWriteExistingArray) {
        this(header);
        setOverWriteExistingArray(overWriteExistingArray);
    }
    
    // constructor used for cloning
    private ArrayConverter(ArrayConverterFactory factory, ArrayHeaderLocator headerLocator, boolean overWriteExistingArray) {
       this.factory=factory;
       this.headerLocator=headerLocator;
       this.overWriteExistingArray=overWriteExistingArray;
    }   
    
    /** This default converter converts numbers, and dates and leaves all other Objects unchanged */
    private void setDefaultConverter() {
        setDefaultConverter(new ConverterNumToString(new ConverterDateToString()));
    }
    
    /** This method 'Converts' the data in the input array.  It can either put the output in the input array or create 
     * a new array depending on how this ArrayConverter object is configured.
     * Use this signature if the column names have changed position.  Note this does not change the ArrayHeaderLocator instance variable.   */
    public Object[][] convert(String[] header, Object[][] data) {
        return convert(new ArrayHeaderLocator(header), data);
    }
    
    /** This method 'Converts' the data in the input array.  It can either put the output in the input array or create 
     * a new array depending on how this ArrayConverter object is configured.
     * Use this signature when either the location of the column name is the same as when this instances ArrayHeaderLocator indicates or
     * no converters by column name have been specified 
     */
    public Object[][] convert(Object[][] data) {
       return convert(getArrayHeaderLocator(), data);
        
    }
 
    /** This method 'Converts' the data in the input array.  It can either put the output in the input array or create 
     * a new array depending on how this ArrayConverter object is configured.
     * Use this signature if the column names have changed position.  Note this does not change the ArrayHeaderLocator instance variable.   
     */
    public Object[][] convert(ArrayHeaderLocator arrayHeaderLocator, Object[][] data) {
     Monitor mon=AppConstants.start("arrays.ArrayConverter.convert(Object[][])");
     Object[][] resultsArray=null; 
     
     try {
        if (data==null)
          return null;
        
        // By default returns a copy of the data, but may be configured to perform an in place replacement
        // of the data in the passed in data array. Data types for the converted objects and the array
        // must be compatible.  If the original array is declared as Object[][] it will always work, 
        // however if the array is of say type Date[][] then the converted Objects must be of type Date.
        resultsArray=getData(data);

        // Get an array of converters.  A converter will be returned for each column in the input 
        // array (data below)
        Converter[] converters=factory.getConverters(arrayHeaderLocator, data);

        // loop through the array calling the appropriate Converter object for each cell
        // in the array
        int rows=data.length;
        int cols=(rows==0 || data[0]==null) ? 0 : data[0].length;
        for (int i=0;i<rows;i++) {
           for (int j=0;j<cols;j++) {
              resultsArray[i][j]=converters[j].convert(data[i][j]);
           }
        } 
        
     } finally {
        mon.stop();
     }
            
     return resultsArray;
    }
   
    
    
     /** If the contents of the original array are no longer needed then ArrayConverter will not allocate memory 
     * and will instead reuse the original data's array.  This happens when true is passed to this routine.  
      *Note the converted objects and input array must be of compatible types if you set this to true or 
      *you will get an exception.   Object[][] arrays are always type compatible.
     */
    public void setOverWriteExistingArray(boolean overWriteExistingArray) {
        this.overWriteExistingArray=overWriteExistingArray;
    }
    
    /** Returns true if an array will not be allocated to hold the converted results, and false otherwise  */
    public boolean overWriteExistingArray() {
        return overWriteExistingArray;
    }

    /** Set the default Converter that will be used if no other matches are found */
    public void setDefaultConverter(Converter converter) {
       factory.setDefaultConverter(converter);
    }
    

    /** Set the column Converter to be used for a particular column number.  colNum uses array 
     * indexing which starts at 0 as opposed to 1.  Column converters have the highest precedence
     * column number and column name Converters have equal precedence and when they conflict the 
     * last one that was executed wins.
     */
    public void setColConverter(int colNum, Converter converter) {
        factory.setColConverter(colNum, converter);
    }
    /** Remove the column converter for the specified column */
    public void removeColConverter(int colNum) {
        factory.removeColConverter(colNum);
    }

    /** Set the column Converter to be used for a particular column name.  This name will be used
     * to match Converters to columns of the same name.  Column converters have the highest precedence
     * column number and column name Converters have equal precedence and when they conflict the 
     * last one that was executed wins.     *
     */
    public void setColConverter(String colName, Converter converter) {
       factory.setColConverter(colName, converter);
    }
    /** Remove the column converter for the specified column */
    public void removeColConverter(String colName) {
        factory.removeColConverter(colName);
    }

    
    /** Set the column coverter to be used for the specified datatype.  Note column converters have
     ** over type Converters
     **/
    public void setTypeConverter(Class type, Converter converter) {
        factory.setTypeConverter(type, converter);
    }
    /** Remove the Converter for the specified data type */
    public void removeTypeConverter(Class type) {
        factory.removeTypeConverter(type);
    }    

    /** Set the factory that will be used to determine which Converters to create */
    public void setArrayConverterFactory(ArrayConverterFactory factory) {
        this.factory=factory;
    }
    
    /** Get the backing ArrayConverterFactory */
    public ArrayConverterFactory getArrayConverterFactory() {
        return factory;
    }
    
    /** Make a clone of the ArrayConverter */
    public Object clone() {
        return new ArrayConverter(factory.copy(), headerLocator.copy(), overWriteExistingArray());
    }
    
    /** Clones the ArrayConverter and then casts it to the appropriate type */
    public ArrayConverter copy() {
        return (ArrayConverter) clone();
    }
    
    /** Specify the ArrayHeaderLocator object that maps column names to column numbers.  This is 
     * not required if you don't specify Converters by column name
     */
    public void setArrayHeaderLocator(ArrayHeaderLocator headerLocator) {
        this.headerLocator=headerLocator;
    }
    /** Set the ArrayHeaderLocator by passing in an array representing the column names*/
    public void setArrayHeaderLocator(String[] header) {
        setArrayHeaderLocator(new ArrayHeaderLocator(header));
        
    }
    
    private ArrayHeaderLocator getArrayHeaderLocator() {
        return headerLocator;
    }
    


     /** Performs a shallow copy of the passed in array */
    private Object[][] getData(Object[][] data) {
        if (overWriteExistingArray())
          return data;
        else
          return Utils.copy(data);
     }
    
    public String toString() {
        return "Factory="+factory+"\nheaderLocator="+headerLocator+"\noverWriteExistingArray="+overWriteExistingArray();
    }
    
    /** Method that has test and sample usage code */
    public static void main(String[] args) throws Exception {
        FormattedDataSet fds=new FormattedDataSet();
        ArrayConverter ac=new ArrayConverter(new String[]{"fname","lname"});
        Object[][] data = { {"jeff","beck",new Integer(1000), new Long(999999), new Float(123.756), new Date(), new Boolean(true), "beck",},
                            {"william","reid",new Integer(1000000), new Long(99999999), new Double(3456.789), new Date(), new Boolean(true), "reid",},
                            {"iggy",null,new Integer(1000000), new Long(99999999), new Double(3456.789), new Date(), new Boolean(false), null,},
                          };
        ac.convert(data);
                         
        //ac.setColConverter(2, new ConverterNumToString(NumberFormat.getCurrencyInstance())); // don't format column 2.
        //ac.setColConverter(5, new ConverterDateToString());
        //ac.setColConverter(4, new NullConverter());
        Map converterMap=new HashMap();
        converterMap.put("reid", "JIMMY");
        converterMap.put(null, "&nbsp;");
        converterMap.put(new Boolean(true), "yes");
        converterMap.put(new Boolean(false), "no");
        
        ac.setColConverter("lname", new ConverterMapValue(converterMap));
        ac.setColConverter(6, new ConverterMapValue(converterMap));
        // Note that below col 7 is also named lnameagain, and so there is a conflict.  In this 
        // case the last converter entered wins (by name)
        ac.getArrayHeaderLocator().setColName("lnameagain", 7);
        ac.setColConverter(7, new NullConverter()); // won't be used as 'lnameagain' occurs afterwards
        ac.setColConverter("lnameagain", new ConverterMapValue(converterMap));
                         
        Map map=new HashMap();
        map.put("delimiter", " - ");
        System.out.println("Data not formatted:");
        System.out.println(fds.getFormattedDataSet(null, data, map,"delimited")); // should not change original array
        
        System.out.println("Data formatted:");
        System.out.println(fds.getFormattedDataSet(null, ac.convert(data), map,"delimited"));
        
        ac.setOverWriteExistingArray(true);
        System.out.println("Data not formatted (overwrite existing array):");
        System.out.println(fds.getFormattedDataSet(null, data, map,"delimited")); // should not change original array
        
        System.out.println("Data formatted (overwrite existing array - original array displayed below):");
        ac.convert(data);
        System.out.println(fds.getFormattedDataSet(null, data, map,"delimited"));
        
        System.out.println(fds.getFormattedDataSet(null, MonitorFactory.getRootMonitor().getData(), map,"delimited"));

        // Test to see that cloning works and original copy is not changed.
        ArrayConverter ac2=ac.copy();
        ac2.setColConverter(25, new NullConverter());
        ac2.setDefaultConverter(new NullConverter());// note  this will show up as entry 0 0 in positionMap
        ac2.setTypeConverter(String.class, new NullConverter());
        
        System.out.println(ac+"\n");
        System.out.println(ac.copy()+"\n");
        System.out.println(ac2+"\n");
        
       

    }
}
