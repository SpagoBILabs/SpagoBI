/*
 * ArrayConverterFactory.java
 * 
 * Created on February 20, 2005, 4:50 PM
 */

package com.fdsapi.arrays;

import java.util.*;
import com.fdsapi.*;
import com.jamonapi.*;
import com.jamonapi.utils.*;

/** 
 * This class returns an array of Converter objects to be used in Converting an array based on the
 * rules speicied below.
 *
 * This class is not thread safe, however if the factory elements are set at say application 
 * startup then it can be used in a thread safe manner.  
 *
 * When looking up which Converter to use for each column in the array the following 
 * precedence order is used:
 * 
 * 1) If a Converter was registered for the column.  This can done by either column number or column
 * name.  In the case where both a column number and column name Converter were specified (a tie) 
 * the last one that was registered will be used.  
 * 2) If a Converter was registered for the column data type then use that Converter.  The first cell
 * within the column is used to get the data type.  If the value is a null then there is no type. The most
 * specific data type is matched first and then the inheritance chain is walked to find a match.  If there
 * is still no match then the interface tree is walked looking for a match. If there is still no match then
 * an attempt is made to match Object.class.  If there is no matches then proceed to the next step.
 * 3) If there have been no matches to this point then the overall default Converter is used.
 * 
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ArrayConverterFactory.htm">View Code</a>

 */

public class ArrayConverterFactory implements Cloneable {

    private Map converterMap=null;  // used to a hold the column number key .
    // sequenceMap - used to determine precedence between column number and column names (i.e. last wins 
    // based on highest sequence number)
    private Map sequenceMap=null; 
    private int sequence;
    private final int NOTINMAP=-54321;// constant that indicates an element is not in a map
    private static final Converter NULL_CONVERTER=new NullConverter();
    private Converter defaultConverter=NULL_CONVERTER;
    
    /** default constructor */
    public ArrayConverterFactory() {
        converterMap=AppMap.createInstance();
        sequenceMap=AppMap.createInstance();
    }
    
    // Constructor used for cloning
    private ArrayConverterFactory(Map converterMap, Map sequenceMap, Converter defaultConverter, int sequence) {
        this.converterMap=converterMap;
        this.sequenceMap=sequenceMap;
        this.defaultConverter=defaultConverter;
        this.sequence=sequence;
    }
    
    
   
    private Converter getConverter(Object key) {
      Converter converter=(Converter) converterMap.get(key);
      if (converter==null)
        return null;
      else
        return converter.createInstance();
    }
    


    /** Set the Converter to be used if no other matches occur based on column, or data type */
    public void setDefaultConverter(Converter converter) {
       defaultConverter=converter;
    }
    private Converter getDefaultConverter() {
       return defaultConverter.createInstance();
    }


    /** Set the column Converter by number.  This Converter will be used by any data within this column */
    public void setColConverter(int colNum, Converter converter) {
       setConverter(new Integer(colNum), converter); 
    }
    /** Remove the column Converter associated with the column number. */
    public void removeColConverter(int colNum) {
        removeConverter(new Integer(colNum));
    }
    
    /** Set the column Converter by name.  This Converter will be used by any data within this column */
    public void setColConverter(String colName, Converter converter) {
        setConverter(colName, converter);
    }
    /** Remove the column Converter associated with the column name */
    public void removeColConverter(String colName) {
        removeConverter(colName);
    }
    
    
    /** Set the column Converter by data type.  This Converter will be used by any data that matches this Data type rules
     * subject to the rules specified above.
     */
    public void setTypeConverter(Class type, Converter converter) {
        setConverter(type, converter);
    }    
    /** Remove the Converter associated with the data type */
    public void removeTypeConverter(Class type) {
        removeConverter(type);
    }

    // Puts the Converter in the map using a key (colnumber, colname, data type), and also
    // puts the sequence that this entry was put in the map.  This is used when both 
    // column names and column numbers have been used. The last one in the maps is used in this
    // case (i.e. the one with the highest sequence number)
    private void setConverter(Object key, Converter converter) {
       converterMap.put(key, converter); 
       sequenceMap.put(key, new Integer(sequence++));
    }
    // Remove the specified Converter
    private void removeConverter(Object key) {
       converterMap.remove(key);
       sequenceMap.remove(key);
    }
    
    // Get the sequence number associated with the Converter.  in the case when both column name 
    // and column number have Converters the one with the highest sequence number is used
    private int getSequence(Object key) {
        if (sequenceMap.containsKey(key))
          return ((Integer) sequenceMap.get(key)).intValue();
        else 
          return NOTINMAP;
    }
    
    /** This method returns an array of Converter objects.  The array will have a Converter for each
     * column in the Array that was passed in.  The arrayHeaderLocator is used to associate Converters
     *that were registered by column name to the data.
     */
    public Converter[] getConverters(ArrayHeaderLocator colNameLocator, Object[][] data) {
        int size=(data==null || data.length==0) ? 0 : data[0].length;
        Converter[] converters=new Converter[size];
        
        for (int j=0;j<size;j++) {
           // The following are performed in precedence order.  
           // 1) converter by col number or name.  if both are defined use the
           //  one with the highest sequence number
           // 2) if there is a converter by data type use it
           // 3) if still no converters have been selected use the overall default Converter

           // see if a Converter has been defined for the column
           Integer colKey=new Integer(j);
           String colName=colNameLocator.getColName(j);
           // get a Converter registered by column number or name if one exists.  If both
           // exists the most recently executed one is returned.
           Converter converter=getConverter(j, colName);
           
           // If a column Converter was not found take the default based on data type.  
           if (converter==null)
             converter=getTypeConverter(data[0][j]);

           // If a Converter still hasn't been found then the defaultConverter is used.  
           // If the user has not changed the default then the NullConverter is used.
           // all very beautiful.
           if (converter==null)
             converter=getDefaultConverter();

           converters[j]=converter;
        }
        
        return converters;
        
    }
    
  
    
    // find the Converter registered by column number or name
    private Converter getConverter(int colNum, String colName) {
      Integer colKey=new Integer(colNum);
      Converter converter=null;
  
      // The following logic returns the most recently registered Converter between
      // col number or column name.  If only one is registered then that one is returned.
      if (getSequence(colKey)>getSequence(colName))
        converter=getConverter(colKey);
      else if (getSequence(colName)>getSequence(colKey))
        converter=getConverter(colName);
      
      return converter;

    }
    
    // get the Converter based on class type.
    private Converter getTypeConverter(Object obj) {
        // This class looks in the typeMap for the most specific type it can match and then
        // keeps going up the base class chain until there are no more looking for a match.
        // If no matches are found then a NullConverter() is returned.
        Class type = (obj==null) ? null : obj.getClass();
        do {
          // note a field can be mapped to any class or even null.
          if (converterMap.containsKey(type))
            return ((Converter) converterMap.get(type)).createInstance();
          
          if (type!=null)
            type=type.getSuperclass();
          
        } while (type!=null);
        
        return null;
        
    }
    

    
    /** This method returns an array of the classes and interfaces that the passed
     * in Object extends or implements.  
     */
    public static Class[] getTypes(Object obj) {
       return (obj==null) ? null : obj.getClass().getInterfaces();
    }
    
    /** Clone this factory */
    public Object clone() {
        // Note because the Map interface and Object base class don't support cloning
        // the maps must be casted to an AppMap which inherits its ability to do a shallow
        // clone through HashMap.  In the case of this factory a shallow copy is ok as the only
        // method that is called on the Converters in the maps is createInstance(). i.e. No state is 
        // changed in the converters in the map.
        Map cm=(Map) ((AppMap) converterMap).clone();
        Map sm=(Map) ((AppMap) sequenceMap).clone();
        
        return new ArrayConverterFactory(cm, sm, defaultConverter, sequence);
      
    }
    
    /** Clones this factory and returns it as the factory type.  This is useful if you want to reuse
        part of a factory and make changes/additions to it 
     */
    public ArrayConverterFactory copy() {
        return (ArrayConverterFactory) clone();
    }
    
    public String toString() {
        return "converterMap="+converterMap+"\ndefaultConverter= "+defaultConverter;
    }
    
   /** Test and sample usage code */
   public static void main(String[] args) {
       ArrayConverterFactory f1=new ArrayConverterFactory();
       f1.setColConverter(1, new NullConverter());
       f1.setTypeConverter(Object.class, new NullConverter());
       f1.setDefaultConverter(new NullConverter());
       ArrayConverterFactory f2=f1.copy();
       f2.setColConverter(25, new ConverterNumToString());

       // f2 should have the new converter in it while f1 remains unchanged
       System.out.println(f1);
       System.out.println(f2);
       
   }
    

}
