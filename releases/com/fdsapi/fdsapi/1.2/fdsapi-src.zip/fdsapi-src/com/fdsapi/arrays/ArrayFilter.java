
package com.fdsapi.arrays;  // FormattedDataSet API

import java.util.*;
import com.fdsapi.*;
import com.jamonapi.*;
import com.jamonapi.utils.AppMap;


/**
 *  <p>This class does for arrays what a SQL select statement for a database table.  For example in a select
 *  statement you can display or not display columns by including them in the select column list.  Example:
 *  select col1,col1,col2,col5.  The addDisplayCol(...) methods in the ArrayFilter class are analagous.
 *  In the SQL select statement you can also limit/filter rows by using where conditions.  For example:
 *  select col1,col1,col2,col5 from table where col1='A' and (col2<=100 or col5 like 'john%').  The ArrayFilter
 *  has methods that can build up such conditionals.  The addConditional(...) methods build each 
 *  individual conditional (i.e. col1='A'), addAnd()/addOr() methods are called in between calls to 
 *  addConditional() to string them together, and parenthesis are controlled with addLeftParen(), and 
 *  addRightParen() (opening/left and closing/right parens respectively).</p>
 *
 *  <p>The original ArrayFilter class was designed by Ed Desrosiers.  Steve Souza refactored this class,
 *  and added design patterns (Primarily the gang of 4's Composite and Decorator patterns.)</p>
 *
 *  <p>To see sample code click on view code below.  The classes main method has plenty of examples.</p>
 
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ArrayFilter.htm">View Code</a>
 * <p>Authors: Steve Souza and Ed Desrosiers</p>
*/



public class ArrayFilter {
    // Contains columns that will be displayed.  Similar to the list of columns in a SQL select statement.
    private List displayCols = new ArrayList();
    // Contains column names to be used in toString() representation of the ArrayFilter
    private ArrayList displayColList=new ArrayList();
    private ResultSetUtils rsu = ResultSetUtils.createInstance();
    // ConditionalComposite that contains all other Conditionals in the ArrayFilter
    private ConditionalCompositeContainer rootComposite=new ConditionalCompositeContainer();
    // Contains logic column names.  Arrays are typically index based not name based.
    // true means to throw an exception if the column name doesn't exit.
    private ArrayHeaderLocator headerLocator=new ArrayHeaderLocator(true);
    private static ColumnFunctionFactory colFunctionFactory=new ColumnFunctionFactory();
    // Used to format/convert the array returned by ArrayFilter
    private ArrayConverter arrayConverter=null;

    
    
    /** Creates a new instance of ArrayFilter */
    public ArrayFilter() {
        this.arrayConverter=new ArrayConverter();
    }

        /** Creates a new instance of ArrayFilter */
    public ArrayFilter(ArrayConverter arrayConverter) {
        this.arrayConverter=arrayConverter;
    }

    /** <p>Creates a new instance filter and allows the columns to be referenced by the label in both
     * display columns and where clauses.  Arrays don't have the concept of named columns and this
     * array gives them this capability.  For example in the following example after calling this 
     * constructor col0 can be referred to as fname, and col1 can be referred to as lname.  
     * The names are not case sensitive</p>
     *
     *  <b>Sample Call:</b><br><br><blockquote><code><pre>
     *  String[] header={"fname","lname"};
     *  ArrayFilter f=new ArrayFilter(header); 
     *  f.addDisplayCol("fname");
     *  f.addDisplayCol("lname");
     *  f.addConditional("LNAme","=","souza");
     *  Object[][] data=f.filter(names);
     * </blockquote></code></pre>
     */
    public ArrayFilter(String[] header) {
        this(header, new ArrayConverter(header));
    }
    
    public ArrayFilter(String[] header, ArrayConverter arrayConverter) {
        // Note Integer object is used to map a logical name back to the index.
        headerLocator = new ArrayHeaderLocator(header, true);
        this.arrayConverter=arrayConverter;
    }
    
    
    
   
    /** <p>Return the array filtered on both rows and columns.  The effect of this method and the ArrayFilter
     ** in general is to return a subset of an array much like a select statement does for a database
     ** table.  For example if a table has 4 columns and 100 rows, then a select statement may only bring
     ** back 3 of the columns and half of the rows based on conditions in the where clause.
     *  Note the array passed in is unchanged and a the method returns the filtered array. Note also if a null array
     *  is passed in it will be returned and no error will occur.  If there are no matches on the array it will return
     *  an empty array (i.e. it will be a valid array with no rows or columns).</p>
     *
     * <p>For examples of using this method click the view code href above</p>
     **/

    public Object[][] filter(Object[][] fullArray){
        Monitor mon=AppConstants.start("arrays.ArrayFilter.filter(Object[][])");
        Object[][] filteredArray=null;
        try {

          if (fullArray==null)
            return fullArray;
          
          validate();  // validate that synax is ok
          build();  // build underlying objects i.e. Composites and Conditionals
          resetDisplayCols();
          
          // ArrayList where resulting filtered array will be stored.
          ArrayList matchingArray = new ArrayList();
          int rows=fullArray.length;
          for (int i = 0; i < rows; i++){
            // for all rows in fullArray check to see if row should be included by calling keepRow which calls
            // all conditionals and returns true if the row should be kept.
            if (keepRow(fullArray[i])) {
              // return an array that only contains the columns that were specified.
              Object[] row=filterCols(fullArray[i]);
              matchingArray.add(row);
            }
          }
        
          filteredArray = rsu.listToObjectArray(matchingArray);
        } finally {
          mon.stop();  
        }
          
        return filteredArray;
        
    }
    

   /** <p>This method executes the query against the data and converts the data with the ArrayConverter.  This method first calls
     *  execute(...).:</p> 
     *
     * <b>Sample Code:</b><br><br>
     * 
     * <blockquote><code><pre>
     * ArrayFilter filter=new ArrayFilter();
     * filter.addDisplayCol(5);
     * filter.convert(data); 
     * </pre></code></blockquote>
     */    
    public Object[][] convert(Object[][] data) {
        Monitor mon=AppConstants.start("arrays.ArrayFilter.convert(Object[][])");
        try {
            return getArrayConverter().convert(filter(data));
        } finally {
            mon.stop();
        }
        
    }
    
    /** Get the underlying ArrayConverter that backs the ArrayFilter object */
    public ArrayConverter getArrayConverter() {
        return arrayConverter;
    }
   
    /** Set the underlying ArrayConverter that backs the ArrayFilter object */
    public void setArrayConverter(ArrayConverter arrayConverter)  {
        this.arrayConverter=arrayConverter;
    }
        
    
    private void resetDisplayCols() {
      // This routine ensures that variables for cols are reset after each iteration.
      // For example the rownum() counter must be reset after looping through the data
      // each time.
      List list=new ArrayList();
      Iterator iter=displayCols.iterator();
      while (iter.hasNext()) {
       Column col=(Column)iter.next();
       list.add(col.createInstance());
      }
      
      displayCols=list;
       
    }

    /** Method that calls the first composite in the chain which subsequently calls all other Conditionals
     * to determine if the row matches based on how the Conditionals evaluate.
     */
    private boolean keepRow(Object[] rowOfArray) {
        for (int col=0; col<rowOfArray.length; col++) {
            if (!rootComposite.isTrue(rowOfArray))
                return false;
        }
        
        return true;
    }

    /** Throws a runtime exception if the ArrayFilter violated a syntax error */
    private void validate() {
         rootComposite.validate();
    }
    
    private void build() {
        rootComposite.build();
    }
    

    /** <p>Add a Conditional to be called against a given column.  Note ==, and = can take Objects as the comparisonValue, but any of the &lt;,&lt;=,&gt;,&gt;= must
     * take a Comparator as an argument.  Another option is to use the alternative signature
     * that adds a Conditional directly.  </p>
     *
     * <p>Arguments: 1) int col - must be >=0 and it represents the index of the array that you would like to have the
     * conditional act against.   2) String type - is the type of Conditional. Currently valid values are:  =,==,&lt;,&lt;=
     * &gt;,&gt;=,&lt;&gt;,!=,like,not like,in,not in which work as you would expect.  See the ConditionalFactory for further info.
     *3) Object comparisonValue - is the value that will be compared against the array column.</p>
     *
     * <p>The Conditional will be added at the current paren level</p>
     *
     * 
     */
    
    public void addConditional(int col, String type, Object comparisonValue) {
      Conditional conditional=ConditionalFactory.createInstance(col, type, comparisonValue);
      rootComposite.addConditional(conditional);
    }

    
    /**
     * <p>Add a conditional against the named column.  This column must match one that was passed in 
     * with the contructor that takes a String[] header. If not a RuntimeException will be thrown. The
     * Conditional will be added at the current paren level.</p>
     */
    public void addConditional(String colName, String type, Object comparisonValue) {
      int col=getColNumFromName(colName);
      Conditional conditional=ConditionalFactory.createInstance(col, type, comparisonValue);
      rootComposite.addConditional(conditional);
    }
    
    
 
    /** <p>This method can be used if you create your own Condtional and would like it to be called to see
     * if the row should be retained.   The Conditional will be added at the current paren level.</p>
     */
    public void addConditional(Conditional conditional) {
      rootComposite.addConditional(conditional);
    }
    
    
    /** Negate the current paren level/composite.  This means that if the current paren level returns
     * true it will now return false and vice versa.
     */
    public void addNot() {
        rootComposite.addNot();
    }
    
    /** Used to indicate that two conditionals are true only if both of them are true.  (i.e. col1=1 and col2=50)
     **/
    public void addAnd() {
       rootComposite.addAnd();
    }
        
    /** Used to indicate that two conditionals are true if one or both of them are true.  (i.e. col1=1 or col2=50)
     **/
    public void addOr() {
       rootComposite.addOr();
    }
    
    /** Group logicals together with parens.  This method represents a left/open paren in the grouping:
     *col1=2 && (col2==50  || col2=100).  This method is comparable to the left paren after && in the example.  If this
     *method is called addRightParen() must also be called.
     */
    public void addLeftParen() {
       rootComposite.addLeftParen();
    }
            
 
        
    /** Group logicals together with parens.  This method represents a right/closed paren in the grouping:
     *col1=2 && (col2==50  || col2=100).  This method is comparable to the right paren before the first col2 in the example.
     *If this method is called addLeftParen() has to be called first.
     */
    public void addRightParen() {
        rootComposite.addRightParen();
    }
           
    


    /** This method is used to determine which columns should be dispalyed in the copied array.  At this point it has
      already been determined that the row should be displayed.  This routine just determines which columns in the
      row should be displayed.*/
    private Object[] filterCols(Object[] originalRow) {
        Object[] filteredRow=null;

        // if no cols have been specified for display then return all columns.  The following sizes the
        // filteredRow appropriately and populates it with all the data from the originalRow.
        if (getNumberOfDisplayCols()==0) 
          filteredRow=copyAllCols(originalRow);
         else   // else if any columns were filtered (added) i.e. addDisplayCol(..) was called.
          filteredRow=copyFilteredCols(originalRow);

        return filteredRow;
         
    }
    
    /** Called when all columns in the row should be copied */
    private Object[] copyAllCols(Object[] originalRow) {
       return Utils.copy(originalRow);
    }
    
    /** Called only when some of the columns in the row should be filtered */
    private Object[] copyFilteredCols(Object[] originalRow) {
       int filteredColIndex=0;
       Object[] filteredRow=new Object[getNumberOfDisplayCols()];
       
       Iterator iter=displayCols.iterator();
       while (iter.hasNext()) {
          Column col=(Column)iter.next();
          filteredRow[filteredColIndex++]=col.getObject(originalRow);
       }
       
       return filteredRow;
       
    }

    
    /** Select a column number to be displayed.  Analagous to a column that is listed in a select
     * statement.  A RuntimeException is thrown if the column number is less than 0.  The column number
     * is indexed starting at 0 (as arrays are) and can't be greater than the the number of columns in the array 
     * minus one.  The order that this method is called is the order that the columns will be displayed in.  Columns can 
     * also be displayed more than once. Technically the columns are returned not displayed.  
     */
    public void addDisplayCol(int columnNumber){
        if (columnNumber >= 0) {
          displayColList.add("col"+columnNumber);
          displayCols.add((new ColumnData(columnNumber)));
        }
        else
            throw new IllegalArgumentException("The column number must be greater than 0.  It was "+columnNumber);
    }

    
    /**
     * Display the named column.  This column must match a column name passed into the constructor.  The columns in the
     * resulting array from filter(array) will appear in the order that the addDisplayCol(...) methods are called in.  Columns can
     *also be displayed more than once.  Technically columns are returned not displayed.
     */
    public void addDisplayCol(String columnName){
        displayColList.add(columnName);
        displayCols.add(new ColumnData(getColNumFromName(columnName)));
    }
    
    public void addDisplayFunction(String functionName) {
        displayColList.add(functionName);
        displayCols.add(colFunctionFactory.getFunction(functionName));
        
    }
    
    /** Returns the column number when passed a column name that matches the header array passed into the Constructor */
    public int getColNumFromName(String columnName) {
        return headerLocator.getColNum(columnName);
    }
    

    /** Returns the number of times that the addDisplayCol(...) methods were called. i.e. returns the number of columns to be displayed. */
    private int getNumberOfDisplayCols() {
        return displayCols.size();
    }

    /** Create a string representation of the ArrayFilter object.  This is useful for debugging.  An example is
     * of a String that could be returned is:  select col1,col2,lname from array where (col1=50000 && (col2=25 || lname='souza))
     */
    public String toString() {
        String select="select "+getDisplayColStr()+" from array";
        String whereCond=rootComposite.toString();
        return select+whereCond;
    }
    
    /* returns the select display columns as a string.  i.e. col1,col2,lname */
    
    private String getDisplayColStr() {
        String cols="";
        if (displayColList.size()==0) 
           cols="*";
        else {  // build something like col0, colname2, colname3
           Iterator iter=displayColList.iterator();
           while (iter.hasNext()) {
               cols+=iter.next();
               
               if (iter.hasNext()) // if not last element
                 cols+=",";
           }
        }
        
        return cols;
    }
    
    ColumnFunctionFactory getColumnFunctionFactory() {
        return colFunctionFactory;
    }
    
    // method only used in main method to display output to the screen for testing.
    private static void  printDebugInfo(ArrayFilter f, Object[][] data) {
        // Used the FormattedDataSet to display the array in csv format using the csv template.
        FormattedDataSet fds=FormattedDataSet.createInstance();
        String str=fds.getFormattedDataSet(null, data, "csv");
        Utils.log("***filter="+f);
        Utils.log(str);
        
        
    }

  

    /** Test and Sample code for the ArrayFilter.  View this classes source code for 
     * examples on how to use the ArrayFilter.
     */
    public static void main(String[] args) {
        
        // Array to be filtered later in code
        Object[][] orig = {
        {"Row 1", "JAVA", new Boolean(true), new Integer(15)},
        {"Row 2", "JAVA", new Boolean(true), new Integer(5)},
        {"Row 3", "PERL", new Boolean(true), new Integer(111)},
        {"Row 4", "JAVA", new Boolean(false), new Integer(26)},
        {"Row 5", "JAVA", new Boolean(true), new Integer(51)},
        {"Row 6", "C", new Boolean(true), new Integer(52)},
        {"Row 7", "C", new Boolean(false), new Integer(51)},
        {"Row 8", "C++", new Boolean(false), new Integer(52)},
        {"Row 9", "C++", new Boolean(false), new Integer(55)},
        {"Row 10", "C++", new Boolean(false), null},
        };
        // used as header for data above.
        String[] header = {"row", "Lang", "bool", "count"};
        Object[][] filtered=null;
        
        // Used as data to filter later in the code.
        for (int i=0;i<25;i++)
           MonitorFactory.start("page"+i+".jsp").stop();
        
        MonitorFactory.start("hello-mypage.jsp").stop();
        MonitorFactory.start("zhello").stop();
        
 
        // Display the columns many times.  Note how many times col0 is displayed.
        ArrayFilter f = new ArrayFilter();
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(1);
        f.addDisplayCol(0);
        f.addDisplayCol(3);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(0);
        f.addDisplayCol(2);
        f.addDisplayCol(3);

        // filter the data based on the above display cols.  no rows will be filtered out 
        // as no conditionals have been set.
        filtered = f.filter(orig);

        // Display the array filtering (and adding certain cols)
        printDebugInfo(f, filtered);

        // Display the full array because no rows or cols have been filtered.  The effect of this
        // is to copy the array.
        f=new ArrayFilter();
        filtered=f.filter(orig);
        printDebugInfo(f,filtered);
        
        // Test conditionals
        f=new ArrayFilter(); // !(col1='java' or col2=true)
        f.addConditional(1,"=","JAVA");
        f.addAnd();
        f.addConditional(0,"<=","Row 4");
        
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);
        
        // col3<=26
        f=new ArrayFilter(); 
        f.addConditional(3,"<=",new Integer(26));
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        
        // col3>26
        f=new ArrayFilter(); 
        f.addConditional(3,">",new Integer(26));
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);
        
        // col3 like 52.  note the Integer will be converted to a String to work with 'like'
        f=new ArrayFilter(); 
        f.addConditional(3,"like",new Integer(52));
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);
 
        // col3 like 52.  note the Integer will be converted to a String to work with 'like'
        f=new ArrayFilter(); 
        f.addNot();
        f.addConditional(3,"like",new Integer(52));
        filtered=f.filter(orig);
        System.out.println("**********");
        printDebugInfo(f, filtered);
        
        // col0 like .jsp (like uses Regular Expressions.
        f=new ArrayFilter();
        f.addConditional(0, "like", ".jsp");
        filtered=f.filter(MonitorFactory.getRootMonitor().getData());
        ArrayComparator.sort(filtered, 0, "desc");
        printDebugInfo(f, filtered);

        // col0 not like .jsp
        f=new ArrayFilter();
        f.addConditional(0, "not like", ".jsp");
        filtered=f.filter(MonitorFactory.getRootMonitor().getData());
        printDebugInfo(f, filtered);
        // Use the ArrayFilter to filter out JAMon data
        // col0 like com.fdsapi.arrays.
        f=new ArrayFilter();
        f.addConditional(0, "like", "com.fdsapi.arrays.");
       
        filtered=f.filter(MonitorFactory.getRootMonitor().getData());
        printDebugInfo(f, filtered);
        
        // use column names instead of column numbers.  The below is similar to 
        // select row,lang,bool,count,LANG,col0 from array where Lang=JAVA || lang=C++
        f=new ArrayFilter(header);
        f.addDisplayCol("row");
        f.addDisplayCol("lang");
        f.addDisplayCol("bool");
        f.addDisplayCol("count");
        f.addDisplayCol("LANG");
        f.addDisplayCol(0);
        f.addConditional("Lang","=","JAVA");
        f.addOr();
        f.addConditional("lang","=","C++");
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);
   

        // select row,lang from array where lang in (JAVA,C,PERL) && lang not in (PERL)
        f=new ArrayFilter(header);
        f.addDisplayCol("row");
        f.addDisplayCol("lang");
        f.addConditional("lang","in",new String[]{"JAVA","C","PERL"});
        f.addAnd();
        f.addConditional("lang","not in",new String[]{"PERL"});
        
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        // select row,lang from array where lang in (JAVA,C,PERL) && lang not in (PERL)
        f=new ArrayFilter(header);
        f.addDisplayFunction("rowNum()");
        f.addDisplayFunction("'steve'");
        f.addDisplayCol("row");
        f.addDisplayCol("lang");
        f.addDisplayFunction("'souza'");
        f.addDisplayFunction("\"jones\"");
        f.addDisplayFunction("date()");
        
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        // select * from array where lang='JAVA' && bool=true && count=15
        f=new ArrayFilter(header);
        f.addConditional("lang","=","JAVA");
        f.addAnd();
        f.addConditional("bool","=", new Boolean("true"));
        f.addAnd();
        f.addConditional("count","=",new Integer(15));
      
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        // select * from array where lang='JAVA' && bool=true && count=15
        f=new ArrayFilter(header);
        f.addConditional("lang","=","JAVA");
        f.addAnd();
        f.addConditional("bool","=", new Boolean("true"));
        f.addOr();
        f.addConditional("count","=",new Integer(4000));
      
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        // select * from array where lang='JAVA' && bool=true && count=15
        f=new ArrayFilter(header);
        f.addConditional("lang","=","JAVA");
        f.addOr();
        f.addConditional("count","=",new Integer(4000));
        f.addAnd();
        f.addConditional("bool","=", new Boolean("true"));
      
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);
        
        // select * from array where lang='JAVA' && bool=true && count=15
        f=new ArrayFilter(header);
        f.addConditional("lang","=","JAVA");
        f.addAnd();
        f.addConditional("count","=",new Integer(4000));
        f.addOr();
        f.addConditional("bool","=", new Boolean("true"));
      
        filtered=f.filter(orig);
        printDebugInfo(f, filtered);

        Object[][] test={{new Integer(10000), new java.util.Date(), new Float(10001.13)}};
        f=new ArrayFilter();
        printDebugInfo(f, f.convert(test));
        
        
    }
    
}
