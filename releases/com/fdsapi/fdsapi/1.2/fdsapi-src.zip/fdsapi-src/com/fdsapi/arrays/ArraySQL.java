/*
 * ArraySQL.java
 *
 * Created on June 30, 2004, 5:39 PM
 */

package com.fdsapi.arrays;

import com.fdsapi.*;
import com.jamonapi.*;
import java.util.*;
import java.math.*;

/**
 *  <p>This class does for arrays what a SQL select statement for a database table.  For example in a select
 *  statement you can display or not display columns by including them in the select column list.  Example:
 *  select col1,col1,col2,col5 from array.  In the SQL select statement you can also limit/filter rows by using where 
 *  conditions.  For example:  select col1,col1,col2,col5 from array where col1='A' && (col2<=100 || col5 in ('jim',john')).  
 *  Ordering is also possible as it is with a SQL select: select * from array where fname='steve' order by lname desc, salary asc</p>
 * 
 * <p>ArraySQL is backed by the ArrayFilter and ArrayComparator objects</p>
 *
 *  <p>To see sample code click on view code below.  The classes main method has plenty of examples. Note where clauses must be of the
 *   format where col0='souza' as opposed to 'souza'=col0 (i.e. the column must come first)</p>
     
 *
 *  <p>Notes:  Exceptions:  1) no query 2) colname that isn't in header 3) not asc or desc.
 *  Also note string checks for equality are case sensitive.  like is not case senstive.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ArraySQL.htm">View Code</a>
 */
public class ArraySQL {
    private ArrayFilter arrayFilter=null;
    private ArrayComparator arrayComparator=null;
    private String query;
    private boolean parseQuery=true;
    private boolean copyData=false;
    
    /** Creates a new instance of ArraySQL */
    public ArraySQL(String query) {
          this.query=query;
          this.arrayFilter=new ArrayFilter();
          this.arrayComparator=new ArrayComparator();
    }
    
    public ArraySQL(String[] header, String query) {
          this.query=query;
          this.arrayFilter=new ArrayFilter(header);
          this.arrayComparator=new ArrayComparator(header);
    }
    
    private void buildObject(Object[][] data) {
        Monitor mon=start("buildObject()");
        try {
            // setting the where clause i.e. setWhereClause() is defferred until the array
            // being queried datatypes are known.  setting select cols is defferred to allow
            // syntax such as select rownum(),* from array
             setSelectCols(data);
             setWhereClause(data);
             setOrderByClause();
        } finally {
            mon.stop();
        }
    }
    
    private String getSelectCols() {
        return SelectColsParser.getSelectCols(query);
    }
    
    private String getWhereClause() {
        return WhereClauseParser.getWhereClause(query);
    }
    
    private String getOrderByClause() {
        return OrderByParser.getOrderByClause(query);
    }
    
    private String[] split(String reStr, String splitStr) {
        return Utils.split(reStr, splitStr);
        
    }
    
    private String[] getOrderByClauseArr() {
        return split(",",getOrderByClause());
    }
    
    
    private void setSelectCols(Object[][] data) {
        SelectColsParser p=new SelectColsParser(data, getSelectCols(),getArrayFilter());
        p.addSelectCols();
    }
    
    
    private void setWhereClause(Object[][] data) {
        WhereClauseParser p=new WhereClauseParser(data, getWhereClause(), getArrayFilter());
        p.addWhereClause();
        
    }
    
    private void setOrderByClause() {
        OrderByParser p=new OrderByParser(getOrderByClause(), getArrayComparator());
        p.addSortCols();
    }
    
    
    
    
    /** Performs a shallow copy of the passed in array
     */
    public static Object[][] copy(Object[][] data) {
        return ArrayComparator.copy(data);
    }
    
    private Monitor start(String label) {
        return AppConstants.start("arrays.ArraySQL."+label);
    }
    
    /** <p>This method executes the query against the data.  A side effect is that the original data is sorted.  
      * If you wish not to sort the original data then you should call setCopyData(false).  Note execute can be called
      * as many times as needed against the same or different arrays.  :</p> 
     *
     * <b>Sample Code:</b><br><br>
     * 
     * <blockquote><code><pre>
     * ArraySQL asql=new ArraySQL("select * from array");
     * asql.setCopyData(false);
     * asql.execute(ArraySQL.copy(data));
     * </pre></code></blockquote>
     
     */
    public Object[][] execute(Object[][] data) {
        Monitor mon=start("execute(Object[][])");
        Object[][] retData=null;
        if (data==null)
          return null;
        
        try {
            // lazy whereClause parsing due to the fact that data is required for the parsing (i.e. this is how the data type 
            // is determined).  Note as long as the data types don't change the passed in data is ok.  The select
            // cols are also parsed based on runtime data.
            if (parseQuery) {
                buildObject(data);
                parseQuery=false;
            }
            
            // This will copy the input array so it won't be sorted.  By default it will not copy the data.
            // When a copy of the data is taken this only copies the first dimension of the array (rows), so sorting won't affect the original
            // array.
            if (getCopyData())
              data=copy(data);
            
            getArrayComparator().sort(data);  // sort the data
            retData=getArrayFilter().filter(data);  // execute the column filter and where clauses
        } finally {
            mon.stop();
        }
        
        return retData;
    }
    
    
    /** <p>This method executes the query against the data and convers the data with the ArrayConverter.  This method first calls
     *  execute(...).:</p> 
     *
     * <b>Sample Code:</b><br><br>
     * 
     * <blockquote><code><pre>
     * ArraySQL asql=new ArraySQL("select * from array");
     * asql.convert(data); 
     * </pre></code></blockquote>
     */    
    public Object[][] convert(Object[][] data) {
        Monitor mon=start("convert(Object[][])");
        try {
           return getArrayConverter().convert(execute(data)); 
        } finally {
          mon.stop();
        }

    }
    
    /** The passed in query */
    public String toString() {
        return query;
    }
    
    /** Get the underlying ArrayFilter that backs the ArraySQL object. */
    public ArrayFilter getArrayFilter() {
        return arrayFilter;
    }

    /** Get the underlying ArrayComparator that backs the ArraySQL object. */
    public ArrayComparator getArrayComparator() {
        return arrayComparator;
    }
    
    /** Get the underlying ArrayConverter that backs the ArraySQL object */
    public ArrayConverter getArrayConverter() {
        return getArrayFilter().getArrayConverter();
    }
     
    public void setArrayConverter(ArrayConverter arrayConverter)  {
       getArrayFilter().setArrayConverter(arrayConverter);
    }
    

    /** Get a debug String.  This debug string gets its information from the backing ArrayComparator and ArrayFilter.  This method should
     ** return a select statement that does the same thing as the original query passed to the constructor even if it looks slightly different.
     **/
    public String debugString() {
        return getArrayFilter()+" "+getArrayComparator()+" "+getArrayConverter();
    }
    
    /** Copy the array passed to the execute(...) method.  This is done so the original array is not sorted.  By default the original
     * array is sorted.
     */
    public void setCopyData(boolean copyData) {
        this.copyData=copyData;
    }
    
    /** Get the copy status for any array that will be passed to the execute(...) method.  */
    public boolean getCopyData() {
        return copyData;
    }
    
    private static void printDebugInfo(int debugCounter, String query, String[] header, Object[][] data) {
        FormattedDataSet fds=FormattedDataSet.createInstance();
        ArraySQL asql=null;
        for (int i=0;i<50;i++) {
            if (header==null)
                asql=new ArraySQL(query);
            else
                asql=new ArraySQL(header, query);
            
            asql.execute(data);
            
        }
        
        asql.log("\n\n\n**********************************************debugInfo for: "+debugCounter);
        asql.log("toString(): "+asql);
        asql.log("select: "+asql.getSelectCols());
        asql.log("where: "+asql.getWhereClause());
        asql.log("order by: "+asql.getOrderByClause());
        data=asql.convert(data);
        
        Map map=new HashMap();
        map.put("delimiter", " - ");
        asql.log("\nquery results:\n"+fds.getFormattedDataSet(null, data, map, "delimited"));
        asql.log("debugString() - arrayFilter + arrayComp: "+asql.debugString());
        int len=data==null ? 0 : data.length;
        asql.log("rows="+len);
    }
    
    private void log(String str) {
        Utils.log(str);
    }
    
    
    
    /** Test code for the ArraySQL class.  This is also good to look to learn some of ArraySQL's capabilities.   Use the view code button
     ** at the top of this file to view the code.
     **/
    public static void main(String[] args) {
        Object[][] data={
            {"jeff", new Date("12/22/2001"), new Integer(101), new Boolean(true),
             new Float("1.1"), new Character('a'),new Double("1.2"),new BigDecimal("1.3"),
             new BigInteger("102"), new Long("103"),new Short("104"),},
             
            {"mick", new Date("12/22/2002"),  new Integer(201), new Boolean(false),
             new Float("2.1"), new Character('b'),new Double("2.2"),new BigDecimal("2.3"),
             new BigInteger("202"), new Long("203"),new Short("204"),},
              
            {"iggy", new Date("12/22/2003"),  new Integer(301), new Boolean(true),
             new Float("3.1"), new Character('c'),new Double("3.2"),new BigDecimal("3.3"),
             new BigInteger("30200"), new Long("3030000"),new Short("30400"),},
               
            {"keith", new Date("12/22/2004"),  new Integer(401),new Boolean(false),
             new Float("4.1"), new Character('d'),new Double("4.2"),new BigDecimal("4.3"),
             new BigInteger("402"), new Long("403"),new Short("404"),},
                 
            {null, new Date("12/22/2005"), new Integer(501), new Boolean(true),
             new Float("5.1"), new Character('e'),new Double("5.2"),new BigDecimal("5.3"),
             new BigInteger("502"), new Long("503"),new Short("504"),},

             {"jim", new Date("12/22/2006"), new Integer(601), new Boolean(false),
             new Float("6.1"), new Character('f'),new Double("6.2"),new BigDecimal("6.3"),
             new BigInteger("602"), new Long("603"),new Short("604"),},
             
};
        
        String[] header={"string","date", "integer", "boolean", "float","character",
        "double","bigdecimal","biginteger", "long","short"};
      
        
        Monitor mon=MonitorFactory.start("ArraySQL.main()");
        
        printDebugInfo(1,"select * from array order by col0 asc, col1 desc", null, data);
        printDebugInfo(2,"select * from array where string<='alan' || string='mick' order by date desc", header, data);
        printDebugInfo(3,"select * from array where (date<='12/22/2000') || date='12/22/2004' order by date desc", header, data);
        printDebugInfo(4,"select * from array where float<=-.35 || float=3.1 order by float desc", header, data);
        printDebugInfo(5,"select string,boolean from array where boolean==true && string='iggy' order by string", header, data);
        printDebugInfo(50,"select string,boolean from array where boolean==true or string='iggy' order by string", header, data);
        printDebugInfo(6,"select string,boolean from array where string like 'j.*' ", header, data);
        printDebugInfo(7,"select * from array where (string ='jeff') ", header, data);
        printDebugInfo(8,"select * from array where character =='c' order by character ", header, data);
        printDebugInfo(9,"select string,double from array where double>=3.2 order by double desc ", header, data);
        printDebugInfo(10,"select string,bigdecimal from array where bigdecimal>=3.3 order by string", header, data);
        printDebugInfo(11,"select string,biginteger from array where biginteger<=5000 order by biginteger desc", header, data);
        printDebugInfo(12,"select string,long from array where long>=403 order by long desc", header, data);
        printDebugInfo(13,"select string, short from array where short>=400 order by short desc", header, data);
        printDebugInfo(14,"select string, short from array where  string='iggy'", header, data);
        printDebugInfo(15,"select string, short from array where  string=='iggy' || string=null", header, data);
        printDebugInfo(16,"select string, short from array where  date==null || string=   null  ", header, data);
        printDebugInfo(17,"select string, short from array where  string in ('iggy','jeff',null) order by string ", header, data);
        printDebugInfo(18,"select string, integer,date from array where  ((date in ('12/22/2003') || integer in ( 401 , 501 , 601    )) && integer not in (401)) order by integer ", header, data);
        printDebugInfo(19,"select string, integer,date from array where  col0='jones'", header, null);
        printDebugInfo(20,"select string, integer,date from array where  col0='jones'", header, data);
        printDebugInfo(21,"select string, integer,date from array where  col0 like '12'", header, data);
        printDebugInfo(22,"select rowNum(), rowNum(), 'steve', date(), col0 from array", header, data);
        printDebugInfo(23,"select *,rowNum(), rowNum(), 'steve', string, *,col0 from array", header, data);
        printDebugInfo(24,"select * from array where (short<=300 or long=503) and boolean=true", header, data);
        printDebugInfo(25,"select * from array where string in ('jeff', 'iggy') && boolean=true && date='12/22/2001' ", header, data);
        printDebugInfo(26,"select rowNum(),* from array where string in ('jeff', 'iggy') || boolean=false && date='12/22/2006' order by col0 asc", header, data);
        printDebugInfo(27,"select * from array where col0='iggy' or col0='iggy' and col2=9999 order by col0 asc, col1 desc", header, data);
        printDebugInfo(28,"select * from array where col0='iggy' or col0='iggy' and col2=9999 or col0='iggy' order by col0 asc, col1 desc", header, data);
        printDebugInfo(29,"select * from array where ((string='mick' or string='jeff') and (integer=101 or integer=201)) order by col0 asc, col1 desc", header, data);
        printDebugInfo(30,"select * from array where (((string='mick' or string='jeff' or string=null) or (integer=101 or integer=201 or integer=301))) order by integer", header, data);
        printDebugInfo(31,"select * from array where (((string='mick' or string='jeff') and (integer=401 or integer=501))) order by integer", header, data);
        printDebugInfo(32,"select * from array where (((string='mick' or string='jeff') or (integer=401 or integer=501))) order by integer", header, data);
        //printDebugInfo(33,"select * from array where string='select' or string='from' or string='where' or string='order by' or string='string' or string='col0' or string='jeff'", header, data);
        printDebugInfo(34,"select * from array where string='select' or string='from' or string='where' or string='string' or string='col0' or string='jeff'", header, data);
        printDebugInfo(35,"select rowNum(), * from array order by col0 desc", header, data);
        
        mon.stop();

        data=MonitorFactory.getRootMonitor().getData();
        printDebugInfo(100,"select * from array", null, copy(data));
        

        
    }
    
}
