/*
 * Column.java
 *
 * Created on September 7, 2004, 4:36 PM
 */

package com.fdsapi.arrays;

/**
 * <p>Interface for columns that occur in a select statement.  For example:  select col0, 'souza', rownum(), date() from array.
 * Everything between 'select' and 'from array' are backed by ojbects that implement the Column interface.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/Column.htm">View Code</a>
 */
public interface Column {
    public Object getObject(Object[] row);
    public Column createInstance();
    
}
