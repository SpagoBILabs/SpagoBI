/*
 * ColumnData.java
 *
 * Created on September 7, 2004, 4:38 PM
 */

package com.fdsapi.arrays;

/**
 *  <p>An implementation of the Column interface that displays a particular column from the array as part of the select clause.
 *  It is invoked for col0, col1, and mycolname in the following example:  
 *  select date(), rownum(), col0, col1, mycolname from array</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ColumnData.htm">View Code</a>
 */
public class ColumnData implements Column {
    
    private int columnNumber;
    /** Creates a new instance of ColumnData */
    
    public ColumnData(int columnNumber) {
        this.columnNumber=columnNumber;
    }
    
    public Object getObject(Object[] row) {
        return row[columnNumber];
    }
    
    public Column createInstance() {
        return new ColumnData(columnNumber);
    }
    
}
