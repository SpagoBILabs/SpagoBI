/*
 * ColumnDate.java
 *
 * Created on September 7, 2004, 5:43 PM
 */

package com.fdsapi.arrays;

import java.util.*;
/**
 * <p>An implementation of the Column interface that displays the current date as part of the select clause.
 *  It is invoked for date() in the following example. It is not case sensitive, however there can be no spaces
 *  surrounding or in the parens (i.e. date(), DATE() are valid but date ( ) and date( ) are not:  
 *  select date(), rownum(), col0, col1, mycolname, 'souza' from array</p>
 *
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ColumnDate.htm">View Code</a>
 */
public class ColumnDate implements Column {
    
   
    /** Creates a new instance of ColumnDate */
    public ColumnDate() {
    }
    
    /** A factory method */
    public Column createInstance() {
        return this;
    }
    
    /** Returns the current date */
    public Object getObject(Object[] row) {
        return new Date();
    }
    
    
}
