/*
 * ColumnFunctionFactory.java
 *
 * Created on September 7, 2004, 5:00 PM
 */


package com.fdsapi.arrays;


import java.util.*;
import com.fdsapi.*;
import com.jamonapi.utils.*;

/**
 * <p>A factory that is in charge of creating Column objects.</p>
 *
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ColumnFunctionFactory.htm">View Code</a>

 */
public class ColumnFunctionFactory {
    
    private Map factoryMap=AppMap.createInstance();
    
    /** Creates a new instance of ColumnFunctionFactory */
    public ColumnFunctionFactory() {
        putFunction("rowNum()", new ColumnRowNum());
        putFunction("date()", new ColumnDate());
    }
    
    /** Passing in a certain name return the associated object that implements the Column interface */
    public  Column getFunction(String functionName) {
        
        if (factoryMap.containsKey(functionName)) {
          Column col = (Column) factoryMap.get(functionName);
          return col.createInstance();
        }
        else {  // check to see if this is  a string of the format:  'souza' or "souza"
            String str=Utils.getREMatch("'(.*)'",functionName,1);
            if (str==null)
              str=Utils.getREMatch("\"(.*)\"",functionName,1);
            
            if (str==null)
              throw new IllegalArgumentException("The passed function name is invalid.  It is not in the ColumnFunctionFactory.  The function is:  "+functionName);
            else 
              return new ColumnString(str);
                
        }
            
        
    }
    
    /** Add a function that implements the Column interface to the function factory */
    public  void putFunction(String functionName, Column col) {
       factoryMap.put(functionName, col);
        
    }
    
    // note as this stands it is a little ugly as there is no easy way for others to check
    // into the functions factory.
    protected String getFunctionREString() {
        return "'.*'|\".*\"|rowNum[(][)]|date[(][)]";
        
    }
    
}
