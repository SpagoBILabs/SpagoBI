/*
 * ColumnRowNum.java
 *
 * Created on September 7, 2004, 5:38 PM
 */

package com.fdsapi.arrays;

/**
 * <p>An implementation of the Column interface that displays the current rownumber as part of the select clause.
 *  It is invoked for rownum() in the following example. It is not case sensitive, however there can be no spaces
 *  surrounding or in the parens (i.e. rowNum(), rowNUM() are valid but rowNum ( ) and rowNum( ) are not:  
 *  select date(), rownum(), col0, col1, mycolname, 'souza' from array</p>
 *
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ColumnRowNum.htm">View Code</a>

 */
public class ColumnRowNum implements Column {
    
    /** Creates a new instance of ColumnRowNum */
    private int rowNum=1;;
    public ColumnRowNum() {
    }
    
    public Column createInstance() {
        return new ColumnRowNum();
    }
    
    /** Return the current rownumber for the row in the array */
    public Object getObject(Object[] row) {
        return new Integer(rowNum++);
    }
    
}
