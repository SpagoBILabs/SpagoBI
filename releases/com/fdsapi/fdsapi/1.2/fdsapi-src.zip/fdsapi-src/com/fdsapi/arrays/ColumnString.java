/*
 * ColumnString.java
 *
 * Created on September 7, 2004, 5:26 PM
 */

package com.fdsapi.arrays;

/**
 * <p>An implementation of the Column interface that displays a string constant as part of the select clause.
 *  It is invoked for 'souza' in the following example. Double quotes may also be used to delimit the String.:  
 *  select date(), rownum(), col0, col1, mycolname, "steve", 'souza' from array</p>
 *
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ColumnString.htm">View Code</a>

 */
public class ColumnString implements Column {
    
    private String stringConst;
    /** Creates a new instance of ColumnString */
    public ColumnString(String stringConst) {
        this.stringConst=stringConst;
    }
    
    public Column createInstance() {
       return this;
    }
    
    /** Return the objects associated String */
    public Object getObject(Object[] row) {
        return stringConst;
    }
    
}
