
package com.fdsapi.arrays;

/** 
 * Interface for conditional logic.  Conditionals are analagous to each conditional in a SQL select 'where clause'.  For
 * example lname='souza'.  Conditionals return true or false. The Conditional's isTrue(...) method is passed a row 
 * of a 2 dimensional array and the method returns true if the row should be kept.  
 * 
 * <p>Conditionals are similar to a where clause in a select statement.  i.e. where col1=5.  In this
 * case the isTrue method would compare column1 to the value 5.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/Conditional.htm">View Code</a>
 */
public interface Conditional {
   /** Pass in one row of an Object[][] array and the implementation of isTrue(...) returns true if the
    * row should be kept and false otherwise
    */
   public boolean isTrue(Object[] row);
   
   /** This method returns information about what action/type the conditional takes.  Examples are 
    * <,>,=, like and not like
    */
   public String getType();

}
