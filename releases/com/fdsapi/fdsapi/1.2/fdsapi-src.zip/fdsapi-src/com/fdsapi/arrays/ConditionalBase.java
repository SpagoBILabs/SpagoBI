

package com.fdsapi.arrays;

import java.util.*;
/**  <p>Abstract base class for other Conditional objects.  This interface is used in where clauses to 
 *   return true if the row in the array should be kept in the resulting array.</p>
 *
 ** <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalBase.htm">View Code</a>
 */
public abstract class ConditionalBase implements Conditional {

      /** Column number to be used in the comparsison */
      protected int col;
      /** Null object that ends the decorator chain.  This allows their not to have to be any special 
       * logic at the end of the decorator chain.
       */
      private static NullConditional nullConditional=new NullConditional();
      
      /** The next conditional in the chain using the Decorator pattern.  This allows Conditionals to
       * be combined.  For example <= can be created by combining the < and = conditionals in the following
       * manner:  new ConditionalLessThan(new ConditionalEquals(...))
       */
      private Conditional nextConditional=nullConditional;
      
 
      /** Contructor that takes the column to be compared as well as the next conditional in the decorator
       * chain.
       */
       public ConditionalBase(int col,  Conditional nextConditional) {
          this.col=col;
          this.nextConditional=nextConditional;
       }      
       
       /** A Constructor that takes the column to be compared in the decorator */
       public ConditionalBase(int col) {
            this.col=col;
       }
    
       /** This method implements the Template design pattern.  It takes the row as input and
        *  calls this classes logic as well as the next Conditional in the decorator chains isTrue(...)
        *  method.  Any class that inherits from this one must implement the isTrueThis(...) method 
        *  to determine if the passed in row should be kept.
        */
       public boolean isTrue(Object[] row) {
          return isTrueThis(row) || nextConditional.isTrue(row);
          
      }
      
      /**
       * This method must be implemented in child classes to specify if the row matches the 
       * comparison value
       */
      abstract protected boolean isTrueThis(Object[] row);
      
      /** This method gets the next Conditional object in the decorator chain */
      protected Conditional getNextConditional() {
          return nextConditional;
      }
      
      /**
       * Display a String representation of this Conditional.
       */
      protected String getConditionalString(Object comparisonValue) {
          return "col"+col+getType()+getNextConditional().getType()+comparisonValue;
      }
    
}

