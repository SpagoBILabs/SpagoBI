
package com.fdsapi.arrays;

import java.util.*;

/**
 * This is the base class for any Conditional that implements the Comparator interface.  Examples
 * are &lt;, and &gt; Conditionals.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalBaseComparator.htm">View Code</a>
 *
 */

public abstract class ConditionalBaseComparator extends ConditionalBase implements  Comparator {
   
      /** Object that the column value will be compared against. */
      protected Comparable comparisonValue;
 
      /** Constructor that takes the column to compare as well as a Comparable object that it will
       * be compared against.
       */
      public ConditionalBaseComparator(int col, Comparable comparisonValue) {
        super(col);
        this.comparisonValue=comparisonValue;
       }
       
      /** Constructor that takes the column to compare as well as a Comparable object that it will
       * be compared against, and the next conditional in the decorator chain.
       */
      public ConditionalBaseComparator(int col, Comparable comparisonValue, Conditional nextConditional) {
          super(col, nextConditional);
          this.comparisonValue=comparisonValue;
       }      

      /** String representation of this Object */
      public String toString() {
         return getConditionalString(comparisonValue);
      }
        
      
}
