

package com.fdsapi.arrays;

/** This interface is the starting point for the implementation of the Composite design pattern.
 * The composite will contain other Conditionals (possibly even other ConditionalComposites).  For example col1=4 && (col2 like .jsp and col3!=true)
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalComposite.htm">View Code</a>
 */
public interface ConditionalComposite extends Conditional {
   
   /** Returns true if the row passed in should be kept */
   public boolean isTrue(Object[] row);
   /** Add another Conditional to the composite.  This could be another ConditionalComposite.*/
   public void addConditional(Conditional conditional);
   /** negate the isTrue(...) method */
   public void addNot();
   /** add an and between two Conditionals */
//   public void addAnd();
   /** add an or between two Conitionals */
//   public void addOr();
   
}
