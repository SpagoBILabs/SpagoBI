
package com.fdsapi.arrays;

import java.util.*;
import com.fdsapi.*;


/**
 * This class is used to build the ArrayFilter and ArraySQL classes (ArraySQL is simply backed by ArrayFilter).  This class validates
 * the given sql.   This class does not need to be used directly by developers.
 * 
 * All classes that implement the ConditionalComposite interface implement the ConditionalComposite design
 * pattern.
 *
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalCompositeContainer.htm">View Code</a>
 *
 */

public class ConditionalCompositeContainer implements ConditionalComposite {
    
      /* root in chain of composites */
      private ConditionalComposite rootComposite=null;
      /** The current/active composite that commands like addConditional, and addAnd take action on */
      /** stack - push(), pop() data structure */
      private FDSStack compositeStack=new FDSStack(); 
      private WhereClauseTokens whereClauseTokens=new WhereClauseTokens();
      private boolean shouldValidate=true;  // indicates if the sql/filter should be validated
      private boolean shouldBuild=true;  // indicates if the sql/filter should be built.  it only needs to be built the first time 

  
     
      // All conditionalCompositeContainers have an 'OR' composite as their root monitor.
       public ConditionalCompositeContainer() {
           this(new ConditionalCompositeImp("or"));
       }
       
       /** Contructor that takes an explicit ConditionalComposite (typically ConditionalCompositeOr)
        * as the root (i.e. first composite) in the chain.
        */
       public ConditionalCompositeContainer(ConditionalComposite rootComposite) {
           setRootComposite(rootComposite);
           setCurrentComposite(rootComposite);
       }
       
       
       
       /** This method is called to convert ArrayFilter calls such as addConditional that build the object structure that implements
        * ArrayFilter.  It uses a WhereClauseTokens object to get a list of instructions that aid in building the backing structure. 
        * This was done so testing was easier.
        */
       
       public void build() {
         if (shouldBuild) {
           Object[][] createData=getCreateData(); // get commands used to build object Structure.
           int rows=(createData==null) ?  0 : createData.length;
           ConditionalComposite prevComp=null; // used to add a composite to another one.
           Conditional prevCond=null; // conditionals are added in the token after they are encountered.  This variable holds the conditional
           
           for (int i=0;i<rows;i++) {
              //System.out.println(WhereClauseTokens.getRowString(createData, i));
              BuildHelper helper=new BuildHelper(createData[i], prevComp, prevCond);
              helper.add();
              prevComp=helper.getPrevCondComposite();
              prevCond=helper.getConditional();
           }
          
           resetStack();
           shouldBuild=false;
        }
           
       }
       
        
       /** This method calls the root composites isTrue(...) method and it in turn calls all Conditionals that 
        * are contained's isTrue(...) methods.  This allows each Conditional to vote whether the row should be kept.  Any 
        * Conditional that votes false can cause the row to be rejected.  
        */
        public boolean isTrue(Object[] row) {
              return getRootComposite().isTrue(row);
        } 
        
        
        /** Method that validates the syntax of the ArraySQL or ArrayFilter method calls.  It will throw
         * a RuntimeException if there is an error such as unmatched parens
         */
        public void validate() {
            if (shouldValidate) {
              whereClauseTokens.validate();
              shouldValidate=false;
            }
        }
        
        /** If the state of this object changes such as by calling addConditional this method
         * sets variables that cause the object to be validated, and build again.
         */
        private void resetBuildAndValidate() {
            shouldBuild=true;
            shouldValidate=true;
        }


        /** Add a Conditional to the currently active ConditionalComposite.  The active Composite is based on the current 
         * paren level.
         */ 
        public void addConditional(Conditional conditional) {
            whereClauseTokens.addConditional(conditional);
            resetBuildAndValidate();
        }
        
        /** This adds the ConditionalComposite to the chain AND makes it the active ConditionalComposite to 
         ** which all subsequent Conditionals are added to until the paren level changes.
         **/
        public void addConditionalComposite(ConditionalComposite comp) {
            whereClauseTokens.addConditional(comp);
            resetBuildAndValidate();
        }
        
      
        /** Add a left paren to group Conditionals together.  The implementation of this mehtod is to create
         ** a ConditionalCompositeOr object and make it the active ConditionalComposite that all subsequent 
         ** Conditionals are added to until the right paren is added.  Then the previous ConditionalComposite
         ** will become active.
         **/
        public void addLeftParen() {
            whereClauseTokens.addLeftParen();
            resetBuildAndValidate();
        }

        /** Add a right paren to end the current grouping of Conditionals together.  The implementation of 
         ** Then the previous ConditionalComposite becomes active.
         */
        public void addRightParen() {
            whereClauseTokens.addRightParen();
            resetBuildAndValidate();
        }  
   
        /** Negate the value of the active ConditionalComposite */
        public void addNot() {
            whereClauseTokens.addNot();
            resetBuildAndValidate();
        }
        
        /** Add a logical "and" between Conditionals in the active ConditionalComposite */
        public void addAnd() {
            whereClauseTokens.addAnd();
            resetBuildAndValidate();
         }
        
        /** Add a logical "or" between Conditionals in the active ConditionalComposite */
        public void addOr() {
            whereClauseTokens.addOr();
            resetBuildAndValidate();
        }
      
       
        
        /* This method is used simply to clarify the codes intent.  It is the method that makes a ConditionalComposite active.  
         * push() is the implementation.
         **/
        private void setCurrentComposite(ConditionalComposite comp) {
            push(comp);
        }

        /** Get the current ConditionalComposite */
        private ConditionalComposite getCurrentComposite() {
            return (ConditionalComposite) compositeStack.getCurrent();
        }
        
        
        
        /** Set the first Composite in the chain.  This should only be called at Object creation */
        private void setRootComposite(ConditionalComposite comp) {
            rootComposite=comp;
        }
        
        /** Get the first ConditionalComposite in the chain */
        private ConditionalComposite getRootComposite() {
            return rootComposite;
        }
        
        
        
        /** Used to help managed the paren levels. It pushes to a stack */
        private void push(ConditionalComposite comp){
            compositeStack.push(comp);
        }
        
        /** Used to help manage paren levels.  It pops from a stack */
        private ConditionalComposite pop() {
            return (ConditionalComposite) compositeStack.pop();
        }
        

        /** This method gets a list of commands that are used to create the underlying Object
         * structure that implements ArrayFilter.
         */
        private Object[][] getCreateData() {
            return whereClauseTokens.getCreateData();
        }
        
        /** reset composite stack */
        private void resetStack() {
         compositeStack.reset(); 
        }
       
        /** Empty implementation */
        public String getType() {
            return "";
        }
        
        /** Display  a string representation of all Conditionals owned by this ConditionalComposite */
        public String toString() {
            return whereClauseTokens.toString();
        }

        //****Start inner class BuildHelper
        // Builder helper takes the WhereClauseTokens array of commands and executes them, thereby
        // building the underlying object structure that implements ArrayFilter.   It is tightly coupled
        // with the WhereClauseTokens class (maybe too tightly coupled :))
        private class BuildHelper {
            private String create;
            private String conditionalToAdd;
            private String compositeToAdd;
            private String compositeStackAction;
            private String lastToken;
            private WhereClauseToken token;
            private ConditionalComposite prevComp;
            private Conditional prevCond;
            
            public BuildHelper(Object[] buildData,  ConditionalComposite prevComp, Conditional prevCond) {
                token=(WhereClauseToken) buildData[0];
                create=(String) buildData[1];
                conditionalToAdd=(String) buildData[2];
                compositeToAdd=(String) buildData[3];
                compositeStackAction=(String) buildData[4];
                lastToken=(String) buildData[5];
                this.prevComp=prevComp;
                this.prevCond=prevCond;
            }
            
           private boolean isConditional() {
               return token.isConditional();
           }
           
           private boolean isRightParen() {
               return token.isRightParen();
           }
           
           private boolean isLastToken() {
               return "lastToken".equalsIgnoreCase(lastToken);
           }
           
           private boolean shouldCreateAndComposite() {
               return "createAndComposite".equalsIgnoreCase(create);
           }
           
           private boolean shouldCreateOrComposite() {
               return "createOrComposite".equalsIgnoreCase(create);
           }
           

           private boolean shouldAddConditional() {
               return "addConditional".equalsIgnoreCase(conditionalToAdd);
           }

           private boolean shouldAddComposite() {
               return "addComposite".equalsIgnoreCase(compositeToAdd);
           }

           private boolean shouldPop() {
              return compositeStackAction.startsWith("pop");
           }
           
           private void popNTimes() {
               // a string will be of the format pop2, or pop1 and the following code
               // will pop the stack that many times.
               int n=Integer.parseInt(compositeStackAction.substring(3));

               // (c1 or c2) - pop1 i.e. n==1.  we need to have this composite be added when 
               // and this paren composite is around when it is needed.
               // (c1 and c2) - you pop twice.  the first pop gives you back the paren composite.  this
               // is what needs to be added.  So the logic below takes care of both cases
               for (int i=0;i<n;i++) {
                   if (token.isRightParen()) {
                     prevComp=getCurrentComposite();
                   }
                     
                   pop();
               }

           }
           
           
           private void addConditional(Conditional conditional) {
                getCurrentComposite().addConditional(conditional);
           }
           
           public Conditional getConditional() {
               return token.getConditional();
           }
           
           public ConditionalComposite getPrevCondComposite() {
               return prevComp;
           }
           
           private Conditional getConditionalToAdd() {
               // prevCond can be null if the where clause has one entry or for the last entry.
               // i.e. where col1=7
               // i.e. where col1=7 or col2=9  (the last column)
               return (prevCond==null) ? getConditional() : prevCond;
           }
           
           
           
           /* Method that does the core building of the ArrayFilter class */
           public void add() {
               // create the And Composite object and make it the current composite.
               // i.e. col0=1 and col1=2 (when 'and is encountered the following code
               // would be executed)
               if (shouldCreateAndComposite()) {
                 ConditionalComposite condComposite=new ConditionalCompositeImp("and");
                 addConditional(condComposite);
                 setCurrentComposite(condComposite);
               }
               
               
               // Done when a left paren in encountered:  where (col0=1 or col1=5)
               if (shouldCreateOrComposite()) {
                 ConditionalComposite condComposite=new ConditionalCompositeImp("or");
                 setCurrentComposite(condComposite);
               }
               
               // if appropriate add a conditional to the current composite.  This usually happens 
               // when an operator is encountered.  In the following case col0-3 is added when the 'and'
               // token is encountered: col0=3 and col12 
               if (shouldAddConditional()) {
                 addConditional(getConditionalToAdd());
               }
               
               // If appropriate add the previous composite to the active.  This happens with paren levels
               // such as:  (col0=3 or col1=2) or col3=1
               if (shouldAddComposite()) {
                 addConditional(getPrevCondComposite());
               }

               // usually you pop composites due to paren levels being exited.
               if (shouldPop()) {
                   popNTimes();
               }
               
               // when the last token is a paren you have to make sure it is added to the outermost
               // composite.  i.e. where (col0=1)
               if (isLastToken() && isRightParen())
                 addConditional(getPrevCondComposite());
                 

               
    }  //****End inner class BuildHelper

           
           
           
}

        
        

}
