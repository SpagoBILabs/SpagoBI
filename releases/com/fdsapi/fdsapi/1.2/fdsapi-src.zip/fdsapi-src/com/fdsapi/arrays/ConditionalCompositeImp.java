
package com.fdsapi.arrays;

import java.util.*;

/** Used for grouping conditionals in the ArraySQL and ArrayFilter classes.  This composite 
 * can correspond to a paren level/or condition, or an and condition.   As this class implements
 * the composite design pattern it can also contain itself.   Here are some examples.  
 * 
 * <p>select * from array where col0='steve' and col1='souza' - creates 2 composites.  One for the 
 *   root holder of the where clause and the other for the and clause</p>
 *
 * <p>select * from array where col0='steve' and col1='souza' or col1='jones' - same as above</p>
 *
 * <p>select * from array where (col0='steve' and col1='souza' or col1='jones') - 3 composites.  the root
   composite, the paren level (an or is created), and the and composite.</p>
 *
 * * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalCompositeImp.htm">View Code</a>

 */
public class ConditionalCompositeImp implements ConditionalComposite {
    
    private List conditionals=new ArrayList();
    private boolean negateReturn=false;
    private boolean isAnd;
    private boolean isOr;

    /** Creates a new instance of ConditionalCompositeImp */
    public ConditionalCompositeImp(String type) {
        if ("and".equalsIgnoreCase(type)) {
          isAnd=true;
          isOr=false;
        }  else {
          isAnd=false;
          isOr=true;
        }
    }
        
        public boolean isTrue(Object[] row) {
            Iterator conditionalsIter=conditionals.iterator(); // ex. col1='Java'
            boolean returnBool=true;
            boolean firstLoop=true;
            
            // loop through this composites conditionals
            // or - loops until a conditional is true or there are no more conditionals (short circuit on true)
            // and - loops until a conditional is false or there are no more conditionals (short circuit on false)
            while (conditionalsIter.hasNext()) {  
               // set the returnBool for when the all their is no true condition. i.e. no short circuit
               if (firstLoop && isOr) {  // if no short circuit or should return false
                 firstLoop=false;
                 returnBool=false;
               } else if (firstLoop && isAnd) {  // if no short circuit and returns true;
                 firstLoop=false;
                 returnBool=true;
               }
               
               Conditional conditional=(Conditional) conditionalsIter.next(); // get next conditional check
               boolean currentBool=conditional.isTrue(row); // determine if this check is true.
               if (currentBool==true && isOr) {  // short circuit 'or' if one condition is true
                 returnBool=true;   
                 break;
               } else if (currentBool==false && isAnd) {  // short circuit 'and' if one condition is false.
                 returnBool=false;
                 break;
               }
         
            }
            
            return negateIfNeeded(returnBool);
        } 
        
        /** Add a conditional to the Composite.  after addConditional() is called then either
         * the Composite must be evaluated or addAnd(), or addOr() must be called.
         *
         * Sample:  composite.addConditional(new ConditionalEquals(2,"steve"));
         */
        public void addConditional(Conditional conditional) {
       //   if (logicalOperatorValid)
       //      throw new FDSArraysRuntimeException("Conditional Syntax violation:  addConditional() was called back to back.  A call to addAnd(), or addOr() is required.");
       //   else
       //      logicalOperatorValid=true;
         
          conditionals.add(conditional);
        
        }

        
        // if addNot was called the return value needs to be negated.
        private boolean negateIfNeeded(boolean value) {
            return (negateReturn==true) ? !value : value;
        }
        
        /** Negate the boolean return status of the entire composite.  i.e. if the composite is true then
         ** this method would change that to false and vice versa
         **/
        public void addNot() {
            negateReturn=true;
            
        }


        /** Returns the empty string */
        public String getType() {
            return "";
        }
        
        /** String representation of all Conditionals in the Composite */
        /*
        public String toString() {
           
            Iterator conditionalsIter=conditionals.iterator(); // ex. col1='Java'
            Iterator andOrIter=(logicalOperators.size()==0) ? null : logicalOperators.iterator(); // ex. and
            boolean firstLoop=true;
            String conditionalStr="";
   
            // loop through Conditionals to build a String representation of what it will look like.
            // examples:
            // (col1 like john and 
            while (conditionalsIter.hasNext()) {  // loop while more conditional checks
                Conditional conditional=(Conditional) conditionalsIter.next(); // get next conditional check
                conditionalStr+=" "+conditional+" ";
                
                if (andOrIter!=null && andOrIter.hasNext()) {
                  String value=(String) andOrIter.next();
                  conditionalStr+=value;
                }
         
            }
            
            String negateStr= negateReturn ? " !" : "";
            return negateStr+"("+conditionalStr+")";
        }*/
      

    
}
