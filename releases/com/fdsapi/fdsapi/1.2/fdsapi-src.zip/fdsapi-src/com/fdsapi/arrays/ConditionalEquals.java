

package com.fdsapi.arrays;

import java.util.*;

/** Conditional object that tests equality of objects.  i.e. col1=7 or col2=Steve
 *  It simply calls the columns equals method against the comparison value passed
 * into the contructor.   If both column and comparison values are null the Conditional 
 * returns true, but if only one of them is null the Conditional returns false.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalEquals.htm">View Code</a>
 */
public class ConditionalEquals  extends ConditionalBase {
   
      /** Object to compare for equality against the column */
      private Object comparisonValue=null;
      
      /** Constructor that takes the col number that should be compared and the Object that the 
       * column should be Compared against.  Note the column equals method must be able to take ComparisonValue's
       * Object type.
       **/
      public ConditionalEquals(int col, Object comparisonValue) {
         super(col);
         this.comparisonValue=comparisonValue;
       }
      
      /** Constructor that takes the col number that should be compared and the Object that the 
       * column should be Compared against, as well as the next Conditional in the decorator chaing.  
       * Note the column equals method must be able to take ComparisonValue's Object type.
       **/
      public ConditionalEquals(int col, Object comparisonValue, Conditional nextConditional) {
         super(col,  nextConditional);
         this.comparisonValue=comparisonValue;
      }     
      
   /** Overridden method that determines if the column to be compared and the Comparison value match by calling
    ** the columns equal method against the comparison value.  equals is called on the comparison value, not the
    ** row value as this approach is more flexible.
    */     
   protected boolean isTrueThis(Object[] row) {
     return isEqual(row[col], comparisonValue);
   }
   
   static boolean isEqual(Object colValue, Object compValue) {
     // Note the following if condition ensures that nulls may be in the array.  
     if (colValue==null && compValue==null) // 2 nulls are considered equal
       return true;
     else if (colValue==null) // if only the column value is null then it is less than the comparison value
       return false;
     else if (compValue==null)// if only the comparison value is null then it is less than the column value
       return false;
     else 
       return compValue.equals(colValue);
       
   }
    

   /** Returns '=' which is used to make a String representation of this Conditional */
   public String getType() {
       return "=";
   }
    
   /** Make a String representation of this Conditional */
   public String toString() {
       return getConditionalString(comparisonValue);
   }
   
 }


