

package com.fdsapi.arrays;

import java.util.*;

/**
 * A Factory design pattern that creates the various Conditional classes that test for =,<,>, != and more.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalFactory.htm">View Code</a>
 */
public class ConditionalFactory {
    
      /** Some objects such as Boolean() do not implement the Comparator interface and so equals comparisons
      * could not be called, so when an Object that doesn't implement Comparator is passed with a type of =, or
      * == this method was created.  Any other argument such as <, >, <= doesn't make sense unless the Comparator is 
      * implemented however, and so a RuntimeException is thrown in this case.
      * 
      * Serveral Conditionals are created with by chaining Conditionals together with the decorator pattern.  For example
      * any not Conditional such as "!=" and "not like" simply decorates the underlying Conditional with the 
      * NegateCondtional object.
      **/
       
   public static Conditional createInstance(int col, String type, Object comparisonValue) {
         Conditional cond=null;
         // If <,<=,>,>= are used then the comparisonValue MUST be a Comparator.
         if (   ("<".equals(type) || "<=".equals(type) || ">".equals(type) || ">=".equals(type)) &&
                comparisonValue!=null &&
                !(comparisonValue instanceof Comparable) 
            ) 
             throw new IllegalArgumentException("The passed comparisonValue ("+comparisonValue.getClass().getName()+") must implement the Comparator interface if the following type argument is used: '"+type+"'");
         else if ( ("in".equalsIgnoreCase(type)||"not in".equalsIgnoreCase(type)) && 
                   !(comparisonValue instanceof Object[] )
                 ) 
             throw new IllegalArgumentException("An Object[] array is required for 'in' or 'not in' ("+comparisonValue.getClass().getName()+")");
             
          
         
          if ("=".equals(type))
            cond = new ConditionalEquals(col, comparisonValue);
          else if ("==".equals(type))
            cond = new ConditionalEquals(col, comparisonValue);
          else if ("<".equals(type))
            cond = new ConditionalLessThan(col, (Comparable) comparisonValue);
          else if (">".equals(type))
            cond = new ConditionalGreaterThan(col, (Comparable) comparisonValue);
          else if ("<=".equals(type))
            cond = new ConditionalLessThan(col, (Comparable) comparisonValue, new ConditionalEquals(col, comparisonValue));
          else if (">=".equals(type))
            cond = new ConditionalGreaterThan(col, (Comparable) comparisonValue, new ConditionalEquals(col, comparisonValue));
          else if ("<>".equals(type))
            cond = new NegateConditional(new ConditionalEquals(col, comparisonValue));
          else if ("!=".equals(type))
            cond = new NegateConditional(new ConditionalEquals(col, comparisonValue));
          else if ("like".equalsIgnoreCase(type))
            cond = new ConditionalRE(col, comparisonValue);
          else if ("not like".equalsIgnoreCase(type))
            cond = new NegateConditional(new ConditionalRE(col, comparisonValue));
          else if ("!like".equalsIgnoreCase(type))
            cond = new NegateConditional(new ConditionalRE(col, comparisonValue));
          else if ("in".equalsIgnoreCase(type))
            cond = new ConditionalIn(col, (Object[])comparisonValue, false);
          else if ("not in".equalsIgnoreCase(type))
            cond = new ConditionalIn(col, (Object[])comparisonValue, true);
          else 
            throw new IllegalArgumentException("The following Conditional type does not exist: "+type);
          
          return cond;
        }
   
      
   

 

}


