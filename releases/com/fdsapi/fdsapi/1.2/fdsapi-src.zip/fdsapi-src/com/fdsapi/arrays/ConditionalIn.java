/*
 * ConditionalIn.java
 *
 * Created on June 13, 2004, 11:04 PM
 */

package com.fdsapi.arrays;

/**
 *  Similar to the 'in clause' within a SQL select statement.  For example:  select * from table where lname in ('souza','johnson','jones')
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalIn.htm">View Code</a>
 */
public class ConditionalIn implements Conditional {
    
    private int col=0;
    private Object[] compArray;
    private boolean isNegated=false;
    
    public ConditionalIn(int col, Object[] compArray, boolean negate) {
        this(col,compArray);
        this.isNegated=negate;
    }
    
    public ConditionalIn(int col, Object[] compArray) {
          if (compArray==null) 
             throw new IllegalArgumentException("The array to compare against may not be null");
          else if (col<0)
             throw new IllegalArgumentException("The column to compare against must be greater than 0.  It was "+col);
              
          this.col=col;
          this.compArray=compArray;
    }
    
    public String getType() {
        return isNegated ? "not in" : "in";
    } 
    
    public boolean isTrue(Object[] row) {
        Object cell=row[col];
        boolean match=false;
        for (int i=0; i<compArray.length; i++) {
            if (ConditionalEquals.isEqual(cell, compArray[i])) {
                match=true;
                break;
            }
        }
        
        return negate(match);
    }
    
    private boolean negate(boolean bool) {
        return isNegated ? !bool : bool;
    }
    
    public String toString() {
      String str="col"+col+" "+getType()+" (";  
      int lastIndex=compArray.length-1;
    
      // loop through comparison array building something like 'in (2,3,4)'
      for (int i=0; i<=lastIndex; i++) {
            if (i==lastIndex)
              str+=compArray[i];
            else
              str+=compArray[i]+",";
        }
      
      return str+")";
    }
    
}
