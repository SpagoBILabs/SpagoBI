

package com.fdsapi.arrays;


/** Conditional used to test to see if a column value is less than value to compare it against.  The 
 ** column value must be of type Comparable.
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalLessThan.htm">View Code</a>
 **/
public class ConditionalLessThan extends ConditionalBaseComparator {

     /** Pass in the column to compare nad the value that it will be compared against. */
     public ConditionalLessThan(int col, Comparable comparisonValue) {
          super(col, comparisonValue);
    }
    
    /** Pass in the column to compare the value that it will compare against and the next Condtional
     * in the decorator chain.
     */
     public ConditionalLessThan(int col, Comparable comparisonValue, Conditional nextConditional) {
          super(col, comparisonValue, nextConditional);
    }      
    
     /** Returns true if the column value is less than the comparison value.  
      * If both column value and comparison value are null then the method 
      * returns false else if either is null return false.
      */      
    protected boolean isTrueThis(Object[] row) {
           return compare(row[col], comparisonValue)<0;
    }
       
       /**
 * Method used by the comparator interface. <br><br>
 *   o1 &lt; o2 - returns a negative integer<br>
 *   o1==o2 - returns zero<br>
 *   o1&gt;o2 - returns a postitive integer<br><br>
 *  Iterate through all columns that should be compared (in the proper order) 
 *  and call the Comparator for each of the column elements.
 * Note the column value is always the first argument and the comparison value is always the second
 */
    public int compare(Object colValue, Object compValue) {
     Comparable comparable=null;

     // Note the following if condition ensures that nulls may be in the array.  
     if (colValue==null && compValue==null) // 2 nulls are considered equal
       return 0;
     // if either other value is null then we don't want this to return less 
     // (i.e. true for this conditional) so return 1 (greater than)
     else if (colValue==null) 
         return 1;
     else if (compValue==null)
       return 1;
     else {
     // Note I am using the passed in value as the Comparable type as this seems more flexible.  For example
     // You may not have control over the array values, but you do over what comparable value you pass in, but being
     // as the comparison is really asking if the col value is less than the comparison value I am taking the negative
     // value.  The compareTo() test is really asking if the compValue is less than the colValue so flipping it with a
     // negative gives us the right answer.
       comparable = (Comparable) compValue;
       return -(comparable.compareTo(colValue));
     }
     
}

    /** Used to help create a String represenation of this Conditional.  Returns "<" */
   public String getType() {
       return "<";
   }
    

    
}
