/*
 * ConditionalParser.java
 *
 * Created on July 25, 2004, 10:44 AM
 */

package com.fdsapi.arrays;

import java.util.Date;
import java.math.*;
import com.fdsapi.*;
/**
 * <p>This class parses individual where clauses within the where clauses such as 'where col0='steve' && lname in ('souza'). See 
 *  the main method for examples.  It is used by ArraySQL.</p>
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalParser.htm">View Code</a>

 */
public class ConditionalParser {
    
    // col1='souza'
    private String left=null; //col1
    private String operator=null;//=
    private String right=null;//'souza'
    private RegularExpression reCol=new RegularExpression("col([0-9]*)");
    // regular expression to get col1,<>, and 'souza' out of col1 <> 'ssouza'.  used to call arrayFilter.addConditional()
    private RegularExpression reConditional=new RegularExpression("([a-zA-Z_0-9]+) *(==|<=|>=|<>|=|<|>|!=| like | not like | !like | in| not in) *(.*)");
    private ArrayFilter arrayFilter;
    private Object[][] data;
      
     public ConditionalParser(Object[][] data, ArrayFilter arrayFilter)  {
         this.data=data;
         this.arrayFilter=arrayFilter;

     }
     
     
     public void parse(String conditional) {
         reConditional.setSourceString(conditional);
         // the conditional string must be of a format similar to col1='souza', col2 in (3,4) etc.
         if (reConditional.next()==false)
           throw new FDSArraysRuntimeException("Invalid conditional syntax:  "+conditional);
         else {
           // col1='souza'
           setLeft(reConditional.getParen(1)); // col1
           setOperator(reConditional.getParen(2)); //=
           setRight(reConditional.getParen(3));// 'souza'
           if (getLeft()==null || getOperator()==null || getRight()==null)  // all values must be provided
              throw new FDSArraysRuntimeException("Invalid conditional syntax:  "+conditional);
        
         }
         
     }
     
     
      private String assignStr(String str) {
          return str==null ? null : str.trim();
      }
      private void setLeft(String left) {
         this.left=assignStr(left);
      }
      
      public String getLeft() {
          return left;
      }
      
      private void setOperator(String operator) {
         this.operator=assignStr(operator);
      }

      /** Returns the operator for the conditional.  For example in, =, != */
      public String getOperator() {
          return operator;
      }
      
      private void setRight(String right) {
         this.right=assignStr(right);
      }

      /** Returns the expression to the right of the conditional.  'souza' in the following example:  col0='souza' */
      public String getRight() {
          return right;
      }
      
      /** Add a conditional to be parsed such as col0='souza' */
      public void addConditional(String conditional) {
        parse(conditional);
        addConditional(getLeft(), getOperator(), getRight());
       
      }

      // This method was added that takes the arguments to simplify the version of addConditional() that
      // doesn't take arguments and to make its intent more clear.  Its intent was getting burried by 
      // implementation details
      
      private void addConditional(String colName, String oper, String comparisonValue) {
        reCol.setSourceString(colName);  // i.e. col1 or fname
        // if a match then we need to add the sort column
        if (reCol.next()) {  // if matches col1 i.e not fname
           // if the column is of the format 'coln' where n is a number then call the addConditional
           // column method that expects an integer else call the addConditional method that exprects a
            // String.
           String colNumStr=reCol.getParen(1);// retrieve the number from col1 i.e. 1
           int colNum=Integer.parseInt(colNumStr);
           arrayFilter.addConditional(colNum, oper, getComparisonValue(colNum));
        } else {
           int colNum=arrayFilter.getColNumFromName(colName);
           arrayFilter.addConditional(colName, oper, getComparisonValue(colNum));
        }

      }
      
      
      
      private Object getComparisonValue(int colNum) {
          DataTypeParser dtp=new DataTypeParser();
          Object compObj=dtp.getComparisonValue(data[0][colNum], getRight());
          return compObj;
      }
      
      
      
      public String toString() {
          return getLeft()+" "+getOperator()+" "+getRight();
      }
      
      private static void printDebugInfo(String conditional) {
          String[] header={"string","date", "integer", "boolean", "float","character",
          "double","bigdecimal","biginteger", "long","short"};
          
          Object[][] data={{"steve",new Date(), new Integer(100), new Boolean("true"),
          new Float("1.05"),new Character('c'), new Double("1.15"), new BigDecimal("100.9"),
          new BigInteger("222"),new Long("100"), new Short("50")}};
          
          ConditionalParser cp=new ConditionalParser(data, new ArrayFilter(header));
          cp.addConditional(conditional);
          System.out.println("\n***");
          System.out.println("after parsing: "+cp);
          System.out.println("left="+cp.getLeft());
          System.out.println("operator="+cp.getOperator());
          System.out.println("right="+cp.getRight());
          System.out.println("ArrayFilter="+cp.arrayFilter);
      }

      /** Test code for this class.  Use the view code link above to view it.  */
      public static void main(String[] args) {
          printDebugInfo("string=='steve'");
          printDebugInfo("date<='12/22/2005 7:00 pm'");
          printDebugInfo("integer==1");
          printDebugInfo("boolean==true");
          printDebugInfo("float==2.5");
          printDebugInfo("character=='c'");
          printDebugInfo("double==3.75");
          printDebugInfo("bigdecimal==4");
          printDebugInfo("biginteger==5");
          printDebugInfo("long==6");
          printDebugInfo("short==7");
          printDebugInfo("string=null");
          printDebugInfo("d biginteger=500"); // note this works but it should really be an error
           
      }
}
