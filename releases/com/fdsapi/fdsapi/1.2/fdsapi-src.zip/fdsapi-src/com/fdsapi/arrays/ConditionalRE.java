

package com.fdsapi.arrays;

import com.fdsapi.*;

/** Conditional that compares a column value against a RegularExpression and returns true if they
  * match.
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/ConditionalRE.htm">View Code</a>
 */
public class ConditionalRE  implements Conditional {
    /** Class used to match RegularExpressions */
    private RegularExpression re;
    /** Col to compare against the Regular expression */
    private int col;
    /** Set to true if the user passes in a null to match against */
    private boolean matchNull=false;
    /** String to match against. */
    private String reString;
    /** Creates a new instance of ConditionalRE comparing the passed in column against the
     String representation of the passed in object. 
     */
    public ConditionalRE(int col, Object reString) {
        
        if (reString==null) {
            matchNull=true;
            this.reString=null;
        } else {
            re=RegularExpression.createInstance(reString.toString());
            this.reString=reString.toString();
        }
        
        this.col=col;

    }
    
    /** Returns true if the column value matches the RegularExpression passed into the constructor.  If this
     * method returns true the row will be kept and if it returns false it will not be kept.
     **/
    public boolean isTrue(Object[] row) {
        if (matchNull && row[col]==null)
            return true;
        else if (row[col]==null)
            return false;
        else {
              re.setSourceString(row[col].toString());
              return re.next();
        }
    }
        
    /** used to create a String represenation of this object.  It returns 'like' */
    public String getType() {
        return "like";
    }
    
    public String toString() {
        return "(col"+col+" "+getType()+" "+reString+")";
    }
        
   
    
}
