/*
 * DataTypeParser.java
 *
 * Created on August 17, 2004, 9:28 AM
 */

package com.fdsapi.arrays;


import java.util.Date;
import java.math.*;
import com.fdsapi.*;

/**
 * <p>Class used to determine the type of a passed in Object.  The methods return true if the passed in data is of the 
 * same type as the method name would indicate. </p>
 *
 *  <p>Several of the String recognition methods were take from a posting on www.experts-exchange.com by maheshexp</p>
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/DataTypeParser.htm">View Code</a>
 */

public class DataTypeParser {
    
    /** Creates a new instance of DataTypeParser */
    public DataTypeParser() {
    }
    
    public boolean isNull(Object dataType) {
        return dataType==null;
    }
    
    public boolean isDate(Object dataType) {
        return dataType instanceof Date;
    }
    
    public boolean isString(Object dataType) {
        return dataType instanceof String;
    }
    public boolean isInteger(Object dataType) {
        return dataType instanceof Integer;
    }
    public boolean isBoolean(Object dataType) {
        return dataType instanceof Boolean;
    }
    public boolean isFloat(Object dataType) {
        return dataType instanceof Float;
    }
    public boolean isCharacter(Object dataType) {
        return dataType instanceof Character;
    }
    public boolean isDouble(Object dataType) {
        return dataType instanceof Double;
    }
  
    public boolean isBigDecimal(Object dataType) {
        return dataType instanceof BigDecimal;
    }

    public boolean isBigInteger(Object dataType) {
        return dataType instanceof BigInteger;
    }

    public boolean isLong(Object dataType) {
        return dataType instanceof Long;
    }
    
    
    public boolean isShort(Object dataType) {
        return dataType instanceof Short;
    }

     public  boolean isDigit(char v){
          return Character.isDigit(v);
     }
     
     public  boolean isAlpha(char v){
          return Character.isLetter(v);
     }
     
     public  boolean isAlphaNumeric(char v){
          return Character.isLetterOrDigit(v);
     }

     // 1000.00 or 100 would return true.
     public  boolean isFloatString(String str){
          int decimalPointCount=0;
          if (str==null)
            return false;
          
          for (int i=0;i<str.length();i++){
             if (str.charAt(i)=='.')
               decimalPointCount++;
             
             boolean flag=(isDigit(str.charAt(i)) && decimalPointCount<=1);
               
             if (flag==false)
               return false;
          }
          return true;
          
     }
     
     
     public  boolean isIntegerString(String str) {
          if (str==null)
            return false;
          
          for (int i=0;i<str.length();i++){
             boolean flag=isDigit(str.charAt(i));
               
             if (flag==false)
               return false;
          }
          return true;
          
     }     
     
     public  boolean isAlpha(String str){
          if (str==null)
            return false;
          
          for(int i=0;i<str.length();i++){
               boolean flag=isAlpha(str.charAt(i));
               
               if (flag==false)
                 return false;
          }
          
          return true;
     }
     
     // number or digit
     public  boolean isAlphaNumeric(String str){
          if (str==null)
            return false;
          
          for(int i=0;i<str.length();i++){
               boolean flag=isAlphaNumeric(str.charAt(i));
               
               if (flag==false)
                 return false;
          }
          return false;
          
     }
     
     

     public  boolean isDateString(String str){
          if (str==null)
            return false;
          
          for(int i=0;i<str.length();i++){
               boolean flag=isAlphaNumeric(str.charAt(i));
               
               if (flag==false)
                 return false;
          }
          return false;
          
     }
     
     public  boolean isQuotedString(String str) {
         if (str==null || "".equals(str.trim()))
           return false;
         
         char first=str.charAt(0);
         char last=str.charAt(str.length()-1);
         
         // either 'souza' or "souza" is a good quoted string.
         if ((first=='\'' || first=='"') && first==last)
           return true;
         else 
           return false;
     }
     
 
     public  String stripQuotes(String str) {
         if (isQuotedString(str)) {
            // copy the string except for surrounding quotes:  i.e. 'souza' or "souza"
            // become souza
            str = str.substring(1, str.length()-1);
         }
         
         return str;

     }
     
     private Object wrapperFactory(Object type, String valueToConvert) {
          if ("null".equalsIgnoreCase(valueToConvert))
           return wrapperFactory("null",null);
          else if (type==null)  // FIX THIS TO GO ON TYPECAST
           return null;// return convertTotype(valueToConvert);
          else if (isString(type)) 
            return wrapperFactory("String", stripQuotes(valueToConvert));    
          else if (isInteger(type))
            return wrapperFactory("Integer",valueToConvert); 
          else if (isFloat(type))
            return wrapperFactory("Float",valueToConvert);
          else if (isDate(type))
            return wrapperFactory("Date",stripQuotes(valueToConvert));
          else if (isBoolean(type))
            return wrapperFactory("Boolean",valueToConvert);
          else if (isCharacter(type))
            return wrapperFactory("Character",stripQuotes(valueToConvert));
          else if (isDouble(type))
            return wrapperFactory("Double",valueToConvert);
          else if (isLong(type))
            return wrapperFactory("Long",valueToConvert);
          else if (isShort(type))
            return wrapperFactory("Short",valueToConvert);
          else if (isBigDecimal(type))
            return wrapperFactory("BigDecimal",valueToConvert);
          else if (isBigInteger(type))
            return wrapperFactory("BigInteger",valueToConvert);
          else 
            return null;    

         
     }
 
     
     private Object wrapperFactory(String type, String valueToConvert) {
         
         //type will now be a string versus the actual datatype.  this will allow 
         //casting to call the same function.
          if ("null".equalsIgnoreCase(valueToConvert))
           return null;
          else if (type==null)  // FIX THIS TO GO ON TYPECAST
           return null;// return convertToDataType(compValue);
          else if ("String".equalsIgnoreCase(type)) 
            return valueToConvert;    
          else if ("Integer".equalsIgnoreCase(type))
            return new Integer(valueToConvert); 
          else if ("Float".equalsIgnoreCase(type))
            return new Float(valueToConvert);
          else if ("Date".equalsIgnoreCase(type))
            return new Date(stripQuotes(valueToConvert));
          else if ("Boolean".equalsIgnoreCase(type))
            return new Boolean(valueToConvert);
          else if ("Character".equalsIgnoreCase(type))
            return new Character(valueToConvert.charAt(0));
          else if ("Double".equalsIgnoreCase(type))
            return new Double(valueToConvert);
          else if ("Long".equalsIgnoreCase(type))
            return new Long(valueToConvert);
          else if ("Short".equalsIgnoreCase(type))
            return new Short(valueToConvert);
          else if ("BigDecimal".equalsIgnoreCase(type))
            return new BigDecimal(valueToConvert);
          else if ("BigInteger".equalsIgnoreCase(type))
            return new BigInteger(valueToConvert);
          else 
            return null;    
         
     }
     
     public boolean isInFormat(String value) {
         // format for in clause args
         // ('steve','souza')
         // (100,200,300)
         if (value==null)
           return false;

         value=value.trim();
         if (value.charAt(0)=='(' && value.charAt(value.length()-1)==')')
           return true;
         else 
           return false;
         
     }
     
       /** Using a regular expression - split the passed in string along token boundaries */
      private Object[] inClauseWrapperFactory(Object dataType, String inClause) {
          // remove parens i.e make ('steve','souza') into 'steve','souza'
          inClause=inClause.substring(1,inClause.length()-1);
          // split 'steve','souza' into an array of strings
          String[] arr=Utils.split(",",inClause);
          if (arr==null || arr.length==0) 
            return null;
          
          // convert the array of strings into the underlying objects i.e. strings, Integers 
          // etc.
          Object[] inObjects=new Object[arr.length];
          for (int i=0;i<arr.length;i++) 
             // trim values passed so integers don't blow up.  i.e. trim "  400 "
             inObjects[i]=wrapperFactory(dataType,arr[i].trim());
          
          return inObjects;

      }
     
  
      /** Takes a String from ArraySQL and converts it to the appropriate data type based on the comparison value.  For
       * example mydate='04/12/04' would know that the string should be converted to a date based on the fact that the
       * data it is being compared to is a date.  If the data in mydate was a String then a String comparison object would
       * be returned, not a Date 
       */
      public Object getComparisonValue(Object dataType, String compValue) {
            // if in statment 
            // ('jeff','mike') 
            // (100,200,  400  )
            // '(100,200,  400  )' - this is a string not an in statement
              if (isInFormat(compValue)) 
                return inClauseWrapperFactory(dataType, compValue);
              else
                return wrapperFactory(dataType,compValue);
      }


 

    
}
