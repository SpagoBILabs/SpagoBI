/*
 * FDSArraysRuntimeException.java
 *
 * Created on June 17, 2004, 9:39 PM
 */

package com.fdsapi.arrays;



/**
 * RuntimeException used for coding errors in this package.
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/FDSArrayRuntimeException.htm">View Code</a>
 */
public class FDSArraysRuntimeException extends RuntimeException {
    
    public FDSArraysRuntimeException(String msg) {
        super(msg);
    }
    

}
