

package com.fdsapi.arrays;


/** Used in a decorator chain to Negate any other conditional.  This reduces the ammount of code that must
 ** be written as != and others are simply wrapped in the NegateConditional() object and so other classes
 ** need not be created.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/NegateConditional.htm">View Code</a>
 **/
public class NegateConditional implements Conditional {
    
    /** Conditional to negate */
    private Conditional nextConditional;
 /** Creates a new instance of NegateConditional, negating the Conditional that is passed in.  If this
  passed in Conditional is false then NegateConditional returns true and if it is true NegateConditional 
  returns false.
  */
    public NegateConditional(Conditional nextConditional) {
      this.nextConditional=nextConditional;
  }
  
  /** This method returns the opposite of the next Conditional in the chain thus negating it. */
  public boolean isTrue(Object[] row) {
      return !(nextConditional.isTrue(row));
  }

  /** Returns '!' to help in creating a String representation of the Conditional */
  public String getType() {
      return "!";
  }
  
  
  /** Return a String representation of this Conditional */
   public String toString() {
       return getType()+nextConditional;
   }
     
    
}
