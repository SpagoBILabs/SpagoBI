

package com.fdsapi.arrays;

/** This class implements the null object design pattern for Conditionals. It is an implementation of the Null object design pattern and is used 
 * to end the decorator chain.
 *
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/NullConditional.htm">View Code</a>
 */
public class NullConditional implements Conditional {
    
    /** Creates a new instance of NullConditional */
    public NullConditional() {
    }
    
    /** The NullConditional returns false always because its use is as a terminator in a decorator chain
     * that tests for true false with an or condition.  By returning false the NullConditional can never
     * incorrectly trigger a true condition.  i.e. return this.isTrue(row) || nextConditional.isTrue(row);
     * where if no conditional has been set nextConditional is the NullConditional.
     */
    public boolean isTrue(Object[] row) {
        return false;
    }
    
    /** Empty implementation */
    public String getType() {
        return "";
    }
    
   
   public String toString() {
       return "";
   }
    
}
