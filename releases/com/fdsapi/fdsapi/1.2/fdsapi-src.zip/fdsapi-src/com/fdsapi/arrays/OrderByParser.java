/*
 * OrderByParser.java
 *
 * Created on July 23, 2004, 10:00 PM
 */

package com.fdsapi.arrays;


import com.fdsapi.*;
import com.jamonapi.*;
/**
 ** <p>Class that parses the Order by clause passed to ArraySQL and translates the String to calls to the ArrayComparator.
    It takes the following formats:  col0, col1 desc, col2 asc, col3 ascending, mycolname descending</p> 
 
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/OrderByParser.htm">View Code</a>

 */
public class OrderByParser {
    
        
        private String orderByClause; // col0 desc, col1 asc
        private RegularExpression reColMatch1=new RegularExpression("(\\w+) *(asc|desc|ascending|descending)?");
        private RegularExpression reColMatch2=new RegularExpression("col([0-9]*)");
        private ArrayComparator arrayComp;

        public OrderByParser(String orderByClause, ArrayComparator arrayComp) {
           this.orderByClause=orderByClause;    
           this.arrayComp=arrayComp;
                   
        }

         /** The constructor takes an order by clause not including the keywords 'order by'.  
         *  For example:  new OrderByParser("col1 desc, col0 asc, col3");
          * A null is also acceptable and has the effect of not having a sort order:
         *  For example:  new OrderByParser(null);
          *
         *
         */
        public OrderByParser(String orderByClause) {
           this.orderByClause=orderByClause;    
           this.arrayComp=new ArrayComparator();
                   
        }
        
        /** Returns the ArrayComparator object that backs this OrderByParser */
        public ArrayComparator getArrayComparator() {
            return arrayComp;
        }

        /** This method parses the order by string passed to the constructor and adds the clauses to the backing ArrayComparator object */
        public void addSortCols() {
            String[] orderByCols=parse();
            for (int i=0; i<orderByCols.length; i++) {
                addSortCol(orderByCols[i].trim());
            }
        }
        
        /* Parses the order by clause passed into the constructor.  If order by col1 desc, fname asc, lname
        * then this method returns 3 array elements:  0) col1 desc 1) fname asc 2) lname
         */
        public String[] parse()  {
          if (orderByClause==null)
            return new String[0];
          else
            return Utils.split(",",orderByClause);
        }
  
        /* This method takes a string in the following formats:  col1 asc, col2 descending, salary, salary desc
         and calls the appropriate ArrayComparator addSortCol method depending on which format is required.
         **/
        public void addSortCol(String orderByCol) {
            reColMatch1.setSourceString(orderByCol);
            // if a match then we need to add the sort column
            if (reColMatch1.next()) {
              // get the direction of the sort, default to ascending
              String dir=reColMatch1.getParen(2);
              if (dir==null)
                dir="asc";

              // get the sort column
              String col=reColMatch1.getParen(1);
              reColMatch2.setSourceString(col);
              // if the column is of the format 'coln' where n is a number then call the add sort
              // column method that expects an integer else call the add sort column method that exprects a
              // String.
              if (reColMatch2.next()) {
                String colNumStr=reColMatch2.getParen(1);
                int colNum=Integer.parseInt(colNumStr);
                arrayComp.addSortCol(colNum, dir);
             } else {
                arrayComp.addSortCol(col,dir);
             }
            }
        }

      /** Incomplete function that will eventually be used to improve the HTML sorting template */
      public static String prependOrderBy(String query, String sortCol, String sortOrder) {
          // select * from array order by col0 asc, col2 desc
          // select * from array
          //          getquerywithout order by
          String select=getSelect(query);
          String orderBy=getOrderByClause(query);
          String orderByClause="col"+sortCol+" "+sortOrder;
          orderBy=(orderBy==null) ? orderByClause : orderByClause+", "+orderBy;
          return select+" order by "+orderBy;

      }
      
      private static String getSelect(String query) {
        return Utils.getREMatch("(select +.* +from +array).*", query, 1);
      }
     
      /** Method that gets an order by clause from a select statement.  The following would return 'col1 desc':  
       * select * from array order by col1 desc'
       */ 
      public static String getOrderByClause(String query) {
        // The following RE ensures that the order by is not in a String. i.e.
        // select ' order by col0 ',* from array where col0=' order by col0 ' order by col0
        return Utils.getREMatch(".* +order +by +(.*[^'\"])", query, 1);
      }
      /** Code used to test this class.  To view select the 'View Code' link above. */
      public static void main(String[] args) {
          String[] header={"fname", "lname"};
          OrderByParser p=new OrderByParser("col1, col2 desc, fname , lname", new ArrayComparator(header));
          p.addSortCols();
          System.out.println(p.getArrayComparator());
          System.out.println(prependOrderBy("select * from array order by col1 des, col 2 asc, fname", "0", "asc"));
          System.out.println(prependOrderBy("select * from array order by col1 des, col 2 asc, fname", "2", "desc"));
          System.out.println(prependOrderBy("select * from array", "2", "desc"));
          
          System.out.println(getSelect("select *,col1,rownum()  from     array order by col1 des, col 2 asc, fname"));
          System.out.println(getSelect("select * from array order by col1 des, col 2 asc, fname"));
          System.out.println(getSelect("SELECT     * from array"));

          System.out.println("1) order by clause="+getOrderByClause("select * from array where (string='select' or string='from' or string='where' or string=' order by ' or string='string' or string='col0' or string='jeff') order by string desc, col0 asc, col1"));
          System.out.println("2) order by clause="+getOrderByClause("select * from array    order    by col0 desc, col1 asc, string"));
          System.out.println("3) order by clause="+getOrderByClause("select * from array   where string=' order by '"));
          System.out.println("4) order by clause="+getOrderByClause("select rowNum(), * from array order by col0 desc"));
          System.out.println("5) order by clause="+getOrderByClause("select * from array where string='select * from array where string=\"string\" order by string'"));
          System.out.println("6) order by clause="+getOrderByClause("select * from array where string='select * from array where string=\"string\" order by string' order by string, col0"));

          
      }    

}
