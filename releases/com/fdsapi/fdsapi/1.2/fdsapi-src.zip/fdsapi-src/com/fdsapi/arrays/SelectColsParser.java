/*
 * SelectColsParser.java
 *
 * Created on July 24, 2004, 11:45 AM
 */

package com.fdsapi.arrays;

import com.fdsapi.*;

/**
 * <p>Class that parses the select columns passed to ArraySQL and translates the String to calls to the ArrayFilter.
 *  For example it could take: col0, col1, col2, *.  This class is not thread safe. </p>
 *
* <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/SelectColsParser.htm">View Code</a>

 */
public class SelectColsParser {
    
   private String selectColsStr;
   private ArrayFilter arrayFilter;
   private int cols;
   private RegularExpression re=new RegularExpression("col([0-9]*)");
   private RegularExpression functions;
            
   public SelectColsParser(Object[][] data, String selectColsStr, ArrayFilter arrayFilter) {
         this.selectColsStr=selectColsStr;
         this.arrayFilter=arrayFilter;
         // matches functions
         functions=new RegularExpression(arrayFilter.getColumnFunctionFactory().getFunctionREString());
         if (data==null || data[0]==null)
           cols=0;
         else
           cols=data[0].length;
   }
 
   
   public SelectColsParser(Object[][] data, String selectColsStr) {
        this(data, selectColsStr, new ArrayFilter());
   }
   
   /** Parses the String passed to the constructor and calls the appropriate ArrayFilter function to add the columns to the display
    * list
    */
    public void addSelectCols() {
       String[] cols=parse();
       for (int i=0; i<cols.length; i++) 
           addSelectCol(cols[i].trim());
    }    
    
    /** Add a single select column such as col0 or fname to the ArrayFilter*/
    public void addSelectCol(String colValue) {
      /* loop through the array of cols i.e. ({"col1","fname",}
       * and call addDisplayCol(..) (with a number or string whichever
       * is appropriate) or addDisplayFunction(...) if that is appropriate.
       */
      colValue=colValue.trim();
      re.setSourceString(colValue);
      if (re.next()) {  // if a col with a number was matched (i.e. col22)
         String colNumStr=re.getParen(1);  // ([0-9]*)
         int colNum=Integer.parseInt(colNumStr); // get the number and add it to the display
         arrayFilter.addDisplayCol(colNum);
      } else if (isFunction(colValue)) {
         arrayFilter.addDisplayFunction(colValue);
      } else if ("*".equals(colValue)) {// if the col is not a * then add the string as a display col
         addAllColumns(); 
      } else          
        arrayFilter.addDisplayCol(colValue);
      
    }
    
    private boolean isFunction(String colValue) {
      functions.setSourceString(colValue);
      return functions.next();
    }
    
    private void addAllColumns() {
       for (int i=0;i<cols;i++)
          arrayFilter.addDisplayCol(i);
    }
      
        
      public String[] parse()  {
        return Utils.split(",",selectColsStr);
      }
    
      /** Get the ArrayFilter that backs this object */
      public ArrayFilter getArrayFilter() {
            return arrayFilter;
      }
      
      /** Get the select column list from a full query such as: select col1, col2, * from array.  This would return col1, col2, *
       */
      public static String getSelectCols(String query) {
        return Utils.getREMatch("select +(.*) +from +array", query, 1);
    }
     
       
     /** Method that has testing code for this class.  Click the 'View Code' link above to see the code */ 
      public static void main(String[] args) {
          String[] header={"fname", "lname"};
          Object[][] data={{"steve","souza"},{"jeff","beck"}};
          SelectColsParser p=new SelectColsParser(data,"rowNum(), date(), 'steve', \"souza\", col1, col2, fname , lname,*,*", new ArrayFilter(header));
          p.addSelectCols();
          System.out.println(p.getArrayFilter());
     
          String query="    select string,col1,*,rowNum(),'steve' from array where col0='steve' ordery by col1";
          System.out.println("1) query="+query);
          System.out.println("  query display cols="+getSelectCols(query));
          
          query="    select * from array where string='select' or string='from' or string='where' or string='string' or string='col0' or string='jeff'";
          System.out.println("2) query="+query);
          System.out.println("  query display cols="+getSelectCols(query));

          query="    select rowNum(), * from array ";
          System.out.println("3) query="+query);
          System.out.println("  query display cols="+getSelectCols(query));
          
       }
            
}
