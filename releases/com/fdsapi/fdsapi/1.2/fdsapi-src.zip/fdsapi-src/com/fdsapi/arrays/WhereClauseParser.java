/*
 * WhereClauseParser.java
 *
 * Created on July 23, 2004, 10:05 PM
 */

package com.fdsapi.arrays;

import com.fdsapi.*;
import com.jamonapi.*;
import java.util.*;

/**
 *
 * <p>Class that parses an entire where clause passed to ArraySQL and translates the String to calls to the ArrayFilter.
 *  For example it could take: col0, col1, col2, *.  This class is not thread safe. </p>
  ** <p>This class is not thread safe. </p>
 * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/WhereClauseParser.htm">View Code</a>
 */
public class WhereClauseParser {
    
            private char[] whereClause;
            private List tokens=new ArrayList();
            private StringBuffer token=new StringBuffer();
            private int currentCharNum=0;
            private boolean isInString=false;
            private char delim;
            private boolean isEscaped=false;
            private ArrayFilter arrayFilter;
            private boolean ignoreParens;
            private ConditionalParser conditionalParser=null;
            private boolean hasWhereClause;
                        
            /** This represents the beginning of the previous token and is used when to know to determine how big the token is */
            public WhereClauseParser(Object[][] data, String whereClauseStr, ArrayFilter arrayFilter) {
                this.hasWhereClause = (whereClauseStr==null || "".equals(whereClauseStr.trim())) ? false : true;
                // the extra spaces make it so getPrevChar() doesn't fail the first time through the loop
                // There is no harm to the logic by padding spaces.
                this.whereClause=(hasWhereClause) ? (" "+whereClauseStr+" ").toCharArray() : null; 
                this.arrayFilter=arrayFilter;
                conditionalParser=new ConditionalParser(data, arrayFilter);

            }
            
            public WhereClauseParser(Object[][] data, String whereClauseStr) {
                this(data, whereClauseStr, new ArrayFilter());
            }
            
            /** Get the ArrayFilter that backs this WhereClauseParser */
            public ArrayFilter getArrayFilter() {
                return arrayFilter;
            }
            
            // Indicates if the character is embedded in a where clause string surrounded by ' or ".
            // i.e. this would return true for any characters in between double quotes "steve's"
            private boolean isInString() {
                return isInString;
            }
            
            private void setIsInString(boolean isInString) {
                this.isInString=isInString;
            }
            
            private void setStringDelim(char delim) {
                this.delim=delim;
            }
            
            private char getStringDelim() {
                return delim;
            }
            
            private boolean isEscapeChar() {
                return '\\'==getCurrentChar();
            }
            
            private char getCurrentChar() {
                return whereClause[currentCharNum];
            }
            
            private char getNextChar() {
                return whereClause[currentCharNum+1];
            }
            
            private char getPrevChar() {
                return whereClause[currentCharNum-1];
            }
            
            private char getCharTwoForward() {
                return whereClause[currentCharNum+2];
            }

            private char getCharThreeForward() {
                return whereClause[currentCharNum+3];
            }
            
            private boolean isEscaped() {
                return isEscaped;
            }
            
            private void setEscaped(boolean isEscaped) {
                this.isEscaped=isEscaped;
            }
            
            private void setStringDelim() {
                // if first delimiter in a string like 'steve' then prepare for a string to be
                // processed
                if (!isInString() && !isEscaped() && (getCurrentChar()=='\'' || getCurrentChar()=='"')) {
                    setStringDelim(getCurrentChar());
                    setIsInString(true);
                } // else it is the last ' or " in 'steve'
                else if (isInString() && !isEscaped() && getCurrentChar()==getStringDelim()) {
                    setIsInString(false);
                }
            }
            
            
            /** If a where clause was passed in the contructor then add it else simply return */
            public void addWhereClause() {
                if (hasWhereClause) {
                  String[] values=parse();
                  for (int i=0;i<values.length;i++) {
                     addWhereClauseToken(values[i].trim());
                  }
                }
                
            }
            
            // pass (,),||,&&,col1=10 etc. and call the appropriate ArrayFilter method
            private void addWhereClauseToken(String token) {
                
               if ("(".equals(token))
                 arrayFilter.addLeftParen();
               else if (")".equals(token))
                 arrayFilter.addRightParen();
               else if ("||".equals(token) || "or".equalsIgnoreCase(token))
                 arrayFilter.addOr();
               else if ("&&".equals(token) || "and".equalsIgnoreCase(token))
                 arrayFilter.addAnd();
               else if ("!".equals(token))
                 arrayFilter.addNot();
               else {
                 // in the following case token would be something like one of the following:
                 //  col1=10
                 //  lname='souza'
                 addConditional(token);
               }
            }
            
            
            /** Parse the passed in where clause and break it along token lines.  A bug: ADD ! (...) and in (...) (ignore parens) */
            public String[] parse() {
                if (!hasWhereClause)
                  return null;
                
                // loop through char[] array that contains the where clause with each character
                // of the where clause being an array element:   col1='souza' || col2<10000
                // The loop below groups the array elements into an array that contains the tokens
                // of interest such as (,),||,&& or col1='souza'.  These values will be used to
                // call the appropriate ArrayFilter methods.
                // isInString()
                // isEscapeChar()
                // must remove any of the escape characters i.e. not treat them as literal
                
                // don't loop though first and last characters as these are just spaces to make
                // it so getPrevChar() doesn't throw an exception on the first character.
                for (currentCharNum=1;currentCharNum<whereClause.length-1;currentCharNum++) {
                    // select * from array where (col1=100 || col2=100) - open i.e. left paren
                    if (isLeftParen())  {
                      addLeftParen();
                    }  // select * from array where (col1=100 || col2=100) - close i.e. right paren
                    else if (isRightParen()) {
                     addRightParen();
                    } // select * from array where (col1=100 || col2=100) - or i.e. ||
                    else if (isOr()) {                        
                     addOr();   
                    } // select * from array where (col1=100 && col2=100) - and i.e. &&
                    else if (isAnd()) {
                     addAnd();
                    } // trigger on select * from array where !(col1=100 || col2=30) but not on col1!=1 or col1 !like or col1 !LIKE
                    else if (isNot()) {
                     addNot();
                    } // select * from array where col1='steve\''  - only needed for quotes
                    else if (isEscapeChar()) { // escape character
                     addEscape();
                    } else { // not a special character
                     addOtherChar();
                    }
                }
  
                addToken();
                
                return Utils.convert(tokens.toArray());
            }
            
            private boolean isLeftParen() {
                return !isInString() && !isIgnoreParens() && getCurrentChar()=='(';
            }
            private void addLeftParen() {
               setEscaped(false);
               addToken();
               addTokenChar('(');
               addToken();
            }
            
            private boolean isRightParen() {
                return !isInString() && !isIgnoreParens() && getCurrentChar()==')';
            }
            private void addRightParen() {
               setEscaped(false);
               addToken();
               addTokenChar(')');
               addToken();
            }
            
            private boolean isNot() {
                return !isInString() && getCurrentChar()=='!' && (getNextChar()!='=' && getNextChar()!='l' && getNextChar()!='L' );
            }
            
            private void addNot() {
               setEscaped(false);
               addToken();
               addTokenChar('!');
               addToken();
            }

            private boolean isOr() {
                // either 'or' or '||' syntax is ok
                return !isInString() && 
                        ( // ||
                          (getCurrentChar()=='|' && getNextChar()=='|') ||
                          ( // or
                             getPrevChar()==' ' &&
                            (getCurrentChar()=='o' || getCurrentChar()=='O') && 
                            (getNextChar()=='r'    || getNextChar()=='R') &&
                             getCharTwoForward()==' '
                          )
                        );
 
            }
            
            private void addOr() {
               setEscaped(false);
               addToken();
               addTokenChar('|');
               addTokenChar('|');
               addToken();
              // normally only 1 character is skipped in the token loop, but 'or' or '||' must skip an extra one
              // hence the following line
               currentCharNum++; 
            }
            
            private boolean isAnd() {
                // either 'and' or '&&' syntax is OK
                return !isInString() && 
                        ( // &&
                          (getCurrentChar()=='&' && getNextChar()=='&') ||
                          ( // and
                             getPrevChar()==' ' &&
                            (getCurrentChar()=='a' || getCurrentChar()=='A') && 
                            (getNextChar()=='n'    || getNextChar()=='N') && 
                            (getCharTwoForward()=='d' || getCharTwoForward()=='D') &&
                             getCharThreeForward()==' '
                          )
                        );
            }
            
            private void addAnd() {
               setEscaped(false);
               addToken();
               addTokenChar('&');
               addTokenChar('&');
               addToken();
              // normally only 1 character is skipped in the token loop, but '&&' needs to skip an extra char and 'and'
              // needs to skip an extra 2 characters hence the following line
               if (getCurrentChar()=='&')
                 currentCharNum++;  // '&&' token
               else
                 currentCharNum=currentCharNum+2; // 'and' token
                   
            }
            
            private void addEscape() {
               if (isEscaped()) {
                 setEscaped(false);
                 addTokenChar(getCurrentChar());
               }
               else {
                 setEscaped(true);
               }
                
            }
            
            private void addOtherChar() {
               setStringDelim();
               setIgnoreParens();
               setEscaped(false);
               addTokenChar(getCurrentChar());
            }
            
            private void setIgnoreParens() {
              // special case for left and right paren is col1 in ('steve','souza'). Part of where
              // clause not a logical left paren.  also applies to not in ('steve')
               if (!isInString() 
                   && getPrevChar()==' '
                   && (getCurrentChar()=='i' || getCurrentChar()=='i') 
                   && (getNextChar()=='n' || getNextChar()=='N') 
                   && (getCharTwoForward()==' ' || getCharTwoForward()=='(') ) 
               {
                   setIgnoreParens(true);
               } else if (isIgnoreParens() && getCurrentChar()==')')
                   setIgnoreParens(false);

            }
            
            private void setIgnoreParens(boolean ignoreParens) {
                this.ignoreParens=ignoreParens;
            }
            
            private boolean isIgnoreParens() {
                return ignoreParens;
            }
            
            
            private void addTokenChar(char c) {
                token.append(c);
            }
            
            private void addToken() {
              if (token!=null) {
                String trimmedToken=token.toString().trim();
                if (!"".equals(trimmedToken))  {
                  tokens.add(trimmedToken);
                  token.setLength(0);
                }
              } else
                token=new StringBuffer();
                  
         
            }
            
       /* Called for each conditional in the where clause.  For example if the select statement was:
        * select * from array where col1=100 && col2='ssouza'
        * then this method would be called twice.  Once with addConditional("col1=100") and once with
        * addConditional("col2='souza'")
        **/
      
       private void addConditional(String conditional) {
         conditionalParser.addConditional(conditional);
       }
       
       /** Get the where clause from a passed in select statement. 'select * from array where col0='souza' order by col1 desc' 
        * would return col0='souza'
        */    

       public static String getWhereClause(String query) {
         String matchStr=Utils.getREMatch("select +.* +from +array +where +(.*)( +order +by +)", query, 1);
         if (matchStr==null)
            matchStr=Utils.getREMatch("select +.* +from +array +where +(.*)", query, 1);
        
         return matchStr;
       }
       
      private static void printDebugInfo(String whereClauseStr) {
          String[] header={"string","lname", "short", "sand"};
          Object[][] data={{"steve","souza",new Integer(20), "sand"},{"jeff","beck", new Integer(20),"no sand"}};

          WhereClauseParser p=new WhereClauseParser(data, whereClauseStr, new ArrayFilter(header));
          p.addWhereClause();
          
          System.out.println("\n***");
          System.out.println("where clause="+whereClauseStr);
          System.out.println("parsed ArrayFilter="+p.getArrayFilter());
          p.getArrayFilter().filter(data);
      }

      /** Method that has test code for this class.  Click 'View Code' above to view the code */
      public static void main(String[] args) {
          printDebugInfo("short=20 || sand='no sand' or short=30 && sand='no sand' and sand='no sand'"); 
          printDebugInfo("(string ='jeff in z')"); 
          printDebugInfo("lname='steve' || sand='no sand'"); 
          printDebugInfo("string='select' or string='from' or string='where' or string='order by' or string='string' or string='col0' or string='jeff'");
          printDebugInfo(null);// Null/empty where clause is allowed
          System.out.println("1) parsed where clause="+getWhereClause("select * from array where (string='select' or string='from' or string='where' or string=' order by ' or string='string' or string='col0' or string='jeff')"));
          System.out.println("2) parsed where clause="+getWhereClause("select * from array where string=\" order by \" or string=\"steve\""));
          System.out.println("3) parsed where clause="+getWhereClause("select * from array where (string='select' or string='from' or string='where' or  string='string' or string='col0' or string='jeff')"));
          System.out.println("4) parsed where clause="+getWhereClause("select * from array where string='select * from array where string=\"string\" order by string'"));
          
          
      }    
      


}
