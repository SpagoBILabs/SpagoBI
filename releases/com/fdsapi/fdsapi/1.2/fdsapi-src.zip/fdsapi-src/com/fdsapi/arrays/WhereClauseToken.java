/*
 * WhereClauseToken.java
 *
 * Created on November 7, 2004, 9:20 AM
 */

package com.fdsapi.arrays;

import java.util.*;
import com.jamonapi.utils.*;
/**
 * Class that represents each token in a where clause.  Examples are conditionals (col0='souza'), 
 * logical operators (and/or), and parens.  The following example has 11 tokens:  select * from array where
 * (col0='steve' and col1='souza') or (col0='jeff' and col1='beck')
 * 
* * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/WhereClauseToken.htm">View Code</a>
  */
public class WhereClauseToken {
    
    private String token="";
    private Conditional conditional;
    private String action;
    private WhereClauseTokenValidator tokenValidator=new WhereClauseTokenValidator();
    
    /** Creates a new instance of WhereClauseToken */
    public WhereClauseToken(String token) {
        this.token=token;
        tokenValidator = tokenValidator.getTokenValidator(token);
    }
    
    public WhereClauseToken(Conditional conditional) {
       this.conditional=conditional; 
       tokenValidator = tokenValidator.getTokenValidator("conditional");
       token="conditional";
    }
    
    
    public String getValue() {
        return token;
    }
    
    public Conditional getConditional() {
        return conditional;
    }
    
    public String getAction() {
        return action;
    }
    
    public void setAction(String action) {
        this.action=action;
    }
    
 
    public boolean isLeftParen() {
        return "(".equals(token);
    }
    
    public boolean isRightParen() {
        return ")".equals(token);
    }
    
    public boolean isOr() {
        return "||".equals(token) || "or".equalsIgnoreCase(token);
    }
    
    public boolean isAnd() {
        return "&&".equals(token) || "and".equalsIgnoreCase(token);
    }
    
    public boolean isOperator() {
        return isAnd() || isOr();
    }
    
    public boolean isNot() {
        return "!".equals(token) || "not".equalsIgnoreCase(token);
    }
    
    
    // If the token is none of the above it is assumed to be a conditional.  
    public boolean isConditional() {
        return "conditional".equalsIgnoreCase(token);
    }
    
    public boolean isNull() {
        return "null".equalsIgnoreCase(token);
    }
    
    public boolean isTokenType(String argType) {
        return token.equalsIgnoreCase(argType);
    }
    
    public boolean isValid(WhereClauseToken nextToken) {
        return tokenValidator.isValid(nextToken);
    }
    
    public String getValidationError() {
        return tokenValidator.getValidationError();
    }
    
    public String toString() {
        if (conditional==null)
          return token;
        else
          return conditional.toString();
    }
    
    /** Token Validators */
        
    private static class WhereClauseTokenValidator {
        protected String validationError="";
        private String createComposite="no";
        private static Map factory=AppMap.createInstance();
        static {
            addValidator("(", new WhereClauseLeftParenValidator());
            addValidator(")", new WhereClauseRightParenValidator());
            addValidator("or", new WhereClauseOrValidator());
            addValidator("||", new WhereClauseOrValidator());
            addValidator("and", new WhereClauseAndValidator());
            addValidator("&&", new WhereClauseAndValidator());
            addValidator("not", new WhereClauseNotValidator());
            addValidator("!", new WhereClauseNotValidator());
            addValidator("conditional", new WhereClauseConditionalValidator());
            
        }

        public String getValidationError() {
            return validationError;
        }
        
        public WhereClauseTokenValidator getTokenValidator(String token) {
            if (factory.containsKey(token))
              return (WhereClauseTokenValidator)factory.get(token);
            else
              return new WhereClauseConditionalValidator();
             
        }
        
        private static void addValidator(String key, WhereClauseTokenValidator validator) {
            factory.put(key, validator);
        }
        
        public boolean isValid(WhereClauseToken nextToken) {
            return false;
        }
        
       
    }
    
    private static class WhereClauseLeftParenValidator extends WhereClauseTokenValidator {
        
        
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) (col0=1 
            //  2) ((col0=1 )...
            //  3) (!(col0=1))
            if (nextToken.isConditional() || nextToken.isLeftParen() || nextToken.isNot()) 
              return true;
            else {
              validationError="A left paren must be followed by a conditional, another left paren, or a not (either 'not' or '!')";
              return false;
            }
        }
        
    }
    

  private static class WhereClauseRightParenValidator extends WhereClauseTokenValidator {
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) (col0=1) or ...
            //  2) ((col0=1 ))...
            if (nextToken==null || nextToken.isOperator() || nextToken.isRightParen()) 
              return true;
            else {
              validationError="A right paren must be followed by an operator, or another right paren";
              return false;
            }
        }
        
    }

 private static class WhereClauseOrValidator extends WhereClauseTokenValidator {
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) or col0=1 
            //  2) or (col0=1...
            //  3) or !(col0=1...
            if (nextToken.isConditional() || nextToken.isLeftParen() || nextToken.isNot()) 
              return true;
            else {
              validationError="The 'or' operator must be followed by a conditional, a left paren, or a not (either 'not' or '!')";
              return false;
            }
        }
        
            
        
    }

private static class WhereClauseAndValidator extends WhereClauseTokenValidator {
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) and col0=1 
            //  2) and (col0=1...
            //  3) and !(col0=1...
            if (nextToken.isConditional() || nextToken.isLeftParen() || nextToken.isNot()) 
              return true;
            else {
              validationError="The 'and' operator must be followed by a conditional, a left paren, or a not (either 'not' or '!')";
              return false;
            }
        }
        
    }

private static class WhereClauseNotValidator extends WhereClauseTokenValidator {
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) not col0=1 
            //  2) not ((col0=1 )...
            //  3) not not col0=1
            if (nextToken.isConditional() || nextToken.isLeftParen() || nextToken.isNot())
              return true;
            else {
              validationError="The not conditional must be followed by a conditional, a left paren, or a not (either 'not' or '!')";
              return false;
            }
        }
        
    }

private static class WhereClauseConditionalValidator extends WhereClauseTokenValidator {
        public boolean isValid(WhereClauseToken nextToken) {
            // valid terms/tokes that can follow '('/left paren/open paren
            // ex. 
            //  1) (col0=1 2) 
            //  2) ((col0=1 )...
            //  3) (!(col0=1))
            if (nextToken==null || nextToken.isOperator() || nextToken.isRightParen()) 
              return true;
            else {
              validationError="A conditional must be followed by an operator (and, or), or a right paren";
              return false;
            }
        }
        
    }

    
    
}
