

package com.fdsapi.arrays;

import java.util.*;
import com.fdsapi.*;

/** 
 * Class that validates and gives a rules table for building both ArrayFilter and ArraySQL classes. 
 * Having a separate class to do this makes for much easier testing.  This class can be tested 
 * indpendent of all the many other objects it takes to build ArrayFilters and the array of data it returns
 * can easily be eyeballed for accuracy.  Without this class testing ArrayFilter would be much more difficult.
 * 
 *
 * * <br><br><a href="http://www.fdsapi.com/javadocs/com/fdsapi/arrays/WhereClauseTokens.htm">View Code</a>
 * <p>Author: Steve Souza</p>

 * Nov 7, 2004
 */
public class WhereClauseTokens {
    
     private List tokens=new ArrayList(); // tokens are and's, or's, conditionals, parens etc.
     private FDSStack compositeStack; // stack that holds the current conditional levels.
     private WhereClauseToken[] tokensArray; // an array that holds the tokens
     private String validationError=""; // Contains a validation error message if one occured.
     // if true runtimeexecptions are thrown when syntax errors occur.  probably the only time it would
     // be false is when testing.
     private static boolean throwValidationExceptions=true; 
     private int currentToken=-1;
     // null object pattern.
     private static final WhereClauseToken NULLTOKEN=new WhereClauseToken("null");
     
     public WhereClauseTokens() {
         resetCompositeStack();
     }

     /** if true syntax errors will throw a RuntimeException */
     public static void setThrowValidationExceptions(boolean throwExceptions) {
         throwValidationExceptions=throwExceptions;
     }
     
     /** Returns true if syntax exceptions will throw a RuntimeException */
     public static boolean getThrowValidationExceptions() {
         return throwValidationExceptions;
     }
     
     // The following methods are fairly self explanatory.  The add a WhereClauseToken to the Tokens list */
     public void addConditional(Conditional cond) {
        addToken(new WhereClauseToken(cond));
     }
     
     public void addLeftParen() {
        addToken(new WhereClauseToken("("));
     }

     public void addRightParen() {
        addToken(new WhereClauseToken(")"));
     }
     
     public void addAnd() {
        addToken(new WhereClauseToken("and"));
     }
     
     public void addOr() {
        addToken(new WhereClauseToken("or"));
     }
     
     public void addNot() {
        addToken(new WhereClauseToken("!"));
     }

     /** adds the token to the tokens list and wipes out the array.  This will be built later when it is needed */
     private void addToken(WhereClauseToken token) {
        tokensArray=null;
        tokens.add(token);
         
     }
     
     private void addToken(String token) {
        addToken(new WhereClauseToken(token));
     }
     

     
    
     public WhereClauseToken[] getTokens() {
       if (tokens.isEmpty())
          tokensArray=null;
        else if (tokensArray==null) {
          tokensArray = new WhereClauseToken[tokens.size()];
          tokens.toArray(tokensArray);
       }  
       
       return tokensArray;
     }
     
     /* Return an array that determines how to build the underlying ArrayFilter.*/
     public Object[][] getCreateData() {
         List createData=new ArrayList();

         resetCompositeStack();
         // Loop through tokens and add to an arraylist info on how to build the underlying ArrayFilter.
         while (next()) {
           Object[] row={getCurrentToken(), getCreateComposite(),getConditionalToAdd(), getCompositeToAdd(), getStackAction(),getLastTokenIndicator()};
           createData.add(row);
         }
         
         // Convert the ArrayList back to a String[][]
         ResultSetUtils rsu=ResultSetUtils.createInstance();
         return rsu.listToObjectArray(createData);
         
     }
     
     // Indicates wheter or not a composite shold be created. 
     private String getCreateComposite() {
         if (getCurrentToken().isLeftParen()) {
           return createOrComposite();
         } // || conditional && 
         else if (getCurrentToken().isAnd() && getCurrentComposite().isOr()) {
           return createAndComposite();
         }  else 
           return "nocreate";

     }
     
     private String createAndComposite() {
           pushComposite(new Composite("and"));
           return "createAndComposite";
     }

     private String createOrComposite() {
           pushComposite(new Composite("or"));
           return "createOrComposite";
     }
     
     // indicates if a conditional needs to be added.  This is done in the token after the conditional.
     private String getConditionalToAdd() {
       if (getCurrentToken().isOperator() && getPrevToken().isConditional())
         return "addConditional"; // conditional or
       else if (getCurrentToken().isRightParen() && getPrevToken().isConditional())
         return "addConditional"; // conditional )
       else if (getCurrentToken().isConditional() && isLastToken())
         return "addConditional"; // conditional
       else 
         return "noAdd";
     
     }


     // indicates if a conditional composite needs to be added.  This is done in the token after the conditional.
     private String getCompositeToAdd() {
       if (getCurrentToken().isRightParen() && getPrevToken().isRightParen())
         return "addComposite"; // add conditional and composite
       else if (getCurrentToken().isOperator() && getPrevToken().isRightParen())
         return "addComposite"; // ) and
       else 
         return "noAdd";
         
     }
     
     // indicates whether or not the composite conditional should be popped from the stack and how many times.
     // a composite can be popped from a stack if if a right paren is encountered or you are moving from an and conditional
     // back to an or conditional.
     private String getStackAction() {
         if (getCurrentToken().isOr() && getCurrentComposite().isAnd()) {
           popComposite();
           return "pop1";
         }  else if (getCurrentToken().isRightParen()) {
             int popCounter=1;
             // the following covers this situation:  cond || (cond && cond) || 
             // ( - pushes an or composite
             // cond && cond - pushes a 2nd time
             // ) - would nomally pop once leaving us incorrectly in the && composite, so we pop an extra time 
             if (getCurrentComposite().isAnd()) {
               popCounter++;
               popComposite();
             }
             
             popComposite();
             return "pop"+popCounter;
         }
         else 
           return "noPop";

     }

     // indicates if the token is the last one.
     private String getLastTokenIndicator() {
         return isLastToken() ? "lastToken" : "notLastToken";
     }
     
     
     
     private WhereClauseToken getFirstToken() {
         return getTokens()[0];
     }
     
     private WhereClauseToken getCurrentToken() {
         return getToken(currentToken);
     }
     
     // indicates if there are more tokens 
     private boolean next() {
         if (currentToken<getNumTokens()-1) {
             currentToken++;
             return true;
         } else {
             currentToken=-1;
             return false;
         }
         
     }
     
     private WhereClauseToken getNextToken() {
         return getToken(currentToken+1);
     }
     
     private WhereClauseToken getPrevToken() {
         return getToken(currentToken-1);
     }
     
     private WhereClauseToken getLastToken() {
         return getTokens()[getNumTokens()-1];
     }

     private int getNumTokens() {
         return (getTokens()==null) ? 0 : getTokens().length;
     }

     private WhereClauseToken getToken(int i) {
         return (i>=0 && i<getNumTokens()) ? getTokens()[i] : NULLTOKEN;
     }
     
     private boolean isLastToken() {
         return (currentToken==(getNumTokens()-1));
     }
     
     /** Note by default this method throws a RuntimeException if there is a syntax error in
      *the ArraySQL.  If this capability is disabled then validate will return a false if a
      *parsing error occurs.
      */
     public boolean validate() {
         
         // 0 tokens is always valid
         if (getNumTokens()==0)
           return true;
         // look at general rules that don't apply to any one token
         else if (generalValidationRule()==false)
           return false;
         // look at each token and see if it is valid
         else if (individualTokenValidationRule()==false)
           return false;
         else 
           return true;
         
         
        
     }
     
     private boolean generalValidationRule() {
         // 1 conditional check - if there is only one token then it must be a conditional
         if (getNumTokens()==1 && !(getFirstToken().isConditional()))
           return setValidationError("If there is only one where clause token it must be a conditional.  The token is: "+getFirstToken().getValue());
         // the first token is a special case.  it can only be a conditional, a left paren or a not/! (i.e. not (col0=2))
         else if ( !  (getFirstToken().isConditional() || getFirstToken().isLeftParen() || getFirstToken().isNot()) )
           return setValidationError("The first where clause token must be a conditional, a left paren, not or !.  The token is: "+getFirstToken().getValue());
         // the last token is also a special case.  it can only be a conditional, a right paren
         else if ( !  (getLastToken().isConditional() || getLastToken().isRightParen()) )
           return setValidationError("The last where clause token must be a conditional, or a right paren.  The token is: "+getLastToken().getValue());
         else if (parensRule()==false)
           return false;
         else 
           return true;
         
     }
     
     // left and right parens must match and at any given time the number of right parens can't exceed the number of left parens
     private boolean parensRule() {
         int leftParens=0;
         int rightParens=0;

         // loop through tokens checking to see if left parens equals the number of right parens
         for (int i=0;i<getNumTokens();i++) {
            if (getToken(i).isLeftParen())
              leftParens++;
            else if (getToken(i).isRightParen())
              rightParens++;
            
            // the number of right parens can never exceed the number of left parens
            if (rightParens>leftParens)
             return setValidationError("The number of right parens exceeded the number of left parens. There are "+leftParens+" left parens, and "+rightParens+" right parens.");
            
         }
         
         // indicate if an error occured.
         if (leftParens!=rightParens)
           return setValidationError("The number of left parens must match the number of right parens.  There are "+leftParens+" left parens, and "+rightParens+" right parens.");
         else
           return true;

         
     }
     
     
     private boolean individualTokenValidationRule() {

         // validate all tokens except the last.  a special case of validating all but the last 
         // is when there is only 1 token then none will be validated.  This is because the first
         // and last terms can only allow certain possibilities that are more limited than other terms
         for (int i=0;i<getNumTokens()-1;i++) {
            WhereClauseToken token=getToken(i);
            boolean valid=token.isValid(getToken(i+1));
            if (!valid) {
              return setValidationError(token.getValidationError()+ " - token: "+token.getValue()+", token index: "+i);
            }
         }
         
         return true;

     }

     /** Returns a message of what the syntax validation error was if one occured */
     public String getValidationError() {
         return validationError;
     }
     
     // throws an exception if an error occured and exceptions are turned on.
     private boolean setValidationError(String validationError) {
         this.validationError=validationError;
         if (getThrowValidationExceptions())
           throw new FDSArraysRuntimeException(validationError);
         else
           return false;
       
     }
     
     // class that is used to track composites.
     private static class Composite {
         private String type;
         //private boolean isInAnd=false;
         public Composite(String type) {
             this.type=type;
         }

         
         public boolean isAnd() {
             return "and".equalsIgnoreCase(type);
         }
         
         public boolean isOr() {
             return "or".equalsIgnoreCase(type);
         }
     }
     
     private void pushComposite(Composite obj) {
         compositeStack.push(obj);
     }
     
     private Composite popComposite() {
         return (Composite) compositeStack.pop();
         
     }
     
     private Composite getCurrentComposite() {
         return (Composite) compositeStack.getCurrent();
     }
     
     private void resetCompositeStack() {
         compositeStack=new FDSStack();
         pushComposite(new Composite("or"));  // there is always a root composite.
     }
     

     
     public String toString() {
         
         WhereClauseToken[] array=getTokens();
         if (array==null)
           return "";
         else {
          String buffer=" where ";
          for (int i=0;i<array.length;i++) 
             buffer+=array[i]+" ";
          
          return buffer;
              
         }
         
     }
     

    static String getRowString(Object[][] buildData, int i) {
      return "token"+i+" build data:  (token="+buildData[i][0]+", "+buildData[i][1]+", "+buildData[i][2]+", "+buildData[i][3]+", "+buildData[i][4]+", "+buildData[i][5]+")";
    }
    
    private static void printDebugInfo(int testNumber, String whereClause) {
         String[] header={"fname","lname", "rank"};
         Object[][] data={
             {"jeff","beck",new Integer(1)},
             {"steve","smith",new Integer(2)},
             {"steve","souza",new Integer(3)},  // only true
         };

         WhereClauseParser p=new WhereClauseParser(data, whereClause, new ArrayFilter(header));
         String[] values=p.parse();
            
         WhereClauseTokens tokens=new WhereClauseTokens();
         for (int i=0;i<values.length;i++)
            tokens.addToken(values[i]);
         
         System.out.println("\n"+testNumber+") whereClause="+whereClause);
         boolean passedValidation=tokens.validate();
         System.out.println("validate()= "+passedValidation+", validation error="+tokens.getValidationError());
         
         if (passedValidation) {
           Object[][] buildData = tokens.getCreateData();
           for (int i=0;i<buildData.length;i++)
              System.out.println(getRowString(buildData,i));
         }
         
         System.out.println("WhereClauseTokens.toString(): "+tokens);
        
    }
     
    public static void main(String[] args) {
        // note where clause parser incorrectly returns: lname='beck ||
        // because the string is not terminated.
        // fname='steve' || lname='souza' && fname='jeff' && age=32 || ||  lname='beck ||
         setThrowValidationExceptions(false);
         printDebugInfo(1, "conditional || conditional && conditional && (conditional || conditional)");
         //printDebugInfo(2, "");
         printDebugInfo(3, "||");
         printDebugInfo(4, "conditional || || conditional && conditional && (conditional || conditional)");
         //printDebugInfo(5, "conditional && && conditional && conditional && (conditional || conditional)");
         printDebugInfo(6, "conditional || ");
         printDebugInfo(7, "(conditional");
         printDebugInfo(8, "(conditional)) || conditional");
         printDebugInfo(9, "conditional && conditional && conditional  || conditional && conditional");
         printDebugInfo(10, "conditional || conditional || conditional && conditional");
         printDebugInfo(12, "conditional || conditional && conditional && conditional");
         printDebugInfo(13, "((conditional || conditional) && conditional && conditional)");
         printDebugInfo(14, "(((conditional || conditional) && conditional) && (conditional && conditional) || conditional && conditional)");
         printDebugInfo(15, "(((conditional || conditional) && conditional) && (conditional && conditional) && conditional && conditional)");
         printDebugInfo(16, "(conditional || conditional) && (conditional) &&  conditional && conditional || conditional");
         printDebugInfo(17, "conditional || (conditional && conditional) || conditional");
         printDebugInfo(18, "conditional || (conditional && conditional) && conditional");
         printDebugInfo(19, "conditional && (conditional && conditional) && conditional");
         printDebugInfo(20, "conditional && (conditional && conditional) || conditional");
         printDebugInfo(21, "conditional || conditional && conditional");
         printDebugInfo(22, "conditional || conditional && conditional && conditional || conditional");
         
   


    }
    
    
    
} 
