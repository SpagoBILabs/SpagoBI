
output = input["Store Name"]
