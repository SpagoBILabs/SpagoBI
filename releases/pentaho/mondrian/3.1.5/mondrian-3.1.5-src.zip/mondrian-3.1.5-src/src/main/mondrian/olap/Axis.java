/*
// $Id: //open/mondrian-release/3.1/src/main/mondrian/olap/Axis.java#2 $
// This software is subject to the terms of the Eclipse Public License v1.0
// Agreement, available at the following URL:
// http://www.eclipse.org/legal/epl-v10.html.
// Copyright (C) 2001-2002 Kana Software, Inc.
// Copyright (C) 2001-2007 Julian Hyde and others
// All Rights Reserved.
// You must accept the terms of that agreement to use this software.
//
// jhyde, 6 August, 2001
*/

package mondrian.olap;

import java.util.List;

/**
 * A <code>Axis</code> is a component of a {@link Result}.
 * It contains a list of {@link Position}s.
 *
 * @author jhyde
 * @since 6 August, 2001
 * @version $Id: //open/mondrian-release/3.1/src/main/mondrian/olap/Axis.java#2 $
 */
public interface Axis {
    List<Position> getPositions();
}
// End Axis.java
