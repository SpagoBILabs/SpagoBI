// This class is generated. Do NOT modify it, or
// add it to source control.

package mondrian.resource;
import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eigenbase.resgen.*;

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from D:/workspace-juno/Mondrian_3.1.5/src/main/mondrian/resource/MondrianResource.xml
 * on Thu Jun 13 23:42:34 CEST 2013.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 */

public class MondrianResource_en_US extends MondrianResource {
    public MondrianResource_en_US() throws IOException {
    }
}

// End MondrianResource_en_US.java
